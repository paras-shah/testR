##### Welcome to Vision, the backend platform for Rubrik Cloud Fabric

### Want to preview
 1. Get a Clone
 1. cd newly cloned repo
 1. Get submodules `git submodule init; git submodule update` 
 1. Get a running stack `src/bin/dev_box --deploy_only`

#### House Rules 
1. Code sharing with between projects should be done via artifacts
2. Something very useful in multiple project move it out and create project and
   share via artifacts.
    1. For python artifacts can be 
        1. PIP
        2. PEX 
3. All projects should follow similar coding styles within this repo.
    1. For Django based projects follow Django guidelines
    2. [GIT COMMIT](https://chris.beams.io/posts/git-commit/)
4. Tests are important so don't shy away.
    1. Best to have automated test, its ok if we have to run them manually for now.
    2. Document testcases which can't be automated today using text based testplans
5. We use [GIT LFS](https://git-lfs.github.com/) to track large files and binaries used by this repo
    1. Install `curl -s https://packagecloud.io/install/repositories/github/git-lfs/script.deb.sh | sudo bash && sudo apt-get install -y git-lfs` 
6. Before creating a PR, please run `src/bin/format`. 
    1. This will format all files in the directory to keep style consistency throughtout the project.

 ### Want to develop 
 1. Get a dev env`src/bin/dev_box`
    * your `username` is your password if required
    * If for some reason you see errors with env_generator.py to unblock
        * copy `env_template.yaml` to `env_template_override.yaml`
        * Replace the content of each value manually yourself
1. Create branch and develop

### Vision Doc Index

1. [Dev Notes](docs/dev.md)
2. Features
    1. [Lab Instance Request](docs/features/lab_instance_request.md)
