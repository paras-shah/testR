# LabTemplateInstance Overview

LabTemplateInstance is core of `vision` and allows to get a instance of lab template type. Below state diagram show state transition a


### RequestStatus

```mermaid
graph TD;
Initial -->Processing;
Initial -->PendingRelease;
Processing -->Ready;
Processing -->Failed;
Processing -->PendingRelease;
Ready -->PendingRelease;
PendingRelease -->Released;
```