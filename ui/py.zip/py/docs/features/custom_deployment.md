## Custom Deployment Overview

This feature is intended to be able to customize various phases for a virtual machine per template.

 1. pre deploy 
 1. post deploy
 1. deploy .
 
Overall for each phase of vm deployment we will support customization by providing hooks for each phase. Each
hook will be invoked if its defined. 

Each hook will follow same I/O format for information passing. This entire workflow will be config driven which
is stored in database, this permits over-ride of these hook while placing a reservation request. 

Format of how information will be passed around or contributed is as follows. 


So for each phase (pre_deploy/post_deploy/deploy), we will support generic set of key:values given below:

1. `script_name`: globally unique name for this script
1. `script_path`: absolute path from yoda-worker imagescript_container_image
1. `script_container_image`: not needed now but idea is to be able to use a custom image to run the post deploym
1. `script_env_param_name`: script will only read this param as source of input, caller needs to set this
1. `script_input_template`:  This yaml string template help caller fill the data which will be set in env_param
        - open item :how to handle complex object in string .format apporach and also be able to reference other top level
            keys so that we don't have to repeat the data
1. `script_input_params_required`: minimum info required for the hook to run
1. `script_input_params`: this is all the variables which caller can customize before calling script
1. `script_input_params_default`: defines default where possible. it will be a dictionary with default values for params
1. `script_output_params`: Params to expects as output of the hook. Can be used to validate input for next step of 
workflow in future. 

`Note: This is not fully implemented yet. But rather an overview of what we want to support.
Currently, post deploy hook is supported.`
 
### Implementation
 
On the VmTemplate object, if it requires any pre/post/deploy customization, it will have the following key:value pairs:

1. 'config.customization.pre_deploy': pre deploy config dictionary
2. 'config.customization.post_deploy': post deploy config dictionary
3. 'config.customization.deploy': deploy config dictionary

Not all keys are required. 

<pre/post/deploy config dictionary> above is the same as the generic set of key:values defined above
 
When submitting a request to JustVm, every virtual machine as part of reservation has its own set of configuration.
In order to invoke the custom deployment hook, the following payload can be sent alongwith reservation request. 

```
{
  "vm_custom_deployment": {
    "post_deploy": {
      "params": <params dictionary>
    },
    "pre_deploy": {
      "params": <params dictionary>
    },
    "deploy": {
      "params": <params dictionary>
    }
  }
}
```
where any parameter defined as part of `params dictionary`  will override any default parameters defined 
for the hook in the VmTemplate object.

Note that if there is no default value defined for a parameter, it is expected to be sent as part of reservation 
request.