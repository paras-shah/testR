## Developer options

### Motivation

The motivation for developer options is to allow a developer working on this project 
to be able to tweak some behavior on production test their own changes while leaving the
rest of the production untouched. 

### Supported options

1. yoda-worker: specify the yoda-worker image to be used for the reservation request


### Usage:

As part of the virtual machine spec in a reservation request, under "developer_options" key, 
you can specify all options and their values for it to take effect. 

For eg. here is a request asking to deploy esx6.7 on colo network with a custom yoda-worker image
```
[
  {
    "resource_type": "vm",
    "vm_networks": [
      "VM Network"
    ],
    "vm_image_source": "esx6.7",
    "location": "Colo",
    "developer_options": {
      "yoda-worker": "temp-docker-registry.colo.rubrik-lab.com:5000/vision/yoda-worker:65b1f1134f7e306506feaf523a1ccacad150ca5c"
    },
    "vm_custom_deployment": null,
    "post_deploy": {
      "params": {
        "esxi_vm_network_vlan": 131
      }
    }
  }
]
```