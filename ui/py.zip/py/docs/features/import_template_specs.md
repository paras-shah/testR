## Import Lab Templates

![Import Lab Templates Diagram](import_template_specs.png)

---
### Import Lab Templates Process
* Purpose of the import lab spacs process to run in the background to automate lab template version control

    * Will identify the absolute path needed
    * Retrieves all lab template repos based on established search criteria
    * Calls `run_import_lab_templates` with repo name and root directory
    
### Clone Lab Templates
* Purpose is to clone or pull a lab templates from github to the same environment that Vision is deployed on

    * Given lab template repo name and a path to the lab template repo root location
        * Inspects and updates the lab template directories
    * Creates a root directory for all lab templates
    * Uses lab template repo name to identify the repo in the database
    * Uses lab template repo url for clone procedures
    * Uses lab template repo token to establish github permissions

### Import Lab Templates
* Purpose is to identify and update changes for lab templates

    * Given lab template repo name and a path to the lab template repo root location
        * Compares, adds and/or updates lab templates and updates lab template repo
    * Depends on lab templates being located on the same environment as Vision
    * Identifies lab templates by the given lab template repo and git commit hash
    * Will either create a new version of the lab template of update the current lab template
    * New lab templates start as `v1` and get incremented upon data changes
    * Lab template must be located inside a labs folder
    * A lab template must have a minimum of four files with optional readme
        * create.yaml
        * meta.yaml
        * param.yaml
        * release.yaml
        * readme.md (optional)
---
#### Quickstart
`
./manage.py import-lab-templates
--repo_name <repo name> 
--root_directory <full path> 
`