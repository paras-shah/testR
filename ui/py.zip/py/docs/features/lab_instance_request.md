# Cannon to Vision Workflow
![State Diagram](Vision-Cannon-StateDiagram.png)
___
### Cannon Requests
1. Start a task
2. Get the status of a task

### Vision Tasks
1. Run "Initial" tasks ("Initial")
    * Check capacity
    * Run Cannon(1)
        * Nothing
        * Change to "Processing"

2. Check status of "Processing" ("Processing")
    * Run Cannon(2)
        * Nothing
        * Change to "Ready"
        * Change to "ProcessingFailed"

3. Check status of "ReleaseRequest" ("ReleaseRequest")
    * Run Cannon(2)
        * Nothing
        * Change to "PendingRelease"
        
4. Retry Policy for "ProcessingFailed"
    * Change to "Initial"
    * Change to "PendingRelease"

5. Lab TTL is over ("Ready")
    * Change to "PendingRelease"

6. Run "Release" tasks ("PendingRelease")
    * Run Cannon(1)
        * Nothing
        * Change to "Releasing"

7. Check status of "Releasing" ("Releasing")
    * Run Cannon(2)
        * Nothing
        * Change to "Released"
        * Change to "ReleaseFailed"

8. Retry Policy for "ReleaseFailed"
    * Change to "PendingRelease"
    * Change to "Releasesd"
