#### Other Dev Notes....

### E2e Test
1. Read about pytest and its plugin we use
    1. https://github.com/pytest-dev/pytest-repeat
    1. https://docs.pytest.org/en/3.0.0/xdist.html
    
1. How to run live server test
    1. Single user crate around 3 task request. 
        
            pytest e2e/test_live_server.py  -s --fulltrace
            
    1. Multi User mode where around 2 user generate request.
        
            pytest -n 2  --count 2  e2e/test_live_server.py  -s --fulltrace

    1. RubrikScale mode where around 80 user generate request. 
      
            pytest -n 80  --count 4  e2e/test_live_server.py  -s --fulltrace
    
    1. Manual local verification of negative context. 
      
             pytest e2e/test_live_server.py  -s --fulltrace -k test_reservation_lifecycle --context negative

1. Testing e2e on same host
    1. Add `env_template_override.yaml` in cannon with following content 
            
            DEFAULT_PROXY_SERVICE_PORT: 8080
    1. Make sure `cannon` instance can access `artifact.storage` from globalConfig of cannon server 
       and start cannon
    1. Add `docker-compose.override.yaml` in vision with following content
    
            version: '3.6'
            x-logging-1: &default-logging
              options:
                max-size: '1m'
                max-file: '5'
              driver: json-file
            
            services:
              proxy:
                image: jwilder/nginx-proxy:alpine-0.7.0
                ports:
                - ${DEFAULT_PROXY_SERVICE_PORT:?DEFAULT_PROXY_SERVICE_PORT}:80
                volumes:
                - /var/run/docker.sock:/tmp/docker.sock:ro
                networks:
                - cannon
                - vision
              celery-worker-web:
                image: ${IMAGE_NAME_PREFIX:?IMAGE_NAME_PREFIX}/web:${WEB_IMAGE_SUFFIX:-latest}
                command: celery worker -A rubrik.vision.site -l DEBUG --events --concurrency=${CELERY_WORKER_WEB_CONCURRENCY:?CELERY_WORKER_WEB_CONCURRENCY} -Ofair
                env_file:
                - ${PWD:?PWD}/.env
                environment:
                  PYTHONPATH: /src/
                logging: *default-logging
                depends_on:
                - redis
                - redis-ui
                - rabbit
            
            networks:
              cannon:
                driver: bridge
                name: cannon
              vision:
                driver: bridge
                name: vision
    1. Change about snippets to match your env setup
    1. Run any vision e2e test it should work.

1. Mocking e2e on same host
    1. Ensure `VISION_DEBUG_DEVELOPMENT_CONTEXT` is true
    1. Follow all the steps from `Testing e2e on sme host` 
    
# Unit Tests
1. How to run tests
    1. Start the dev_box: 
    `./bin/dev_box`
    1. Start the services: 
    `./bin/deploy`
    1. Run the test: 
    `./manage.py test`
    1. Using coverage to generate a report
        1. Run tests with: 
        `coverage run --source='.' manage.py test`
        1. Generate html report with: 
        `coverage html`

### Formatting code
1. `yapf -i -r -p -e yoda .`

### Update yoda_env worker
1. Update yoda sub-module to a stable desired tip
1. Copy the sd_dev bootstrap hash from sdmain and add it as first line in 
    docker/workers/yoda_env/Dockerfile. This will ensure we don't have missing
    pip or other env deps for yoda lib to work correctly.

### Installing new packages in Django
1. Go to ../src/
2. Run "pipenv install .."
3. Example "pipenv install django-cors-headers==3.1.0"

### Django Debugging
1. set environment variable: debug=true
2. Terminal:
    1.after running /bin/deploy:
        1. docker-compose run --service-ports dev-web /bin/bash
        2. python manage.py runserver 0.0.0.0:8080 --insecure --nothreading
        3. access server : dev.web.vision......local/api
3. Function debugging : IPython.embed()
4. Comment out Celery beat tasks for local developing

### Dev Coding Standards
1. Add docs in each models
2. Organize imports and reformat code before pushing


## Vision Doc Index

1. [Import Template Specs](features/import_template_specs.md)
