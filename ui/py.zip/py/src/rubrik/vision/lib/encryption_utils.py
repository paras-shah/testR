from cryptography.fernet import Fernet


def encryption(data, encryption_key):
    """
    >>> data = "data"
    >>> assert data == decryption(encryption(data=data))
    """

    f = Fernet(encryption_key)
    return f.encrypt(data.encode()).decode("utf-8")


def decryption(data, encryption_key):
    f = Fernet(encryption_key)
    return f.decrypt(data.encode()).decode("utf-8")


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
