import re
import smtplib
import configparser
import logging
from datetime import datetime

from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email import encoders

# from email.mime.base import MIMEBase

from rubrik.vision.site.settings import SMTP_CONFIGURATIONS

# Configurations
smtp_server_address = SMTP_CONFIGURATIONS["server"]
smtp_username = SMTP_CONFIGURATIONS["user_name"]
smtp_password = SMTP_CONFIGURATIONS["password"]
smtp_port = int(SMTP_CONFIGURATIONS["port"])


# for validating an Email
def validate_email(email):
    regex = "^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$"
    # pass the regualar expression
    # and the string in search() method
    return bool(re.search(regex, email))


# sendig an email
def send_mail(mail_sender, mail_receiver, mail_subject, mail_body, mail_attachment):
    # logging.INFO('MAIL_ATTACHMENT TYPE: {0}'.format(type(mail_attachment)))
    # Create message container - the correct MIME type is multipart/alternative.
    msg = MIMEMultipart("alternative")
    msg["Subject"] = mail_subject
    msg["From"] = mail_sender
    msg["To"] = mail_receiver
    msg["Date"] = datetime.now().strftime("%d/%m/%Y %H:%M")
    msg.attach(MIMEText(mail_body, "html"))

    # Attachments
    if mail_attachment != "":
        part = MIMEApplication(mail_attachment.read(), Name=mail_attachment.__str__())
        part["Content-Disposition"] = 'attachment; filename="{0}"'.format(
            mail_attachment
        )
        # Add attachment to message
        msg.attach(part)

    # convert message to string
    text = msg.as_string()

    # send mail
    try:
        smtp_server = smtplib.SMTP(smtp_server_address, smtp_port)
        smtp_server.ehlo()
        smtp_server.starttls()
        smtp_server.ehlo()
        smtp_server.login(smtp_username, smtp_password)
        response = smtp_server.sendmail(mail_sender, mail_receiver, text)
        logging.info("Response of sending email {0}".format(response))
        smtp_server.close()
    except Exception:
        logging.exception("Error while sending email", exc_info=True)
        return False
    return True
