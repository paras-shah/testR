import logging

import plumbum


def get_change_set(directory):
    """Get git hash from full path

    :param directory: full path
    :return: change_set hash
    """

    with plumbum.local.cwd(directory):
        change_set = plumbum.local["git"]["log", "--pretty=oneline", "-n 1", "."]()
        change_set = change_set.strip().split(" ")[0]
        logging.info(
            "change_set: {0}, workflow_path: {1}".format(change_set, directory)
        )
        return change_set
