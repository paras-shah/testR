"""Collection of tools to manipulate python nested data structures.

These collection of tools are very handy to transform data so that
we can write generic comparision function. Using it we can handle
a very nested and complex structure and define a scheme to compare
them.

Assumption
  1. Keys of dictionary will be string type.

Note: Do not alter the formatting of this file specially in doc string as it
act as testcase as well.

How To Test:
    python collections_utils.py
"""

import yaml
import collections
import copy
import json
import re
import urllib

import six
from deepdiff import DeepDiff


class CollectionUtils(object):
    """Collection of tools to manipulate python nested data structures."""

    # ########################################################################
    # Export / Import
    # ########################################################################
    @staticmethod
    def load_json_from_url(source):
        """Return a python collection object from given url.

        :param source:
        :return: python object
        """
        response = urllib.urlopen(source)
        return json.loads(response.read())

    @staticmethod
    def load_json_from_file(filename):
        """Return a python collection object from given file.

        :param filename:
        :return: python object
        """
        with open(filename) as ifp:
            return json.loads(ifp.read())

    @staticmethod
    def load_json_from_string(json_str):
        """Return a python collection object from given json string.

        :param json_str:
        :return: python object

        >>> a = {u'a': u'b', u'c':[1,2,3,4]}
        >>> b = CollectionUtils.load_json_from_string(CollectionUtils.dump_dict_to_string(a))
        >>> CollectionUtils.is_equal(a,b)
        True
        """
        return json.loads(json_str)

    @staticmethod
    def dump_dict_to_file(
        input_collection,
        filename,
        sort_keys=True,
        indent=4,
        ensure_ascii=True,
        **kwargs
    ):
        """Export given collection to json.

        A thin wrapper around json module with some reasonable defaults.

        :param input_collection:
        :param filename:
        :param indent:
        :param sort_keys:
        :param ensure_ascii:
        """
        with open(filename, "w") as ofp:
            ofp.write(
                json.dumps(
                    input_collection,
                    sort_keys=sort_keys,
                    indent=indent,
                    ensure_ascii=ensure_ascii,
                    **kwargs
                )
            )

    @staticmethod
    def dump_dict_to_string(
        input_collection, sort_keys=True, indent=4, ensure_ascii=True, **kwargs
    ):
        r"""Export given collection to json.

        A thin wrapper around json module with some reasonable defaults.

        :param input_collection:
        :param sort_keys:
        :param indent:
        :param ensure_ascii:
        :return: String rep of input collection

        >>> a = {u'a':u'b', u'c':[1,2,3,4]}
        >>> b = CollectionUtils.load_json_from_string(CollectionUtils.dump_dict_to_string(a))
        >>> CollectionUtils.is_equal(a, b)
        True
        """
        return json.dumps(
            input_collection,
            sort_keys=sort_keys,
            indent=indent,
            ensure_ascii=ensure_ascii,
            **kwargs
        )

    @staticmethod
    def is_json_data_type(v):
        """Return true if given value is json basic data type.

        :param v:
        :return: True | False

        >>> CollectionUtils.is_json_data_type('')
        True
        >>> CollectionUtils.is_json_data_type(1)
        True
        >>> CollectionUtils.is_json_data_type([])
        False
        >>> CollectionUtils.is_json_data_type({})
        False
        >>> CollectionUtils.is_json_data_type(1.0)
        True
        >>> CollectionUtils.is_json_data_type(True)
        True
        >>> CollectionUtils.is_json_data_type(None)
        True
        >>>
        """
        return (
            isinstance(v, float)
            or isinstance(v, six.integer_types)
            or isinstance(v, six.string_types)
            or isinstance(v, six.text_type)
            or isinstance(v, bool)
            or v is None
        )

    @staticmethod
    def copy(input_collection):
        """Create copy of given collection.

        :param input_collection:
        :return: A copy of input_collection

        >>> a = {'a':'b'}
        >>> b = CollectionUtils.copy(a)
        >>> a['a'] = 'c'
        >>> a
        {'a': 'c'}
        >>> b
        {'a': 'b'}
        >>>
        """
        return copy.deepcopy(input_collection)

    # ########################################################################
    # Manipulate
    # ########################################################################
    @staticmethod
    def replace_key_with_path(input_collection):
        r"""Replace the key in collection with path from root of collection.

        This method is very hand where hierarchy of collection needs to be
        preserved, but due to similar key names other function in this
        utility can not be used to further process input_collection.

        :param input_collection:
        :return A new copy of data

        >>> data = [
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   },
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   }
        ... ]
        >>> expected = [{'0.hyperv': [{'0.hyperv.0.dns': 'demo.local', '0.hyperv.0.name': 'demo-linux-vm'}, {'0.hyperv.1.dns': 'demo.local2', '0.hyperv.1.name': 'demo-linux-vm2'}], '0.vmware': [{'0.vmware.0.dns': 'demo.local', '0.vmware.0.name': 'demo-linux-vm'}, {'0.vmware.1.dns': 'demo.local2', '0.vmware.1.name': 'demo-linux-vm2'}]}, {'1.hyperv': [{'1.hyperv.0.dns': 'demo.local', '1.hyperv.0.name': 'demo-linux-vm'}, {'1.hyperv.1.dns': 'demo.local2', '1.hyperv.1.name': 'demo-linux-vm2'}], '1.vmware': [{'1.vmware.0.dns': 'demo.local', '1.vmware.0.name': 'demo-linux-vm'}, {'1.vmware.1.dns': 'demo.local2', '1.vmware.1.name': 'demo-linux-vm2'}]}]
        >>> outcome = CollectionUtils.replace_key_with_path(data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = {'hyperv': [{'hyperv.0.name': 'demo-linux-vm', 'hyperv.0.dns': 'demo.local'}, {'hyperv.1.name': 'demo-linux-vm2', 'hyperv.1.dns': 'demo.local2'}], 'vmware': [{'vmware.0.dns': 'demo.local', 'vmware.0.name': 'demo-linux-vm'}, {'vmware.1.dns': 'demo.local2', 'vmware.1.name': 'demo-linux-vm2'}]}
        >>> outcome = CollectionUtils.replace_key_with_path(data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        """
        input_collection = CollectionUtils.copy(input_collection)

        def _replace_key_with_path(sub_input_collection, parentKeyName):
            if not isinstance(sub_input_collection, collections.Iterable):
                return
            items_keys = (
                list(sub_input_collection.keys())
                if type(sub_input_collection) is dict
                else sub_input_collection
            )
            for index, item_key in enumerate(items_keys):
                if type(sub_input_collection) is list and isinstance(
                    item_key, collections.Iterable
                ):
                    if parentKeyName:
                        _replace_key_with_path(
                            item_key, "{}.{}".format(parentKeyName, index)
                        )
                    else:
                        _replace_key_with_path(item_key, "{}".format(index))
                elif type(sub_input_collection) is dict:
                    if parentKeyName:
                        _parentKeyName = "{}.{}".format(parentKeyName, item_key)
                    else:
                        _parentKeyName = "{}".format(item_key)

                    # Update dict key name
                    _data = sub_input_collection.pop(item_key)
                    sub_input_collection[_parentKeyName] = _data

                    if isinstance(_data, collections.Iterable):
                        _replace_key_with_path(_data, _parentKeyName)

        if isinstance(input_collection, collections.Iterable):
            _replace_key_with_path(input_collection, None)

        return input_collection

    @staticmethod
    def replace_str_everywhere(old_new_pair, input_collection):
        r"""Replace given pair of old/new strings everywhere.

        This function will convert collection to json string and apply string \
        replace function, so if its
        a dictionary it will replace key and value both.

        If you have to replace string involving escape characters, account \
        for json converter
        adding additional escape characters.

        :param old_new_pair:
        :param input_collection:
        :return: A copy of data

        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = {u'hyperv': [{u'name': u'dev-linux-vm', u'dns': u'dev.local'}, {u'name': u'dev-linux-vm2', u'dns': u'dev.local2'}], u'vmware': [{u'name': u'dev-linux-vm', u'dns': u'dev.local'}, {u'name': u'dev-linux-vm2', u'dns': u'dev.local2'}]}
        >>> outcome = CollectionUtils.replace_str_everywhere([('demo','dev')],data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        """
        str_input_collection = CollectionUtils.dump_dict_to_string(
            input_collection, sort_keys=False, indent=None
        )
        _old_new_map = {}
        for _old, _new in old_new_pair:
            _old_new_map[_old] = _new

        old_new_pair = []
        for k in sorted(_old_new_map.keys(), reverse=True):
            old_new_pair.append((k, _old_new_map[k]))

        for _old, _new in old_new_pair:
            str_input_collection = str_input_collection.replace(_old, _new)

        return json.loads(str_input_collection)

    @staticmethod
    def deflate_collection(input_collection, delimiter="."):
        """Deflates the multi level collection to single level.

        :param input_collection:
        :param delimiter: Default delimiter is '.'
        :return input_collection with expanded keys

        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = {'vmware.0.name': 'demo-linux-vm', 'vmware.1.dns': 'demo.local2', 'vmware.0.dns': 'demo.local', 'hyperv.1.name': 'demo-linux-vm2', 'hyperv.0.dns': 'demo.local', 'hyperv.0.name': 'demo-linux-vm', 'hyperv.1.dns': 'demo.local2', 'vmware.1.name': 'demo-linux-vm2'}
        >>> outcome = CollectionUtils.deflate_collection(data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> data = [
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   },
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   }
        ... ]
        >>> expected = {'1.vmware.0.dns': 'demo.local', '0.hyperv.0.dns': 'demo.local', '0.hyperv.0.name': 'demo-linux-vm', '1.vmware.1.name': 'demo-linux-vm2', '1.hyperv.1.name': 'demo-linux-vm2', '1.hyperv.1.dns': 'demo.local2', '1.hyperv.0.dns': 'demo.local', '0.vmware.1.name': 'demo-linux-vm2', '1.vmware.0.name': 'demo-linux-vm', '0.vmware.1.dns': 'demo.local2', '0.hyperv.1.name': 'demo-linux-vm2', '1.vmware.1.dns': 'demo.local2', '0.hyperv.1.dns': 'demo.local2', '0.vmware.0.dns': 'demo.local', '0.vmware.0.name': 'demo-linux-vm', '1.hyperv.0.name': 'demo-linux-vm'}
        >>> outcome = CollectionUtils.deflate_collection(data)
        >>> CollectionUtils.is_equal(expected,outcome)
        True
        >>> data = [
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   },
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   }
        ... ]
        >>> expected = {'1,vmware,0,dns': 'demo.local', '0,hyperv,0,dns': 'demo.local', '0,hyperv,0,name': 'demo-linux-vm', '1,vmware,1,name': 'demo-linux-vm2', '1,hyperv,1,name': 'demo-linux-vm2', '1,hyperv,1,dns': 'demo.local2', '1,hyperv,0,dns': 'demo.local', '0,vmware,1,name': 'demo-linux-vm2', '1,vmware,0,name': 'demo-linux-vm', '0,vmware,1,dns': 'demo.local2', '0,hyperv,1,name': 'demo-linux-vm2', '1,vmware,1,dns': 'demo.local2', '0,hyperv,1,dns': 'demo.local2', '0,vmware,0,dns': 'demo.local', '0,vmware,0,name': 'demo-linux-vm', '1,hyperv,0,name': 'demo-linux-vm'}
        >>> outcome = CollectionUtils.deflate_collection(data, delimiter=',')
        >>> CollectionUtils.is_equal(expected,outcome)
        True
        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = {'vmware,0,name': 'demo-linux-vm', 'vmware,1,dns': 'demo.local2', 'vmware,0,dns': 'demo.local', 'hyperv,1,name': 'demo-linux-vm2', 'hyperv,0,dns': 'demo.local', 'hyperv,0,name': 'demo-linux-vm', 'hyperv,1,dns': 'demo.local2', 'vmware,1,name': 'demo-linux-vm2'}
        >>> outcome = CollectionUtils.deflate_collection(data, delimiter=',')
        >>> CollectionUtils.is_equal(expected, outcome)
        True

        """
        input_collection = CollectionUtils.copy(input_collection)
        output_collection = {}

        def _deflate_collection(inner_collection, parentKeyName):
            if not isinstance(inner_collection, collections.Iterable):
                return

            items_keys = (
                inner_collection.keys()
                if type(inner_collection) is dict
                else inner_collection
            )

            for index, item_key in enumerate(items_keys):
                if type(inner_collection) is list and isinstance(
                    item_key, collections.Iterable
                ):
                    if parentKeyName:
                        _deflate_collection(
                            item_key, "{}{}{}".format(parentKeyName, delimiter, index)
                        )
                    else:
                        _deflate_collection(item_key, "{}".format(index))
                elif type(inner_collection) is dict:
                    if parentKeyName:
                        _parentKeyName = parentKeyName + delimiter + item_key
                    else:
                        _parentKeyName = item_key

                    _data = inner_collection.get(item_key)
                    if CollectionUtils.is_json_data_type(_data):
                        output_collection[_parentKeyName] = _data

                    if isinstance(_data, collections.Iterable):
                        _deflate_collection(_data, _parentKeyName)

        _deflate_collection(input_collection, None)
        return output_collection

    @staticmethod
    def remove_keys(pattern, input_collection):
        r"""Remove key if they match pattern.

        It will replace any key and its corresponding value from collection \
            where pattern matches.

        :param pattern: Python regular expression
        :param input_collection:
        :return New collection with key removed

        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = {'hyperv': [{'name': 'demo-linux-vm'}, {'name': 'demo-linux-vm2'}], 'vmware': [{'name': 'demo-linux-vm'}, {'name': 'demo-linux-vm2'}]}
        >>> outcome = CollectionUtils.remove_keys('dns',data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> expected = {'hyperv': [{'dns': 'demo.local'}, {'dns': 'demo.local2'}], 'vmware': [{'dns': 'demo.local'}, {'dns': 'demo.local2'}]}
        >>> outcome = CollectionUtils.remove_keys('name',data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> data = CollectionUtils.remove_keys('name',data)
        >>> expected = {'hyperv': [{}, {}], 'vmware': [{}, {}]}
        >>> outcome = CollectionUtils.remove_keys('dns',data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        """
        input_collection = CollectionUtils.copy(input_collection)

        def _remove_keys(_pattern, _input_collection):
            if type(_input_collection) == list:
                for i in range(0, len(_input_collection)):
                    if (
                        type(_input_collection[i]) == dict
                        or type(_input_collection[i]) == list
                    ):
                        _remove_keys(_pattern, _input_collection[i])
            else:
                for k in list(_input_collection.keys()):
                    v = _input_collection[k]
                    # match patterns and remove those
                    if re.match(_pattern, k):
                        _input_collection.pop(k)

                    if type(v) == dict or type(v) == list:
                        _remove_keys(_pattern, _input_collection[k])

        if pattern:
            _remove_keys(pattern, input_collection)
        return input_collection

    @staticmethod
    def remove_keys_except(pattern, input_collection, nested_clean=True):
        r"""Remove key all keys which are not a match.

        It will replace any key and its corresponding value from collection \
            where pattern
        is not a match.

        Nested clean means if parent is match still go down and clear out any \
            thing which does
        not match.

        :param pattern: Python regular expression
        :param input_collection:
        :param nested_clean: By Default don't clean nested if parent need to \
            be preserved
        :return A new copy of input_collection with preserved keys

        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = {'hyperv': [{'dns': 'demo.local'}, {'dns': 'demo.local2'}], 'vmware': [{'dns': 'demo.local'}, {'dns': 'demo.local2'}]}
        >>> outcome = CollectionUtils.remove_keys_except('dns',data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> expected = {'hyperv': [{}, {}], 'vmware': [{}, {}]}
        >>> outcome = CollectionUtils.remove_keys_except('vmware', data)
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> expected = {'hyperv': [{}, {}], 'vmware': [{'name': 'demo-linux-vm', 'dns': 'demo.local'}, {'name': 'demo-linux-vm2', 'dns': 'demo.local2'}]}
        >>> outcome = CollectionUtils.remove_keys_except('vmware', data, nested_clean=False)
        >>> CollectionUtils.is_equal(expected,outcome)
        True
        """
        input_collection = CollectionUtils.copy(input_collection)

        def _remove_keys_except(_pattern, _input_collection, _nested_clean):
            if type(_input_collection) == list:
                for i in range(0, len(_input_collection)):
                    if (
                        type(_input_collection[i]) == dict
                        or type(_input_collection[i]) == list
                    ):
                        _remove_keys_except(
                            _pattern, _input_collection[i], _nested_clean
                        )
            else:
                for k in list(_input_collection.keys()):
                    v = _input_collection[k]
                    k_in_pattern = True if re.match(_pattern, k) else False

                    if not k_in_pattern and not (type(v) == dict or type(v) == list):
                        _input_collection.pop(k)
                        continue

                    if (
                        not k_in_pattern
                        and type(v) == list
                        and all(isinstance(x, six.string_types) for x in v)
                    ):
                        _input_collection.pop(k)
                        continue

                    if not k_in_pattern and type(v) == dict and v == {}:
                        _input_collection.pop(k)
                        continue

                    if not _nested_clean and k_in_pattern:
                        continue

                    if type(v) == dict or type(v) == list:
                        _remove_keys_except(
                            _pattern, _input_collection[k], _nested_clean
                        )

        if pattern:
            _remove_keys_except(pattern, input_collection, nested_clean)
        return input_collection

    @staticmethod
    def update_keys_value(pattern, input_collection, callable_or_value):
        r"""Update of values for all the key matched by pattern.

        :param str pattern: Pattern of key whose value will be updated
        :param dict or list input_collection: Collection which will operated
        :param func or lambda callable_or_value:
                Can be string or callable with returns
                processed callable_or_value
        :return New collection with updated value for keys

        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = {'hyperv': [{'name': 'newNameForAllVms', 'dns': 'demo.local'}, {'name': 'newNameForAllVms', 'dns': 'demo.local2'}], 'vmware': [{'name': 'newNameForAllVms', 'dns': 'demo.local'}, {'name': 'newNameForAllVms', 'dns': 'demo.local2'}]}
        >>> outcome = CollectionUtils.update_keys_value('name',data,'newNameForAllVms')
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> expected = {'hyperv': [{'name': 'demo-linux-vm', 'dns': 'demo.rubrik'}, {'name': 'demo-linux-vm2', 'dns': 'demo.rubrik'}], 'vmware': [{'name': 'demo-linux-vm', 'dns': 'demo.rubrik'}, {'name': 'demo-linux-vm2', 'dns': 'demo.rubrik'}]}
        >>> outcome  = CollectionUtils.update_keys_value('dns',data, lambda x: "{}.rubrik".format(x.split('.')[0]))
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        """
        input_collection = CollectionUtils.copy(input_collection)

        def _update_keys_value(_pattern, _input_collection, _callable_or_value):
            if type(_input_collection) == list:
                for i in range(0, len(_input_collection)):
                    if (
                        type(_input_collection[i]) == dict
                        or type(_input_collection[i]) == list
                    ):
                        _update_keys_value(
                            _pattern, _input_collection[i], _callable_or_value
                        )
            else:
                for k, v in _input_collection.items():
                    # match patterns and remove those
                    if re.match(_pattern, k):
                        if callable(_callable_or_value):
                            _input_collection[k] = _callable_or_value(v)
                        else:
                            _input_collection[k] = _callable_or_value

                    if type(v) == dict or type(v) == list:
                        _update_keys_value(
                            _pattern, _input_collection[k], _callable_or_value
                        )

        if pattern:
            _update_keys_value(pattern, input_collection, callable_or_value)
        return input_collection

    @staticmethod
    def convert_to_dict(input_collection, callable_or_value):
        """Covert a list of dictionary to dictionary.

        :param input_collection:
        :param callable_or_value:
        :return: Dict

        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> CollectionUtils.convert_to_dict(data,'name')
        Traceback (most recent call last):
        ...
        RuntimeError: Only list are supported
        >>> expected = {'demo-linux-vm2': {'name': 'demo-linux-vm2', 'dns': 'demo.local2'}, 'demo-linux-vm': {'name': 'demo-linux-vm', 'dns': 'demo.local'}}
        >>> outcome = CollectionUtils.convert_to_dict(CollectionUtils.find('vmware',data)[0],'name')
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        """
        if not isinstance(input_collection, list):
            raise RuntimeError("Only list are supported")
        response = {}
        for i in input_collection:
            if callable(callable_or_value):
                response[callable_or_value(i)] = i
            else:
                response[i[callable_or_value]] = i

        return response

    # ########################################################################
    # Find and compare
    # ########################################################################
    @staticmethod
    def find_keys(pattern, input_collection, depth=-1, expand_key_names=True):
        r"""For given pattern return a list of keys.

        :param pattern: python regular expression
        :param input_collection: collection which will be searched
        :param depth: How many level deep should it go. Default: -1 means no \
            limit
        :param expand_key_names: Matched key will be prefixed with path from \
            root.
        :return: A list of keys

        >>> data = {
        ...   "vmware": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ],
        ...   "hyperv": [
        ...     {
        ...       "name": "demo-linux-vm",
        ...       "dns": "demo.local"
        ...     },
        ...     {
        ...       "name": "demo-linux-vm2",
        ...       "dns": "demo.local2"
        ...     }
        ...   ]
        ... }
        >>> expected = ['hyperv.0.dns', 'hyperv.1.dns', 'vmware.0.dns', 'vmware.1.dns']
        >>> outcome = CollectionUtils.find_keys('dns',data)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> expected = ['dns', 'dns', 'dns', 'dns']
        >>> outcome = CollectionUtils.find_keys('dns',data,expand_key_names=False)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> expected  = ['hyperv', 'vmware']
        >>> outcome = CollectionUtils.find_keys('.*r.*',data)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> data = [
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   },
        ...   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   }
        ... ]
        >>> expected = ['0.hyperv.0.dns', '0.hyperv.1.dns', '0.vmware.0.dns', '0.vmware.1.dns', '1.hyperv.0.dns', '1.hyperv.1.dns', '1.vmware.0.dns', '1.vmware.1.dns']
        >>> outcome = CollectionUtils.find_keys('dns',data)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> expected = ['dns', 'dns', 'dns', 'dns', 'dns', 'dns', 'dns', 'dns']
        >>> outcome = CollectionUtils.find_keys('dns',data,expand_key_names=False)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> expected = ['0.hyperv', '0.vmware', '1.hyperv', '1.vmware']
        >>> outcome = CollectionUtils.find_keys('.*r.*',data)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        """
        results = []

        def _find_keys(inner_pattern, sub_collection, inner_depth, parentKeyName):
            if inner_depth == 0:
                return
            for index, item_key in enumerate(sub_collection):
                if type(sub_collection) is list and isinstance(
                    item_key, collections.Iterable
                ):
                    if parentKeyName:
                        _find_keys(
                            inner_pattern,
                            item_key,
                            inner_depth - 1,
                            "{}.{}".format(parentKeyName, index),
                        )
                    else:
                        _find_keys(
                            inner_pattern, item_key, inner_depth - 1, "{}".format(index)
                        )
                elif type(sub_collection) is dict:
                    if parentKeyName and expand_key_names:
                        _parentKeyName = "{}.{}".format(parentKeyName, item_key)
                    else:
                        _parentKeyName = "{}".format(item_key)

                    if re.match(inner_pattern, item_key):
                        results.append(_parentKeyName)

                    if isinstance(
                        sub_collection[item_key], collections.Iterable
                    ) and not CollectionUtils.is_json_data_type(
                        sub_collection[item_key]
                    ):
                        _find_keys(
                            inner_pattern,
                            sub_collection[item_key],
                            inner_depth - 1,
                            _parentKeyName,
                        )

        if isinstance(input_collection, collections.Iterable):
            _find_keys(pattern, input_collection, depth, None)

        return results

    @staticmethod
    def find(pattern, input_collection, depth=-1, max_find=-1):
        r"""For given pattern return a list of item matched in collection.

        :param pattern: python regular expression
        :param input_collection: collection which will be searched
        :param depth: How many level deep should it go.
                      Default: -1 means no limit
        :param max_find: Return after n hits. Default: -1 means no limit
        :return: A list of values matched for given pattern

        >>> data =   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   }
        >>> CollectionUtils.find('dns',data)
        ['demo.local', 'demo.local2', 'demo.local', 'demo.local2']
        >>> CollectionUtils.find('dns',data,depth=1)
        []
        >>> CollectionUtils.find('dns',data,depth=2)
        []
        >>> CollectionUtils.find('dns',data,depth=3)
        ['demo.local', 'demo.local2', 'demo.local', 'demo.local2']
        >>> CollectionUtils.find('dns',data,depth=3,max_find=2)
        ['demo.local', 'demo.local2']
        >>> CollectionUtils.find('ip',data,depth=3,max_find=2)
        []
        >>>
        """
        results = []

        def _find(inner_pattern, sub_collection, inner_depth):

            if inner_depth == 0:
                return

            if max_find is not -1 and len(results) == max_find:
                return results

            for item_key in sub_collection:
                if type(sub_collection) is list and isinstance(
                    item_key, collections.Iterable
                ):
                    _find(inner_pattern, item_key, inner_depth - 1)
                elif type(sub_collection) is dict:
                    if re.match(inner_pattern, item_key):
                        results.append(sub_collection[item_key])
                        continue
                    if isinstance(
                        sub_collection[item_key], collections.Iterable
                    ) and not CollectionUtils.is_json_data_type(
                        sub_collection[item_key]
                    ):
                        _find(inner_pattern, sub_collection[item_key], inner_depth - 1)

        if isinstance(input_collection, collections.Iterable):
            _find(pattern, input_collection, inner_depth=depth)
        return results

    @staticmethod
    def find_output_chain(pattern_list, input_collection, max_find=-1, depth=-1):
        r"""Get output of first pattern and feed the output to next.

        :param pattern_list: list of python regular expression
        :param input_collection: collection which will be searched
        :param depth: How many level deep should it go. Default: -1 means no \
            limit
        :param max_find: Return after n hits. Default: -1 means no limit
        :return: A  list of values

        >>> data =   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local",
        ...         "snapshot": {
        ...           "name": "snapname",
        ...           "date": "now"
        ...         }
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   }
        >>> expected = ['snapname', 'demo-linux-vm', 'demo-linux-vm2']
        >>> outcome = CollectionUtils.find_output_chain(['vmware','name'], data)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> expected = ['snapname']
        >>> outcome = CollectionUtils.find_output_chain(['vmware','snapshot','name'], data)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> expected = ['snapname']
        >>> outcome = CollectionUtils.find_output_chain(['snapshot','name'], data)
        >>> CollectionUtils.is_equal(expected, outcome, ignore_order=True)
        True
        >>> expected = ['demo-linux-vm', 'demo-linux-vm2', 'snapname', 'demo-linux-vm', 'demo-linux-vm2']
        >>> outcome = CollectionUtils.find_output_chain(['name'], data)
        >>> CollectionUtils.is_equal(expected, outcome ,ignore_order=True)
        True
        """
        for pattern in pattern_list:
            input_collection = CollectionUtils.find(
                pattern, input_collection, depth=depth, max_find=max_find
            )
        return input_collection

    @staticmethod
    def find_one(pattern, input_collection, error_on_multiple=False, depth=-1):
        r"""For given pattern return single element, raise error on multiple.

        :param pattern: python regular expression
        :param input_collection: collection which will be searched
        :param error_on_multiple: If multiple hit found raise error.
        :param depth: How many level deep should it go. Default: -1 means no \
            limit
        :return: value or None

        >>> data =   {
        ...     "vmware": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local",
        ...         "snapshot": {
        ...           "name": "snapname",
        ...           "date": "now"
        ...         }
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ],
        ...     "hyperv": [
        ...       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local"
        ...       },
        ...       {
        ...         "name": "demo-linux-vm2",
        ...         "dns": "demo.local2"
        ...       }
        ...     ]
        ...   }
        >>> outcome = CollectionUtils.find_one(['vmware', 'snapshot', 'name'], data)
        >>> outcome == 'snapname'
        True
        >>> outcome = CollectionUtils.find_one('name', data)
        >>> outcome in ['demo-linux-vm2', 'demo-linux-vm', 'snapname']
        True
        >>> try:
        ...     CollectionUtils.find_one('name', data, error_on_multiple=True)
        ... except RuntimeError as e:
        ...     'Multiple values found' in str(e)
        True
        >>> try:
        ...     CollectionUtils.find_one('name', data, error_on_multiple=True, depth=3)
        ... except RuntimeError as e:
        ...     'Multiple values found' in str(e)
        True
        """
        max_find = 1
        if error_on_multiple:
            max_find = 2

        if isinstance(pattern, list):
            result = CollectionUtils.find_output_chain(
                pattern, input_collection, depth=depth, max_find=max_find
            )
        else:
            result = CollectionUtils.find(
                pattern, input_collection, depth=depth, max_find=max_find
            )

        if result:
            if error_on_multiple:
                if len(result) > 1:
                    raise RuntimeError("Multiple values found %s" % result)
            return result[0]

        # To handle None or emtpy case
        return None

    @staticmethod
    def is_equal(collection1, collection2, ignore_order=False):
        r"""Return True if given collection is same.

        :param collection1:
        :param collection2:
        :param ignore_order:
        :return: True \ False

        >>> data1 =       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local",
        ...         "snapshot": {
        ...           "name": "snapname",
        ...           "date": "now"
        ...         }
        ...       }
        >>> data2 =       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local",
        ...         "snapshot": {
        ...           "name": "snapname",
        ...           "date": "now"
        ...         }
        ...       }
        >>> CollectionUtils.is_equal(data1,data2)
        True
        >>> data2['name']='changed'
        >>> CollectionUtils.is_equal(data1,data2)
        False
        >>>
        """
        diff = DeepDiff(collection1, collection2, ignore_order=ignore_order)
        if diff:
            return False

        return True

    @staticmethod
    def compare(collection1, collection2, ignore_order=False):
        """Compare two very complex object.

        :param collection1:
        :param collection2:
        :param ignore_order:
        :return: Diff in dict object

        >>> data1 =       {
        ...         "name": "demo-linux-vm",
        ...         "dns": "demo.local",
        ...         "snapshot": {
        ...           "name": "snapname",
        ...           "date": "now"
        ...         }
        ...       }
        >>> data2 =       {
        ...         "name": "changed",
        ...         "dns": "demo.local",
        ...         "snapshot": {
        ...           "name": "snapname",
        ...           "date": "now"
        ...         }
        ...       }
        >>> expected = {'values_changed': {"root['name']": {'new_value': 'changed', 'old_value': 'demo-linux-vm'}}}
        >>> outcome = dict(DeepDiff(data1,data2))
        >>> CollectionUtils.is_equal(expected, outcome)
        True
        >>> data2 = CollectionUtils.copy(data1)
        >>> data1 = CollectionUtils.copy(data1)
        >>> DeepDiff(data1,data2)
        {}
        >>>
        """
        return DeepDiff(collection1, collection2, ignore_order=ignore_order)

    @staticmethod
    def compare_custom(
        collection1, collection2, pattern, is_equal_function=None, sanitize_value=None
    ):
        """Compare a given collection with custom comparisons function.

        :param collection1:
        :param collection2:
        :param pattern: Python regular expression
        :param is_equal_function: Comparision function accepts (c1,c2) return True on match.
                Default is python == operator
        :param sanitize_value: Function to sanitize before comparision
        :return: A list of diff in format key,c1,c2

        >>> c1 =   {
        ...     "name": "demo-linux-vm",
        ...     "dns": "demo.local",
        ...     "size": 100
        ...   }
        >>> c2 =   {
        ...     "name": "demo-linux-vm2",
        ...     "dns": "demo.local2",
        ...     "size": 90
        ...   }
        >>> expected = ([{'c2': 90, 'c1': 100, 'key': 'size'}], [{'c2': 90, 'c1': 100, 'key': 'size'}])
        >>> outcome = CollectionUtils.compare_custom(c1,c2,'size')
        >>> CollectionUtils.is_equal(expected,outcome)
        True
        >>> expected = ([], [{'c2': 90, 'c1': 100, 'key': 'size'}])
        >>> outcome = CollectionUtils.compare_custom(c1,c2,'size',lambda x, y: x-y <=12)
        >>> CollectionUtils.is_equal(expected,outcome)
        True
        >>> expected = ([], [{'c2': 'demo', 'c1': 'demo', 'key': 'dns'}])
        >>> outcome = CollectionUtils.compare_custom(c1,c2,'dns',lambda x, y: x == y, lambda x: x.split('.local')[0])
        >>> CollectionUtils.is_equal(expected,outcome)
        True
        """
        # create a copy
        collection1 = CollectionUtils.copy(collection1)
        collection2 = CollectionUtils.copy(collection2)

        # expand the collection
        collection1 = CollectionUtils.deflate_collection(collection1)
        collection2 = CollectionUtils.deflate_collection(collection2)

        diff = []

        compared_data = []
        for k in collection1.keys():
            if k not in collection1:
                raise RuntimeWarning(
                    "Collections can not be compared,"
                    " key {} does not exist in collection1".format(k)
                )
            if k not in collection2:
                raise RuntimeWarning(
                    "Collections can not be compared,"
                    " key {} does not exist in collection2".format(k)
                )

            if re.match(pattern, k):
                c1 = (
                    sanitize_value(collection1.get(k))
                    if sanitize_value
                    else collection1.get(k)
                )
                c2 = (
                    sanitize_value(collection2.get(k))
                    if sanitize_value
                    else collection2.get(k)
                )

                if is_equal_function:
                    if not is_equal_function(c1, c2):
                        diff.append(dict(key=k, c1=c1, c2=c2))
                else:
                    if c1 != c2:
                        diff.append(dict(key=k, c1=c1, c2=c2))

                compared_data.append(dict(key=k, c1=c1, c2=c2))

        return diff, compared_data

    @staticmethod
    def ensure_is_list(data):
        """Wrap the data in a list if it's not a list.

        :param data: anything
        :type data: any type
        :return: data itself if it's list already, otherwise data wrapped in
        list
        :rtype: list
        """
        if not isinstance(data, list):
            return [data]
        return data

    # TODO(Estifanos) Check if complete mapping is required??
    @staticmethod
    def transform_dict_keys(originalData, keyMap):
        """Transform original dict with key mapping .

        :param data: dict
        :type keyMap: dict
        :return: @originalData with key transformed according to @keyMap
        :rtype: dict

        >>> data =   {
        ...     "val1": "val1",
        ...     "val2": "val2",
        ...   }
        >>> keyMap =   {
        ...     "val1": "value1",
        ...   }
        >>> expected =   {
        ...     "value1": "val1",
        ...     "val2": "val2",
        ...   }
        >>> outcome = CollectionUtils.transform_dict_keys(data,keyMap)
        >>> CollectionUtils.is_equal(expected,outcome)
        True
        """
        for key, val in originalData.items():
            newKey = keyMap.get(key)
            if newKey:
                originalData[newKey] = originalData.pop(key)
        return originalData

    @staticmethod
    def ensure_is_string(data):
        """Covert given input to string.

        :param data: dict
        :return: Returns string repr of the given input
        :rtype: str
        """
        if CollectionUtils.is_json_data_type(data):
            if data is None:
                return ""
            else:
                return str(data)
        return yaml.safe_dump(data)


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
