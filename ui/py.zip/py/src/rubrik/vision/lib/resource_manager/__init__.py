"""
   Module to handle resource management logic.

    Modules:
       base_resource_manager: Base manager specify Interface design pattern.
       dc_resource_pool_manager: Module  to provision resource pools on a given datacenter.
       dc_vdu_manager:  Module to provision virtual datacenters in a given datacenter.
       resource_manager: Module to provision a single resource. 
       resource_pool_resource_manager: Module to manage resources in a given resource pool.
       vdu_resource_pool_manager: Module to manage resource pools in a given virtual datacenter.
       exceptions: exceptions module.

    Desing Patterns Used:
        Interface design pattern: All Managers  implements common interface.
        Delegate design pattern: Managers  delegates aggregation to child managers.
        Strategy design pattern: While inforcing the interface design pattern,
            sub modules may override different strategy to provision/calculate resource capacity.
"""
