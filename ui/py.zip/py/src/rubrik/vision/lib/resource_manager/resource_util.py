import enum
from rubrik.vision.lib.resource_manager import exceptions as resource_exceptions


class ReservationType(enum.Enum):
    RESERVE = "RESERVE"
    RELEASE = "RELEASE"


def aggregate_dict(data):
    """
    Aggregate list of dict according to aggregate_type.

    Input: [
            {'property_name': VmwareComputeCluster__CpuCores, 'property_value': 1, 'aggregate_type': 'Sum'},
            {'property_name': VmwareComputeCluster__CpuCores, 'property_value': 1, 'aggregate_type': 'Sum'},
            {'property_name': VmwareComputeCluster__Memory, 'property_value': 1, 'aggregate_type': 'Sum'},
            {'property_name': VmwareComputeCluster__Memory, 'property_value': 1, 'aggregate_type': 'Sum'},
            {'property_name': VmwareComputeCluster__Memory, 'property_value': 1, 'aggregate_type': 'Sum'},
            {'property_name': VmwareComputeCluster__NetworkLabWan, 'property_value': 1,  'aggregate_type': 'Sum'},
            {'property_name': VmwareComputeCluster__NetworkLabLan, 'property_value': 1,  'aggregate_type': 'Sum'},
    ]
    Output:
            {'VmwareComputeCluster__CpuCores': 2, 'VmwareComputeCluster__Memory': 3,
            'VmwareComputeCluster__NetworkLabWan': 1, 'VmwareComputeCluster__NetworkLabLan': 1}
    """
    agg_value = {}
    agg_type = {}
    for datum in data:
        property_name = datum["property_name"]
        property_value = datum["property_value"]
        aggregate_type = datum["aggregate_type"]

        if not agg_value.get(property_name):
            agg_value[property_name] = []
        if isinstance(property_value, list):
            agg_value[property_name].extend(property_value)
        else:
            agg_value[property_name].append(property_value)
        if not agg_type.get(property_name):
            agg_type[property_name] = aggregate_type
        if agg_type[property_name] != aggregate_type:
            raise resource_exceptions.ConflictingAggregationMethod(
                "{} {} {}".format(
                    property_name, agg_type[property_name], aggregate_type
                )
            )
        agg_type[property_name] = aggregate_type
    for value in agg_value:
        if agg_type[value] == "Sum":
            agg_value[value] = sum(agg_value[value])
        if agg_type[value] == "Unique":
            agg_value[value] = list(set(agg_value[value]))
    return agg_value
