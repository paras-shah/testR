from rubrik.vision.core import models
from rubrik.vision.lib.resource_manager import resource_util
import copy

class Resource:
    """
             Single Resource  Object constructed from request_param.

             - Constructs  Resource  fron json data for @models.ResourceRequestReservation.request_params
             - Validates Data

            Attr:
                request_params.requirements[0]:  valid data convertable to  @models.Resource
                {
                            'virtual_datacenter_unit': '00000000-0000-0000-0000-000000000000',
                            'ResourceType': 'VmwareComputeCluster',
                            'name': 'gateway',
                            'is_provisioned': false,
                            'CpuCores': {'size': 1024, 'unit': 'Hz' },
                            'Memory': {'size': 1024, 'unit': 'Mb'},
                            'Disk': {'size': 1024, 'unit': 'Mb'},
                            'NetworkLabLan': {'size': 2, 'unit': 'port', type: 'network'},
                            'NetworkLabWan': {'size': 1, 'unit': 'port'},
                }
                resource_properties_data : Massaged value of property:
                [
                    {property_name: CpuCores, property_value: 1, aggregate_type: Sum},
                    {property_name: Memory, property_value: 1, aggregate_type: Sum},
                    {property_name: Disk, property_value: 1, aggregate_type: Sum},
                    {property_name: NetworkLabLan, property_value: 1, aggregate_type: Sum},
                    {property_name: NetworkLabWan, property_value: 1, aggregate_type: Sum}
                ]
    """

    def __init__(self, request_params):
        self._request_params = request_params
        self._is_provisioned = None
        self._resource_name = None
        self._resource = None
        self._resource_properties = []
        self._resource_properties_data = []
        self._init_data()
        self.validate()

    def _init_data(self):
        _request_params = copy.deepcopy(self._request_params)
        resource_type = models.EntityType.objects.get(
            name=_request_params.pop('ResourceType'),
            family='ResourceType')
        self._resource_name = _request_params.pop('name')
        self._virtual_datacenter_unit = _request_params.pop('virtual_datacenter_unit')
        self._is_provisioned = _request_params.get(
            'is_provisioned') and  _request_params.pop('is_provisioned')
        if  self._is_provisioned:
             self._resource = models.Resource.objects.get(resource_type=resource_type)
        else:
            self._resource = models.Resource(name=self._resource_name, resource_type=resource_type)

        for prop, value in _request_params.items():
            resource_property_type = models.ResourcePropertyType.objects.get(
                name__name=prop, name__family="ResourcePropertyTypes"
            )
            _rp = models.ResourceProperty(
                resource_property_type=resource_property_type,
                value={"value": value["size"]},
            )
            self._resource_properties.append(_rp)
            self._resource_properties_data.append(
                {
                    "property_name": "{}__{}".format(resource_type.name, prop),
                    "property_value": value["size"],
                    "aggregate_type": resource_property_type.aggregate_type.name,
                }
            )

    @property
    def resource(self):
        return self._resource

    @property
    def resource_name(self):
        return self._resource_name

    @property
    def resource_properties_data(self):
        return self._resource_properties_data

    def validate(self):
        pass

    def update_resource(self, resource_pool=None, state=None, status=None):
        self._resource.resource_pool = resource_pool or self._resource.resource_pool
        self._resource.state = state or self._resource.state
        self._resource.status = status or self._resource.status

    def save(self):
        if  self._is_provisioned:
            return
        self._resource.save()
        for r_p in self._resource_properties:
            r_p.resource = self.resource
            r_p.save()


class ResourceReservationRequest:
    """
             Resource Reservation Request.

             - Loads resource_request_reservation from @models.ResourceRequestReservation
             - Validates Data

            Attr:
                resource_request_reservation_id:   @models.ResourceRequestReservation_id

                resource_request_reservation.request_params:
                {   
                    requirements: [ 
                        {
                            'virtual_datacenter_unit': '00000000-0000-0000-0000-000000000000',
                            'ResourceType': 'VmwareComputeCluster',
                            'name': 'gateway',
                            'CpuCores': {'size': 1024, 'unit': 'Hz' },
                            'Memory': {'size': 1024, 'unit': 'Mb'},
                            'Disk': {'size': 1024, 'unit': 'Mb'},
                            'NetworkLabLan': {'size': 2, 'unit': 'port', type: 'network'},
                            'NetworkLabWan': {'size': 1, 'unit': 'port'},
                        },
                        {
                            'virtual_datacenter_unit': '00000000-0000-0000-0000-000000000000',
                            'ResourceType': 'VmwareComputeCluster',
                            'name': 'gateway',
                            'CpuCores': {'size': 1024, 'unit': 'Hz' },
                            'Memory': {'size': 1024, 'unit': 'Mb'},
                            'Disk': {'size': 1024, 'unit': 'Mb'},
                            'NetworkLabWan': {'size': 1, 'unit': 'port'},
                        }
                    ]
                }
    """

    def __init__(self, resource_request_reservation_id):
        self._resource_request_reservation_id = resource_request_reservation_id
        self._resources = []
        self._resource_reservations = []
        self._init_data()
        self._compute_aggregate_values()
        self.validate()

    def _init_data(self):
        self._resource_request_reservation = models.ResourceReservationRequest.objects.get(
            id=self._resource_request_reservation_id)
        for resource_data in self._resource_request_reservation.request_params['requirements']:
            resource_data.get('virtual_datacenter_unit')
            self.add_resource(resource_data)
        self._compute_aggregate_values()

    def _compute_aggregate_values(self):
        resource_properties_data = []
        for res in self._resources:
            resource_properties_data.extend(res.resource_properties_data)
        agg_value = resource_util.aggregate_dict(resource_properties_data)
        self._resource_request_reservation.data = (
            self._resource_request_reservation.data or {}
        )
        self._resource_request_reservation.data["aggregate_values"] = agg_value

    @property
    def resource_request_reservation(self):
        return self._resource_request_reservation

    @property
    def aggregate_values(self):
        return self._resource_request_reservation.data.get("aggregate_values")

    def add_resource(self, resource_data):
        self._resources.append(Resource(resource_data))

    def validate(self):
        for res in self._resources:
            res.validate()

    def save(self, resource_pool, rrrStatus):
        self._resource_request_reservation.data["resource_pool_id"] = str(
            resource_pool.id
        )
        self._resource_request_reservation.status = rrrStatus
        self._resource_request_reservation.save()
        rState = models.EntityType.objects.get(
            name="Available", family="ResourceStatus"
        )
        rStatus = models.EntityType.objects.get(
            name="Allocated", family="ResourceState"
        )
        for r_s in self._resources:
            r_s.update_resource(
                resource_pool=resource_pool, state=rState, status=rStatus
            )
            r_s.save()
            models.ResourceReservation(
                resource_reservation_request=self.resource_request_reservation,
                resource=r_s.resource, resource_reservation_name=r_s.resource_name).save()

    @classmethod
    def release_resource(cls, resource_request_reservation_id):
        resource_request_reservation = models.ResourceReservationRequest.objects.get(
            id=resource_request_reservation_id
        )
        resource_reservations = models.ResourceReservation.objects.filter(
            resource_reservation_request=resource_request_reservation)

        if resource_request_reservation.status.name != "PendingRelease":
            rrrStatus = models.EntityType.objects.get(
                name='PendingRelease', family='ReservationStatus')
            resource_request_reservation.status = rrrStatus
            resource_request_reservation.save()

        rrrStatus = models.EntityType.objects.get(
            name='Released', family='ReservationStatus')
        resource_request_reservation.status = rrrStatus
        resource_request_reservation.save()
        # TODO (Estifanos) See into moving status to reserve from resource.

