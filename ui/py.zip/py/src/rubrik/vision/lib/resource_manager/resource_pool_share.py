from django.db.models import Q
from rubrik.vision.core import models
from rubrik.vision.lib.resource_manager import exceptions
from rubrik.vision.lib.resource_manager.resource_util import ReservationType


class ResourcePoolShare:
    """
       Resource Pool Share handler.

       Attribute:
           virtual_datacenter_unit_id: virtual_datacenter_unit,
           data: Aggregated data
             {'VmwareComputeCluster__CpuCores': 2, 'VmwareComputeCluster__Memory': 3, 'VmwareComputeCluster__NetworkLabWan'
    """

    def __init__(self, virtual_datacenter_unit_id, aggregate_values):
        self.virtual_datacenter_unit = models.VirtualDataCenterUnit.objects.get(
            id=virtual_datacenter_unit_id)
        self.aggregate_values = aggregate_values
        self._resource_pool = None
        self._resource_pools = None
        self.query_objs = []
        self._init_data()
        self._fetch_available_resource_pool()

    def _init_data(self):
        for key, value in self.aggregate_values.items():
            rt, rpt = key.split("__")
            self.query_objs.append(
                {
                    "resource_type__name": rt,
                    "resource_property_type__name": rpt,
                    "value": value,
                }
            )

    def _fetch_available_resource_pool(self):
        rpQuery = models.ResourcePool.objects.filter(
            resource_pool_share__virtual_datacenter_unit=self.virtual_datacenter_unit
        )
        for query in self.query_objs:
            _q = Q(
                resource_pool_share__virtual_datacenter_unit=self.virtual_datacenter_unit,
                resource_pool_share__resource_type__name=query["resource_type__name"],
                resource_pool_share__resource_property_type__name__name=query[
                    "resource_property_type__name"
                ],
                resource_pool_share__free_capacity__gte=query["value"],
                resource_pool_capacity__resource_type__name=query[
                    "resource_type__name"
                ],
                resource_pool_capacity__resource_property_type__name__name=query[
                    "resource_property_type__name"
                ],
                resource_pool_capacity__free_capacity__gte=query["value"],
            )
            rpQuery = rpQuery.filter(_q)
        self._resource_pools = [r for r in rpQuery if rpQuery]
        self._resource_pool = self._resource_pools and self._resource_pools[0]

    def update_resource_pool_capacity(self, reservationType):
        """ Update resource pool capacity / resource pool share capacitywith the Reserved aggregated data."""
        for query in self.query_objs:
            _q = Q(
                resource_pool=self.resource_pool,
                resource_type__name=query["resource_type__name"],
                resource_property_type__name__name=query[
                    "resource_property_type__name"
                ],
            )

            rpCQ = models.ResourcePoolCapacity.objects.get(_q)
            if reservationType == ReservationType.RESERVE:
                rpCQ.used_capacity += query["value"]
                rpCQ.free_capacity -= query["value"]
            if reservationType == ReservationType.RELEASE:
                rpCQ.used_capacity -= query["value"]
                rpCQ.free_capacity += query["value"]
            rpCQ.save()

    def update_resource_pool_share_capacity(self, reservationType):
        """ Update resource pool share capacity / resource pool share capacitywith the Reserved aggregated data."""
        for query in self.query_objs:
            _q = Q(
                virtual_datacenter_unit=self.virtual_datacenter_unit,
                resource_pool=self.resource_pool,
                resource_type__name=query['resource_type__name'],
                resource_property_type__name__name=query['resource_property_type__name'])

            rpCQ = models.ResourcePoolShare.objects.get(_q)
            if reservationType == ReservationType.RESERVE:
                rpCQ.used_capacity += query['value']
                rpCQ.free_capacity -= query['value']
            if reservationType == ReservationType.RELEASE:
                rpCQ.used_capacity -= query['value']
                rpCQ.free_capacity += query['value']
            rpCQ.save()

    def reserve_resource_pool(self):
        self._fetch_available_resource_pool()
        if not self.resource_pool:
            raise exceptions.OutOfCapacity("No Resource Pool found.")
        self.update_resource_pool_capacity(ReservationType.RESERVE)
        self.update_resource_pool_share_capacity(ReservationType.RESERVE)
        return self.resource_pool

    def reslease_resource_pool(self, reserve_resource_pool_id):
        self._resource_pool = models.ResourcePool.objects.get(
            id=reserve_resource_pool_id
        )
        self.update_resource_pool_capacity(ReservationType.RELEASE)
        self.update_resource_pool_share_capacity(ReservationType.RELEASE)
        return self.resource_pool

    @property
    def resource_pool(self):
        return self._resource_pool

    @property
    def resource_pools(self):
        return self._resource_pools
