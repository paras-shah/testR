class UnknownResourceType(Exception):
    pass


class UnknownAggregationMethod(Exception):
    pass


class ConflictingAggregationMethod(Exception):
    pass


class CanNotProcessRequest(Exception):
    pass


class OutOfCapacity(Exception):
    pass


class InvalidResourceQuotaUsageReport(Exception):
    pass


class UnsupportedVDUReservationResource(Exception):
    pass
