from rubrik.vision.core import models
from rubrik.vision.lib.resource_manager import resource_request_reservation
from rubrik.vision.lib.resource_manager import resource_pool_share
from rubrik.vision.lib.resource_manager import exceptions as resource_exceptions
from rubrik.vision.lib.collections_utils import CollectionUtils


class ResourceRequestProcessor:
    """
        Interface to process incoming request to reserve/release resources.
    """

    @classmethod
    def reserve_resource(cls, request_reservation_id):
        """
          Process request to reserve a resoruce.

          Retrieve ResourceReservationRequest by request_reservation_id.
                {
                    requirements: [
                        {
                            'virtual_datacenter_unit': '00000000-0000-0000-0000-000000000000',
                            'ResourceType': 'VmwareComputeCluster',
                            'is_provisioned' : 'false',
                            'name': 'gateway',
                            'CpuCores': {'size': 1024, 'unit': 'Hz' },
                            'Memory': {'size': 1024, 'unit': 'Mb'},
                            'Disk': {'size': 1024, 'unit': 'Mb'},
                            'NetworkLabLan': {'size': 2, 'unit': 'port', type: 'network'},
                            'NetworkLabWan': {'size': 1, 'unit': 'port'},
                        },
                        {
                            'virtual_datacenter_unit': '00000000-0000-0000-0000-000000000000',
                            'ResourceType': 'VmwareComputeCluster',
                            'is_provisioned' : 'false',
                            'name': 'gateway',
                            'CpuCores': {'size': 1024, 'unit': 'Hz' },
                            'Memory': {'size': 1024, 'unit': 'Mb'},
                            'Disk': {'size': 1024, 'unit': 'Mb'},
                            'NetworkLabWan': {'size': 1, 'unit': 'port'},
                        }
                    ]
                }

          Returns:
             @models.ResourceReservationRequest.id
        """
        r_r_r_obj = models.ResourceReservationRequest.objects.get(
            id=request_reservation_id
        )
        r_r_r = resource_request_reservation.ResourceReservationRequest(r_r_r_obj.id)
        collectionUtils = CollectionUtils()

        vdus = set(collectionUtils.find('virtual_datacenter_unit', r_r_r_obj.request_params))

        if not vdus or len(vdus) != 1:
            raise resource_exceptions.UnsupportedVDUReservationResource()
        r_p_s = resource_pool_share.ResourcePoolShare(
            virtual_datacenter_unit_id=vdus.pop(),
            aggregate_values=r_r_r.aggregate_values,
        )
        r_p_s.reserve_resource_pool()
        status = models.EntityType.objects.get(
            name="Reserved", family="ReservationStatus"
        )
        r_r_r.save(r_p_s.resource_pool, status)

    @classmethod
    def release_resource(cls, request_reservation_id):
        """
          Process Release Resource, which were previously reserved
          through ResourceRequestProcessor.reserve_resource

          ResourceReservationRequest.data {
           resource_pool_id: UUID,
           ....
         }
        """

        r_r_r_obj = models.ResourceReservationRequest.objects.get(
            id=request_reservation_id)
        collectionUtils = CollectionUtils()
        vdus = set(collectionUtils.find('virtual_datacenter_unit', r_r_r_obj.request_params))

        if not vdus or len(vdus) != 1:
            raise resource_exceptions.UnsupportedVDUReservationResource()
        r_p_s = resource_pool_share.ResourcePoolShare(
             virtual_datacenter_unit_id=vdus.pop(),
             aggregate_values=r_r_r_obj.data['aggregate_values'])
        r_p_s.reslease_resource_pool(r_r_r_obj.data['resource_pool_id'])
        resource_request_reservation.ResourceReservationRequest.release_resource(
            request_reservation_id
        )
