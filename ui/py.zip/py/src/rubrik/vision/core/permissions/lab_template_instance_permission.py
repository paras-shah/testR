from rubrik.vision.core.permissions.base_permission import BasePermission
from rubrik.vision.core.permissions.permission_enums import LabTemplatePermissions
from rubrik.vision.core.permissions.permission_enums import (
    LabTemplateInstancePermissions,
)


class LabTemplateInstancePermission(BasePermission):
    perms_map = {
        "GET": [LabTemplateInstancePermissions.can_read_labtemplateinstance.name],
        "POST": [
            LabTemplateInstancePermissions.can_create_labtemplateinstance.name,
            LabTemplatePermissions.can_read_labtemplate.name,
            LabTemplatePermissions.can_consume_resource.name,
        ],
        "PUT": [LabTemplateInstancePermissions.can_update_labtemplateinstance.name],
        #'DELETE': [LabTemplateInstancePermissions.can_update_labtemplateinstance.name],
    }
