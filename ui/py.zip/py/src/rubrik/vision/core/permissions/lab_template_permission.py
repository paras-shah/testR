from rubrik.vision.core.permissions.base_permission import BasePermission
from rubrik.vision.core.permissions.permission_enums import LabTemplatePermissions


class LabTemplatePermission(BasePermission):
    perms_map = {
        "GET": [LabTemplatePermissions.can_read_labtemplate.name],
        # 'POST': [],
        # 'PATCH': [],
        # 'DELETE': [],
    }
