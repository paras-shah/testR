from rubrik.vision.core.permissions.base_permission import BasePermission
from rubrik.vision.core.permissions.permission_enums import (
    VirtualDataCenterUnitPermissions,
)


class VirtualDataCenterUnitPermission(BasePermission):
    perms_map = {
        "GET": [VirtualDataCenterUnitPermissions.can_read_virtualdatacenterunit.name],
        # 'POST': [],
        # 'PATCH': [],
        # 'DELETE': [],
    }
