import enum


@enum.unique
class VirtualDataCenterUnitPermissions(enum.Enum):
    can_create_virtualdatacenterunit = "Create VDU"
    can_read_virtualdatacenterunit = "Read VDU"
    can_update_virtualdatacenterunit = "Update VDU"
    can_delete_virtualdatacenterunit = "Delete VDU"


@enum.unique
class LabTemplatePermissions(enum.Enum):
    can_create_labtemplate = "Create LabTemplate"
    can_read_labtemplate = "Read LabTemplate"
    can_update_labtemplate = "Update LabTemplate"
    can_delete_labtemplate = "Delete LabTemplate"
    can_consume_resource = "Consume Resource"


@enum.unique
class LabTemplateInstancePermissions(enum.Enum):
    can_create_labtemplateinstance = "Create LabTemplateInstance"
    can_read_labtemplateinstance = "Read LabTemplateInstance"
    can_update_labtemplateinstance = "Update LabTemplateInstance"
    can_delete_labtemplateinstance = "Delete LabTemplateInstance"
