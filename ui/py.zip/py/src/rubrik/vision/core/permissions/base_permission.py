from rest_framework import permissions
from rest_framework import exceptions
from django.http import Http404


class BasePermission(permissions.BasePermission):

    perms_map = {"GET": [], "POST": [], "PATCH": [], "DELETE": []}
    authenticated_users_only = True

    def _queryset(self, view):
        assert (
            hasattr(view, "get_queryset") or getattr(view, "queryset", None) is not None
        ), (
            "Cannot apply {} on a view that does not set "
            "`.queryset` or have a `.get_queryset()` method."
        ).format(
            self.__class__.__name__
        )

        if hasattr(view, "get_queryset"):
            queryset = view.get_queryset()
            assert queryset is not None, "{}.get_queryset() returned None".format(
                view.__class__.__name__
            )
            return queryset
        return view.queryset

    def get_required_permissions(self, method, model_cls):
        """
        Given a model and an HTTP method, return the list of permission
        codes that the user is required to have.
        """
        if method not in self.perms_map:
            raise exceptions.MethodNotAllowed(method)

        return ["core.{0}".format(perm) for perm in self.perms_map[method]]

    def get_required_object_permissions(self, method, model_cls):
        return self.get_required_permissions(method, model_cls)

    def has_permission(self, request, view):
        """
        Return `True` if permission is granted, `False` otherwise.
        """
        if not request.user or (
            not request.user.is_authenticated and self.authenticated_users_only
        ):
            return False

        queryset = self._queryset(view)
        perms = self.get_required_permissions(request.method, queryset.model)
        return request.user.has_perms(perms)

    def has_object_permission(self, request, view, obj):
        # authentication checks have already executed via has_permission
        SAFE_METHODS = ()
        queryset = self._queryset(view)
        model_cls = queryset.model

        perms = self.get_required_object_permissions(request.method, model_cls)

        if not request.user.has_perms(perms, obj):
            # If the user does not have permissions we need to determine if
            # they have read permissions to see 403, or not, and simply see
            # a 404 response.

            if request.method in SAFE_METHODS:
                # Read permissions already checked and failed, no need
                # to make another lookup.
                raise Http404

            read_perms = self.get_required_object_permissions("GET", model_cls)
            if not request.user.has_perms(perms, obj):
                raise Http404

            # Has read permissions.
            return False

        return True
