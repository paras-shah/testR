from guardian.shortcuts import assign_perm
from guardian.shortcuts import remove_perm
from guardian.shortcuts import get_group_perms
from django.contrib.auth.models import Group
from django.contrib.auth.models import Permission
from rubrik.vision.core.models import virtual_data_center_unit
from rubrik.vision.core.models import lab_template
from rubrik.vision.core.models import lab_template_instance
from rubrik.vision.core.permissions import permission_enums


def get_permission_vdu_owners_group():
    permissions = [
        # VirtualDataCenterUnit Perms
        Permission.objects.get(
            codename=permission_enums.VirtualDataCenterUnitPermissions.can_read_virtualdatacenterunit.name,
            content_type__model=virtual_data_center_unit.VirtualDataCenterUnit._meta.model_name,
            content_type__app_label=virtual_data_center_unit.VirtualDataCenterUnit._meta.app_label,
        )
    ]
    return permissions


def get_permission_vdu_members_group():
    permissions = [
        # VirtualDataCenterUnit Perms
        Permission.objects.get(
            codename=permission_enums.VirtualDataCenterUnitPermissions.can_read_virtualdatacenterunit.name,
            content_type__model=virtual_data_center_unit.VirtualDataCenterUnit._meta.model_name,
            content_type__app_label=virtual_data_center_unit.VirtualDataCenterUnit._meta.app_label,
        ),
        # LabTemplate Perms
        Permission.objects.get(
            codename=permission_enums.LabTemplatePermissions.can_read_labtemplate.name,
            content_type__model=lab_template.LabTemplate._meta.model_name,
            content_type__app_label=lab_template.LabTemplate._meta.app_label,
        ),
        Permission.objects.get(
            codename=permission_enums.LabTemplatePermissions.can_consume_resource.name,
            content_type__model=lab_template.LabTemplate._meta.model_name,
            content_type__app_label=lab_template.LabTemplate._meta.app_label,
        ),
        # LabTemplateInstance Perms
        Permission.objects.get(
            codename=permission_enums.LabTemplateInstancePermissions.can_read_labtemplateinstance.name,
            content_type__model=lab_template_instance.LabTemplateInstance._meta.model_name,
            content_type__app_label=lab_template_instance.LabTemplateInstance._meta.app_label,
        ),
        Permission.objects.get(
            codename=permission_enums.LabTemplateInstancePermissions.can_create_labtemplateinstance.name,
            content_type__model=lab_template_instance.LabTemplateInstance._meta.model_name,
            content_type__app_label=lab_template_instance.LabTemplateInstance._meta.app_label,
        ),
        Permission.objects.get(
            codename=permission_enums.LabTemplateInstancePermissions.can_update_labtemplateinstance.name,
            content_type__model=lab_template_instance.LabTemplateInstance._meta.model_name,
            content_type__app_label=lab_template_instance.LabTemplateInstance._meta.app_label,
        ),
    ]
    return permissions


def get_permission_vdu_members_group_for_lab_template_obj():
    permissions = [
        # LabTemplate Perms
        Permission.objects.get(
            codename=permission_enums.LabTemplatePermissions.can_read_labtemplate.name,
            content_type__model=lab_template.LabTemplate._meta.model_name,
            content_type__app_label=lab_template.LabTemplate._meta.app_label,
        ),
        Permission.objects.get(
            codename=permission_enums.LabTemplatePermissions.can_consume_resource.name,
            content_type__model=lab_template.LabTemplate._meta.model_name,
            content_type__app_label=lab_template.LabTemplate._meta.app_label,
        ),
    ]
    return permissions


def get_permission_vdu_members_group_for_lab_template_instance_obj():
    permissions = [
        # LabTemplateInstance Perms
        Permission.objects.get(
            codename=permission_enums.LabTemplateInstancePermissions.can_read_labtemplateinstance.name,
            content_type__model=lab_template_instance.LabTemplateInstance._meta.model_name,
            content_type__app_label=lab_template_instance.LabTemplateInstance._meta.app_label,
        ),
        Permission.objects.get(
            codename=permission_enums.LabTemplateInstancePermissions.can_update_labtemplateinstance.name,
            content_type__model=lab_template_instance.LabTemplateInstance._meta.model_name,
            content_type__app_label=lab_template_instance.LabTemplateInstance._meta.app_label,
        ),
    ]
    return permissions


def get_permission_vdu_owners_group_for_vdu_obj():
    permissions = [
        # VirtualDataCenterUnit Perms
        Permission.objects.get(
            codename=permission_enums.VirtualDataCenterUnitPermissions.can_read_virtualdatacenterunit.name,
            content_type__model=virtual_data_center_unit.VirtualDataCenterUnit._meta.model_name,
            content_type__app_label=virtual_data_center_unit.VirtualDataCenterUnit._meta.app_label,
        )
    ]
    return permissions


def get_permission_vdu_members_group_for_vdu_obj():
    permissions = [
        # VirtualDataCenterUnit Perms
        Permission.objects.get(
            codename=permission_enums.VirtualDataCenterUnitPermissions.can_read_virtualdatacenterunit.name,
            content_type__model=virtual_data_center_unit.VirtualDataCenterUnit._meta.model_name,
            content_type__app_label=virtual_data_center_unit.VirtualDataCenterUnit._meta.app_label,
        )
    ]
    return permissions


def add_permission_to_vdu_owners_group(group_obj):
    for perm in get_permission_vdu_owners_group():
        group_obj.permissions.add(perm)


def add_permission_to_vdu_members_group(group_obj):
    for perm in get_permission_vdu_members_group():
        group_obj.permissions.add(perm)


def add_vdu_owners_group_on_vdu_obj(group_obj, vdu_obj):
    for perm in get_permission_vdu_owners_group_for_vdu_obj():
        assign_perm(perm, group_obj, vdu_obj)


def add_vdu_members_group_on_vdu_obj(group_obj, vdu_obj):
    for perm in get_permission_vdu_members_group_for_vdu_obj():
        assign_perm(perm, group_obj, vdu_obj)


def create_owners_group_for_vdu(vdu):
    group_name_owner = "vdu_owners__{0}".format(vdu.id)
    group_owner, _ = Group.objects.get_or_create(name=group_name_owner)
    # Reset Group perms
    group_owner.permissions.clear()
    for perm in get_group_perms(group_owner, vdu):
        remove_perm(perm, group_owner, vdu)

    # Add perms owners
    add_permission_to_vdu_owners_group(group_owner)
    add_vdu_owners_group_on_vdu_obj(group_owner, vdu)


def create_members_group_for_vdu(vdu):
    group_name_member = "vdu_member__{0}".format(vdu.id)
    group_member, _ = Group.objects.get_or_create(name=group_name_member)
    # Remover group perms from obj
    group_member.permissions.clear()
    for perm in get_group_perms(group_member, vdu):
        remove_perm(perm, group_member, vdu)

    # Add perms members
    add_permission_to_vdu_members_group(group_member)
    add_vdu_members_group_on_vdu_obj(group_member, vdu)


def create_groups_for_vdu(vdu):
    create_owners_group_for_vdu(vdu)
    create_members_group_for_vdu(vdu)


def add_staff_users_to_all_vdu(users, default_password=None):
    from django.contrib.auth.models import User, Group

    for user in set(users):
        user = user.split("<")[-1].split(">")[0]
        if not User.objects.filter(username=user).first():
            if default_password:
                user = User.objects.create_user(
                    username=user, email=user, password=default_password
                )
                user.is_staff = True
                user.groups.add(Group.objects.get(name="rcf_staff"))
                user.save()
            else:
                raise RuntimeError("Default password required for creating user")
        else:
            user = User.objects.get(username=user)

        # Add them as owner to all groups
        for vdu in virtual_data_center_unit.VirtualDataCenterUnit.objects.filter().iterator():
            user.groups.add(Group.objects.get(name="vdu_owners__{0}".format(vdu.id)))
            user.groups.add(Group.objects.get(name="vdu_member__{0}".format(vdu.id)))


def add_vdu_members_to_lab_templates(vdu):
    group_name_member = "vdu_member__{0}".format(vdu.id)
    group_member, _ = Group.objects.get_or_create(name=group_name_member)
    for l_t in lab_template.LabTemplate.objects.filter(virtualdatacenterunit=vdu).iterator():
        for perm in get_permission_vdu_members_group_for_lab_template_obj():
            assign_perm(perm, group_member, l_t)
