import base64
import logging
import os
import re

import jsonpath_rw_ext
import plumbum
import yaml
from celery import shared_task
from celery_once import QueueOnce
from django.db import transaction

from rubrik.vision.core.models import EntityType
from rubrik.vision.core.models import LabTemplate
from rubrik.vision.core.models import LabTemplateRepo
from rubrik.vision.core.models import VirtualDataCenterUnit
from rubrik.vision.core.models import VirtualDataCenterUnitLinkLabTemplateRepo
from rubrik.vision.lib.git import get_change_set

log = logging.getLogger(__name__)
RUBRIK_LOGO = "data:image/svg+xml;base64,iVBORw0KGgoAAAANSUhEUgAAARQAAAEUCAYAAADqcMl5AAAABGdBTUEAALGOfPtRkwAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAABFKADAAQAAAABAAABFAAAAACW05W5AAApeElEQVR4Ae2d6ZMbx3nGAcbfBd6RKJdBx3HuZFVJ7PK3RcX5JIlcyiIpu1IRtmLncCqRmKRyVJKiWHYqdyRVlEocxwZkxwe5irhLSh+dXX+zY8uCrzh2DiJFSrIoioL/gWye9337RQ+wWCyOATDAPL21c/T09PHr7mfe7pnBFAp0JEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACJEACGSNQzFh+mJ0MEShdfaq0XSg8jiyVtwvFwr5CsYntc637P9jKUDaZlQwRoKBkqDKylBURE+RnE4KyVICYyJ84CEsTq1Pfu//XGrJPRwJJAhSUJA1uK4E+YuKEYKEUK9+7/1cpKk6EayWwjxxIIElgADFB8GKpuF3cLF39CKwXOhKIBGihRBaZ3rrz+T9ZRkdGBy6uv3LvHzQnkdkBxaQAMUE2JAdFWCqFSuv+X56IpXJo49NlxL+MpJqvnXzfFrbpMk6AgpLxCrrz+Q9XkcXz6LzlAqZF4dCJi/e8cu/vN2UnLTeCmGjSxW3NT+WNEx9IVVSCmLyIBloK6tXEPM6FmycfqqdVZsaTPgEKSvpMx44RIoJOVHgU/w/jv2wdKoxOzTq4AEF5DMdScWOICdLX6doW1pXbJ97fSCVDiASC8hgapwgpJoJFSq2pwjpqYv9p+D9xc+UM0qXLEgHOoWSoNu56/kMl/D+GLF3DPzpTTzGBt3UubIztUhAT5KFYwmLz4JWPLY2doRBBkI9uMZH9MtITNteOrK89dnR9TdKmywgBCkoGKgIiUsZ/DVm5htuy0llCJ5Fu1WGZYD9zYoI8Sa6K8szK5oErH09JVHZYJiousfyYGDbRvXZ0/ZnakfV/KWtGuJgpAQrKTPEXChCSKrJwDf9ViEniattPTMYXlZQsE2RbxcQ7O/JfhKjUUhGVxDDH49f0LMWwCfGFkFVB5Nr3rz9bbftyYyYEKCgzwW6JimWCrZrsyZOo0fUXk230oHEcxEQ6/IuIBmuZA7G0u/OQuJujyWECFs5D2zmyZ9mRffXDLWUZ/tTHEpV2KpgzivEn05dt4yZh5Q+NuXbX+rMlO8LlLAhQUGZBPaZZls3ujrz7MAedC72rM3yMbJCtICbyBGx5AmJSUNEp+vDnEyOLisQjgjaEmITiy611ulkRoKDMiryl24A4tGIW5AofqiQ+6xEOpyomuIrbVV0i7xQo+HelPaBl4mISRGBfad/29ubhjVFFZSQxEZaNAIyrGRCgoMwAuif58r1/LB3gnO0PJibS+TsFwGPrv05YJtMQkwLERCRLJ2oPbXxyqX/udh4dwTJBJMVzL6+cEqZ0MyJAQZkReE/2lXv/qI6OsDqIZWJiUij8H7rqMG5GYuLDFREwWCrDioqXUSyp6FSmRKrwFxuvhCiuvryyUo8huTULArFOZpE601QCr9z7h3VsrBa6hhroJO05ExcTWQ/jZiwmyKp0/W0VlUMbnxrSUqGYDFPXWQhLQclCLSAPeD+njp63Kh3QXD8x8TD9M58RMUEmURa9JV7cxBOwA4oKxaR/7WbzKAUlQ/WCx+nryI6Kit/N2WmZSOfc22VMTJBhFUF5GA3Dn8/sKSpJyRQG/hcbrITgMGfvljDdELF+ppsuU9uFwCv3/l4dYrJqQmLiIdvmXEx8v3ckGRWTUAqbqD2y8dk9RUVKRzHpXcdZ9aWgZLBmvnvf79bRkSAqyVu6UUz6yUnGxUStKzwBW0LRNo+uX9xVVFxQaZlksIH2yRIFpQ+cWR66ed/vqKhYHjrFJFosnTmcEzHRTONZF72lfGT90i6i4lLCuzmdtZztPQpKhuvn1n2/XZd5An8mQywTuWXcaw5lzsQklMEsFbw1vENUpGGKpMQGKqXnnAkgZNrF+sp0NvObuVv3/VZdOpKLiXQzvb2cQDKnYhJKoG8NY/jTLSoUk0QVz80mBWUOqur1+87VYZmsmphohlue7TkXE5FHcSX8bx5Zf6ZtqaBhhjJKCFomAmkeHAVlHmoJebx936N1jBOOY1Me1a/jvwAxkY54GUMgrG3OQfw751jg3/XA3Ijv5vjj9D5cQUqSpgzAZKkdX5LXLfOT539NMgZ40Q+3lIuX8RMEUiZxdcSBshaP8wlY5TEXC6vtucgqM9lN4I6rT1XhV5POK3/i5lRMQgm0FKuvrDxQ18JwMXcE3jR3OWaGkwTKiyQmwVxGmejmlQAFJcWaw6cuHkN0D8PQL2u0XUMN6fx7PwFrtoa9AAirQ0YUcLA8WtvF4jo2z7Xu+42W+/mQYt4tkzj2jj/ncOzyRgnI5FOoy2BX9qGalF1YittZfvPXg1hsI4QOypSjnxMsuWKhiQnup68/8O7HPDzX4xGI9ThePLk/G2JSA4TzExITtHu9xVrFxqbDRmcSgWktlphomayIxYKUtTohMYGqFMuI//zdz36uhjVdCgQoKClAhJgsIZqqXC/VpWuZiJi0493GzzbecfXvkBaU5P4PNiEmq3ZQlrBuutL2q7rF4Et/lkX2gx8iLiAdWUk5wu+ZhH0LZ0dlmThPw9sRtxYGmICVnOpfbIAap/wEQVOiPLa+UcUKXKVM4mP59LWnFcXUj0tYsUD6WiYiJiGcrqt3P/uvUod0YxKI9TlmRPk+vbg8JTEBZukAxTIW6vDRcrFSVsV/AcREyuKubGWSXev8vk5ZTDz+ZUmJbjwCFJTx+IWzdThiVz1t+7EDjDFn0m2ZIC2/rndmGqJSh5isWr+ztP2qHvb0BDnbLBDxTYTLhmVS7yyVCKT4WD59PSExkYRKsqAbjwAFZTx+8eyuoYZ0gEmIiSQYzfyYfOvEr9SR5qr4eEcMkqGB5ktMYO9NV0yEmnLiYjwCFJTx+NnZMxYTLwI+Wg5LJQx/1NMlZZ4sk4C03cGtDBO0TJAgxcTb0LhrCsq4BOV8bY/eKKdrmXRn/40TEJUwp2JZmz8xiWUyphSTSCTrWxSUVGpo2mLi6fXO/O0TH6jjyOq8DXOSpfFh3TTERNLy9JJ54PbwBCgowzPb5YxpWSY+WblLNoL37RPvr2MaYhXmU8tNep1byeQE7M6yiJBMS0yEi94h25kN+gxJgIIyJLBewbcxhzKdCVgRE7FO+lsonsfbJ36pjrAV7LfmSUwk/17CaDm4jxwd+jkTnJE837YlbuUi6+RhTYGLUQhQUEah1nWOm8y2Tt6FEVNaHBoslj0ep9/11rCcFTuT7AUxkYiGaPy3T6w20Gkq6DF4olbcTB5aEyvp1LBvDcfydxZ4yIfWuoBZXBK3i8k+eHWmoKC4GIEABWUEaL1OmZqYaNMfrvm/fnK1ATGpQExaM3gCVsSkAjFZ78VtN79pionkIaa3W47oPwgBCsoglPYIM10xQfc0U2OPXHUevn2i2oCYVHBdDpaKiBL21IaSpe3LWSZXdsTnMWSo5daWxSznRifn+19sVDp/I2LSiCGH2UqmkP4wRywTcRQT45DGMvdvG9/1/IdWAPIR/MtLdk/i06Bbw4KVjhYbZex40l5TG+Z4N9de3dnRBs3vrZMPNw5tfKICydjEP37QSCKTpcRncfpSjuRJTGL9DUrTwh195gvLOFfaTwn/T9588J1DWWLDpZb90PFikv28pp7DICaXEbE0ChGWzTuf/3B12IRiY5yOmFinHzaXFv7WyV9sQDxgqWy3sismnWWbxJyJpOD1JmuZVB/WQUyqOAfiXJC2s4w4Lh9e+6Js59blWlBQ6/JbG+2GZa2gWLvz+T+t2vYwy2mKyTiSUijcOvkLKiroSCoqUsrsWCadzDMuJrW2KAVBwr62qc5S5Gcvt4ISrJOyNwirculWiqR253N/Vh28GcyPmHiZXguigv1WFsVE6mVaYmJpDS7SwTLpJSaCt3xw7Uu5tVJyKyio+Ed2EROYLGhcxQIslT+vSgvZy1k8Nkk5qTkT7/R75WWY47dOvq+BeCsorE7UznbOpDvnJtJ+a1eOSmNV1gJDn8dJWpdGSMK5vSVh/fzuCVg5JsMcqzs7a5DlHmLi8cmcSi5dLgUF1skyGtJyrHFpjAGFiQn2tYFCVP6iGsP13pKQ8j8NMfE7Kb1zMrzvaxAV9KsKxATDH5RjJndzduZbRhAuBnJ00mIyiLAMKCYQlcLygbUvLUu+8+ZyKShoPOdjRe8qJgiiV7Ha0ef+shrD79ySxjgtMZGONkjj35nL3X1unXwv5lQKFYhJ4payhDery8+UdP0vNpxxbw177J3rqYuJmCt93BBiorF0trE+ES/YodguFqxguxUHd3GWcUz+4fYUE+28aBy1w8/9VVVP6bGwpoi4QpuUjtf1s42alndPOR4dfDutovaV2UL5EnHqSbKfPD/GNM7WzZMPqaWCuNVSmaWYWDmsjNJAlZfsTmCYo3FDTDrrpJPkCGIiFtXywbUXljtjWvy93AkKqvRhq1ZpoaH4XR1aOpOPr6WhSUfGunboub+u2rndS8Q1x2Lipbm5clYtFREV6852RBj4X2wwk7FMPC+ylrS0o09BTDSdZOJhe0QxwdnabkJb6xHxgnrF9rGgBUwWC9ZJGftVqewhxQThxRVrB5/7m6puJhdTFhMbDiQzkN72zZUzYaLWPgVKMSnUXGx8VNTe13bUvpao+FmHcmuyUD2w9kI5vdrJfky5EhQIwvkxxCQYIWKpPF7tqlrMPaAR+SuriYnNtIc5KiaeTlcm0tp9deW0WiooEywV+4sNZfKWiZRDWc6vZZKsCrS5/LjYTnJR5mJ5RMvExUSvSZiArR147smqI0PH25qmmMAgCvMcnoP01yIqkBJ596cZG0mxCUEe492cIfKJCeJJz5kkLQ1sr3vuxhzmeDS6RrzLHR4LvpOzd3nCzMBgcyah6t18lSt1x61heSKyLoHeuP83G6Xn/nYLHWDZRj92VZdj3mhlW6yjUSdg3TJB/E3EU5fYJu1eXXmPWCrHJ53OLvHX4S/PCpWxhgt1l9gWtn43aJDnTLQuwgSs14vGUSxsvfqed0lZ3T3ePm4V2q7Htn8IKfsmuN5OPAqvexHh/Lh48clHmc+hYTatbXoDRUNAo5GGYf/eEASIN5IdYiIHt2TRdtvFU4imLudY6GQ8EkoaP9LUZC1t7wxhT6OSc60Ni28iHIY58MdVtFi5feLhlgZe4AU+D4oy6o9DbTkHK64xkbpyfmOJCeoMMZ5KokTcSBP1ZxWh7UL3Q30Eb/UfQEzQ5uhIgARIgARIgARIgARmR8Dsx9mlP7cpl64+VYbpK/MoK2KS46+J7XP43jCGJXTzQgATsKi/gsyZlLGWYc4WVquvnX5nE2u6IQlQUIYEJsEhJktYbUJQSkFMNBYZ18OtyqdB1YOLTBPoczenhYxXbp1+RyPTBchg5vI2KTt2FewhJhJ/7Y6r/1AdOyFGMFECfcRE0i3h4rCJnyGQCwfdEAQoKEPAGkBMEJvcfSjWSlc/Uh0iagadIoE9xMTv6kBUCpt4a5iiMkTdUFAGhDWEmIS7nCIq/1gdMHoGmxKBAcUEoqIuWCpfpqgMWD8UlAFAjSAmGiuek6jtv/LR6gBJMMgUCAwpJv6cSQlXCFgqL1BUBqgjCsoekMYQE8Qsd38KtQNX/qm6RzI8PGECI4oJcqUPFEJUZPhDUdmrmigofQilICbaILGoHbzysWqfpHhoggTGFBPPmYrK/rWv0FJxIj3WFJQeUMQrRTFROwVjclgqH6/ukhy9J0QgJTHR3OHOD0SluFlae5Giskt9UVB6gJmAmCAVeUYFbylfqVV7JEmvCRBIWUyQw8Tw51KDotKjzigoXVAmKCaakkzUHrxSr3Yly92UCUxITDSX+7bFUils7qeo7Kg1CkoCyRTEBBc5vcrBUvlENZE0N1MkMGEx0ZxiCKvDn/2XvkpLJVF3FJQAY4pighT3FfDh8trhDYpKoi2msjklMUFeZQjrovI1ikqoPQqKtIr+7+YEVPoEbGhH2pjav8cR9jSc3Ci2h6LENxHOLBP4qZjgiFkqhzY+WYUnXQoEpiwmyLHWbwnLzUOXvk5RAZHcC8oMxSQ0SHyig6IytpzMSExUUvCRNAx/KCpSibkWlAyIidkpBfzw9canqlIhdMMTmLGYeIaDqHwj15ZKbgUlQ2ISXkYTUfl01Vsn14MRyIiYhMyapXL40jdzKyq5FJQMiok2SIzFMfz5THWwrsRQGROTUIdFnVM5cunfcykquROUDIsJGqRN1B7Z+GyVctGfQEbFxKZpw5xKHkUlV4IyB2KCSS29c1A7un6RorKLpmRcTDzXOqdy5NK3cmWp5EZQ5khM9HMb8u7PkfVLFBXvnmE9J2IScmtzKkcv5kdUciEocygmaJBmqRxZX6uG1pn71ZyJidYXXrVQS+Xoxf/IhaWy8IIyx2KCBmm/p3KUolKYUzEJFwG3VL698KKy0IKyAGLiVgmGP89UfSdv6zkXk1BddvfnrkuLLSoLLSioycvhJS671sMjfOrCK1nnK2x0oUOMNB6nR9wSlz+EL3dubF8SDano4/lhAtbnTNpHg2UiwdXJ+firff/6s+XglZsVxETKXPN6S+HzoMpeAOKtYVmFfduONSRPfbqfBsPCa08tx/a+H20ft3cvEsctPD6ZKsOfyzH84m0trKDccfWpZdRr2TqnNQRvlFaNqOTxvzWMqDrezcG+pCUNSFpVamKiMSLmRxBprhzqTD6YrmWeczHRMqDNlY9d/M7yolbimxa1YFYu6diLISZB+Rd+DN6jPWqZF0RMehRvsbwW1kJZJMskVlLx84vV/PYuDey8z1NM9uaUlRCxrWYlRynl43v3//oWomq4uWzRzt8wJ1ZQsQWRrFs5crTcLkiZW16PcW0MZN8Y2SAzScbCRv8ZzJlodnRoHTPWeOns27fi7mJtxfa6WOXS0qBBVbDRsKLNvZhUXl5ZaVpZ8rOUj5aHekyIipV/HsUEOZc2ubDOJhgWtniFwh1X/76EK/smrhJLNp1iRcYDR3A+wxL8sK/eGjARrvePI+n5Foecle4EbFR6tUxETIIwSr7z58J3hjdBGvVpd+vmzTJBtiuwTlqLXHsLLyhSeaUrHymhv2+i0y/JPsVEKMyfC98ZhqgUSxSTbNZfLgRF0OM7w3Jlg6VSgKjQMslmc9w7V/vXvrwEMZGLA7473OlkCCR16/5ZmTNBphbeMvGayI2gSIH3XxFRwfCnYKIifiIt1gCtMaqfeHCYIygy6Q7ik6Cook1kTi4S6igmTmK261wJiqA+cOWjKirYXKKYzLbxjZN6+M6wigrFZByS6Z6bO0ERfPh4OX5VqygTfDr8ETtFnM6t0DJRFvOwEFGBmEBU4vCHw5zZ1lwuBUWQH7jysWCpJCZqKSazbY0jpL4f3xnGhUEtFYrJCABTPiW3giIc8Z1hGYPbRC3FJOWmNb3o5OPlEBMVFYgLnDfrYHnCZwIv+llK4QVD3bFnnnIzARvK3LGKjzt0eOdj5/aJ1RaGORVMwDasIU7vRb8Ins+ZjNvaWqfvaSCOCuqwRTEZl+Z457uUjxfLnJ994Eodlsq+TXwedMdErd0D4kNr81DF4TvDsFSKYnmqnULLZLo1R0EJvA9vPI1G2DlRSzGZbmNMI7X9l/Q7w/JoAB5+627eti9393yrM83ga+YqDvn5Fh6/Z6Ku+90ceOZ6mGNUApvkTt63D218QkUFDQmWirQqWibz2CYOQFQgJrBU4nMqLg4Uk8nWqEvwZFOZo9gPbfwzbilvi9kstySRc0PkS5EZv/LJlUr2PYysk0DlfP/jnImCmtoifLw8iIrXntdPspZi/eljA5pDP27haZkMXm1ObvAzchDyMEQlPN+wJMX15kgxma/KN1ExS8WEPdZmLEmoXbsytGvbLw4Uk0hqkC0Kyi6U8J1hmdhrP6ZPMdkFVMa9D136hky065yKXxpilikmkUU6WxSUPhwPq6jYRC2HOX1AZfzQEf14+S5zKrRMUq09CsoeOA9tfEbuFmwi2BLnTPaAleHD4TvDUo8y8a455ZxJ+hUW5wrTj3shYrx18r0tFKQCMQkPv7kG+wSfFZMTsNmu7ptnfrQh9QgxkfoMv4mjW7KA4wSscRhv6b1jvFhycPaR9YtyZVNLxRufF5ti4iSyv5aPl8My6bBUvD45ATt+/dFCGZDhzZWzaqmg8TWSKkwxGRBgRoLdPPMjHZYKxSTdikn2jXRjXtDY8J1hWCp6hdPnVOx2pP/yuhSa7+bMQ9Xbx8vt7g8tk/RqjIIyAksRFXlOBWIityTDZxwkIorJCDhndsrRi99e+j79reFCiY/Tp1MNHPKMwPHVldMt3PmpQEzqANhEFBgOFdfxn/tfpx8B58xOefXsD+nwB2KCupM61LqsY813cwCBjgRIgARmSiCXQx48BbtsBZelDFqw3JZ66Hw3x46Iv30HRo6LSSf+r6w8sCX+3e7Y+kYZfmUJk3xuRaKXh+McuEzmmvN1TEPCen40bwiL14Za10/9vFxRc+fCezklK7jz6hhqJpjE40X/hmmCtcyXWAipn0IT38lpJk5ubx67+F9L2MEzSOLsDG0iiX3Z9Hq0tCyc+WvAxksPHW/pVk4WkUAOCgwhWUExayg0GqeJxxhPwDZeXnngHsd27PKGfPvnMvaXJW4XBDtumD0tb4TeUD2ObUhOUkzEXxq0hpcototNLE9df+DdDawX3h3EW8MgKUzLsbDGUqTZt+Ix2Qq+7d5v+1onONpjAnYL3qeSH+CCmLwIP6TtZ0kdJJ3F6fXYS0z0XFwEEMPq9bPl9eTZi7xtArzIJews23lUdBpigljtR3za0dvk3rI2QW191uhkX1wKYiLRlNGIN+9+9nNl2Vlkd/DS18uQjE2UsRzLaSxTFBOJehl1JOkkXUlScskaUUwkBrS1wiPJiBd9+02LXsBk+dBI0hKTFhrLKY8bw5xlbC9pE5ycmJilYmVYQXpPePqTWh995gsoU+EyRKyMdQEjiCZWp/C94YbsT9KhrqSMpZjGRMQE0Wu8S7BKll86+7YtSQ8+p4KY4W5e0lkeBrBMLJbkqTnZzpmFUlyXBuLWQnKOw+rbr0m2Jw3H/yKonreGl6ckJsiYNupER7O8pr0MYiKf/SxL3GE6Qi2kQ2v/tiR+E3aJMlpHtrqQVG0/ph+Ot3u/H7f67DHMCafGcPBY9vhunH1bA9sVRNdyP09zBDGRuHLjYj/JQZHRQJ6cgJiAHBquNuaOBtoWLm+E3igd9QBzJhp0t/M9nrTXCTHRTu1zmyEf+gxO+Hh52kn3iC+IhUq7HHbGHjQcH09MPLL2+vrZH1BRgQdExdLweugzZ4LgO/L3ZDvSHGzkSlDwol8T1V1P0TLRJrJv6mLS3WjTa6l7iEl72IUib4aPl6eXeEdMUkYr54QtE021F9EbKirFCgK0RhETnFO/fvYtTU0gJ4tcCYrW6Xbxgl3MvAmZWez1LQ3H/yKcnsMcP8U7GfYtTreCvBG6v58wnmXi+fbY0lsPKCYor7pgqXx5Kb0c7IxpWmKyG9UbZ9/aQD1WkDN8ckVKHkP6Hj7p1OEve6HuL8h2nlzsMzkp9asrZ5toFHUr7vhiErFZQ8uJmGiHQeMpgSUslRcmICou60I4dmKvN/UNyhaPW30OOGeiUUnMdlZ3GpaSLF86e7wBMakgZMt9BxCT+o2cWSfCJneCEhoExrXpiYlbItMQE0nL0/PGPe56SMvExQTJ6rM8EBUZ/qQrKtIwrYt3d/Tgm6qYdD9nspPojYfe2oAvREWGP5a3PpaJRJCruRMpsLhcCsrNlTMNNMstJYCFdFD/i0D6D3P8XFmLkExLTGTyV+aA0nJjiolnQ0Vl/9pXltwjnXV3OW3fJsAlBT9uF4fRLJO9xcTLcuOh4xj+4Me2ZPijSXv6FiIh9FuwTkSAcudi/8ld0QsXpMjjionE4c0qNij3kaOSxp5PwIZwfp6vxdu2NZ96VUbnSR7WM0dbpCQmmjjyB1Epbsp3hkfLTfdZ3YW0/VmJiecOj9I3wL+CsrbcT9ax7tX3QvJYnrZzKyh4Y3gLjWBrHMsk2VBig+rsCGmLiVyFO1NI5mLw7ZTFBAknhj+XGimJipfHSjxZMRmc6nXMqSBnFfyrqMS61/yKdbKlWzlc5FZQpK4xTLkgghIhDD7MSbaV2KA6G+UkxETSjeklczH49oTERDOwb1sfN9/cn5qoZEtMnDLez1FRQV2oqLg/1hcS27nbjH0pd0UvFL678p4tAJArDRpBUf7H+D2TYgfBnIqJMsDIrASWEJWvLnVAGXrHmGbFMunOfhCVe+CPtqP/lTxbJ8InV+/ySIG7Hd4Y3oKf/I/hpismo1ooE7ZMlJ9O89igLIjK1ypvnPnJxvBwpycmo/KUMoVbw48NX77FPCPXFsokqnTSlok0fn8Ufpj8T1lMkDUVBHlrdzP8nskw2dXzp2GZuJjYQ2tDZpHBdxCgoOxAMroHxcQttWBdACXmqWCpDC8qsYPHOGVLJqXF7bx1HsNZCJM0u6Es805JZ2E7xcTPT4bj9rAEKCjDEusRXq0GdB1ptHZVtcYpcLXRym54dsQbcbiCh9hiA/fzveN4eE0DCejarv7h3P6rGVkmmkN/Ngc5DKLyjaX+ue0+6p3cZMGZUEy6OWVnn4KSSl3oLdOpiMkw2c2ImIQsm6VyWL8zPEgpKCaDUMpaGApKCjUyLcvEs+pWi+/3WmdMTDSLsDN0TiV8Z7hXtrv8pmeZdA6JurLB3YEJUFAGRrV7QB+mSIhJDXM8dRWTPWZlMyomYaBmlsreokIx8TqfpzUFJZXaMvN8WmLSz0KBmFRRpBcRRuYt2neE/Jy4lqM2J2ONwIZt5mtLCxv98dCaHrCreRySiKfsJeZMNJzPE4k0WGg/x+ZU5DvDIeCOlcYXgk9yzkStS8l7O2s7skKPIQhQUIaA1S/oNMXERaE7P0FMan7cDZn2fujWbt6L/wzEJGTbLJWjF7+10l0O2fcOPg0xSevdqF7lyJsfBSWFGqeYdF/ebb+HZRJoh+PbaqlcxneGqzurAWfveKva0/G12UBu/7hQWlwWxsV07x9HinHuzAt9BiVAQRmUVJ9w20V8L0faY3tI4I3T13KybUsD9zkXvwp7o5e1WBW+L2fpNjz1WIhD/JNuziwTzboxkE3lUsN3hqt6ICzicfd1lr5OU0w0jZanxPXoBCgoo7NLnFncmpaYBGFpeuIQExkyzMswR7MdxcLFQW2M2l2Xvp0c/rTL6GIc16mLieRrXTPHxVgEKChj4bOTr596dxNbT0TLwjuKHLdtOTauZaJxFAtbNx98V11ihpiUsVoEMfE5k9qxS9+RMuFnF99ex2rL+cX1RMTkCbzo10R6dGMSSLb8MaPi6fiiXxXN/eFIwvGGNYZEuw1zpJv4HIAK045hjsax8eqD73rC4z/yzBcfxfbjso/g6lzU4jr629UjpmNHfIgV/VO8mxOSsPLvYpm0mYQ5k3MQk3YZj138T5SxeNLzKjH1mzNxjnvPmWiMLSyfztOnQp3jpNa5f9s4TbA3Hvi5OuKT/2m5kiS0QGIixdEyyYa4l87+4BNYyT/dHBDgkGcOKqlPFpsLJiZS1Gaf8vJQxgnQQsl4BSWzJxOwGMoswe+Jmw++swUxWcf2efiVsW7fHUoOneZkmCPZF9fEv5SpgG8Nl7B6FP8NfHNY/cSfLtsEaKFku37auQu3hi/D4zz+paMV8NFyfNJBP9oua/HqmIeZMzFpIfunMH8ia3FSxvMo1eU3X/zvqnjQZZ8ABSX7dSR3c6rIZq1bNCTrt06/owH/CjYhKuYk3ByKSQVi0ghF0FViArZ2N0UliSaz2xSUzFaNZWyHmIhquHKEvL9++mchKoUgKoshJtIwu+7mUFRCfWd5RUHJcO30FBPk1y2VZNZvq6gUK6hQDBniLWAPY+dE/xnfGvZsyfBmh2ViB8U+6dbOIkTlf6p6gItMEqCgZLJa9KG1KrIWhznBKuklJl6EN07/DIYMxQqCSkdtu/kTE8t6pyHmAlOsHbt4rdouHDcyRYCCkqnqsMzsZZn0E5XXT/80RMWGPxLbgomJAsJDa7W7P0tRURgZW1BQMlYh44iJF+V2EBWICSyVeRrmeAmS67Zlop6JJ2ApKklMGdmmoGSkIiQbg4pJ51CgdwFMVOLwJ/tzJt3lECHZVUw0MDhQVLqxzXifgjLjCvDk0xQTj/ON0/fo8AdionMqJkTWSb2zyt4Qv7QWorY4Bnw3x7MjedhlAtaD7Fz78C5hmWggKYvkAj+OVHvzxWZVPbmYOQEKysyrIF3LpLs4rSAq6IA6/LHjQRCwM+dighJoWSgq3RU/o30KyozAe7LDWiY+yernD7K+fWYJloo9/BY6oHbDBRETR4Bbyv9b9R2uZ0OAgjIb7poqxKSEjV1vDbu5b0MVu2MjFeYPfA2T9TfO/FRbVOSanmUx8XL1GeYoBQ8n68BKREWY0s2IAAVlRuAlWXSCpbZoBNVo75spjzDmxN8qK961CYcGXslHyyEmePjN5lTiiT4Ecqmy/R3HPTMhby5t/hsvXb8B28L5Q8+ZeJojiImfuuQbXE+fAAVl+syTKcJqwDs4UxATT/Q2RAXbFUnX/LInJsl8ybbgkVzar9N3ip0LsISDkzJJ+ehmRICCMiPwkmz4CYJVbOLFPusocW0ZS8MysZji8taZnwiigh/XhhO7xFLv7KzWjbGcomUSc2lbQ4rJ6o2zbwlC2R0T96dBgIIyDcp90sBPEKxDNI4jyCrWTQnq/XcSYiLxiwuicg+kRIZBcHMrJk1kfhX/xyEm61jTzZAAf2BphvA9afwEgVxV6/J/YO1LVazPQ0zKu82ZiNCk4W6d+fHWkUvfrEBMNhHfUozT4s+4ZdJEfi9AROox39yaNQFaKLOuga708dZwHf/HUTG46ha33FrxYCYm6QiKxHnzzI+JmEFUfO5h9mIi+ZL5kl3mTLZwWIY2YpHUsU2XIQLptcwMFWqRsnJg7YVllOc8/peDmIgA3IOnYJtYp+bw8fKSWyqztEy8QG++eK2M/LyIfeRLHcS1KBbJVtjnKoMEKCgZrJReWdq/9pUyOhj+Cw2IiYhK6g4fLy9BTMLwx5uGTdhO4tbwXgXAI/UiJkv4b+FTF429wvP47Al4q5l9TpiDTBDAx8vRiX1OZXZikgkYzMTQBCgoQyNb/BPw8XIVFTSOpVlYJotPeHFLyEnZxa3bkUv26tkfbuHkCsREhxldT8A25Vj3D0qPnBhPXCgCtFAWqjrTLQw+Xl7CoOdxPBhTDjE3sZZPhYrg0JEACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACZAACUyMwP8DuP+1i5bL7hwAAAAASUVORK5CYII="


@shared_task(base=QueueOnce, once={"graceful": True})
def import_lab_template_process():
    repos = LabTemplateRepo.objects.filter(status__name="Active")
    git_workspace = "/tmp/git_repositories"
    for repo in repos.iterator():
        try:
            import_repo(repo, git_workspace)
        except Exception:
            log.exception("Error processing repo {0}".format(repo))


def import_repo(repo, git_workspace):
    lab_template_git_workspace_path = "{0}/{1}/labs".format(git_workspace, repo.name)
    latest_changeset = clone_or_update_repo(repo, git_workspace, lab_template_git_workspace_path)
    if repo.latest_changeset and repo.latest_changeset == latest_changeset and not VirtualDataCenterUnit.objects.filter(modified_date__gte=repo.modified_date,
                                                                                                                    lab_template_repo=repo).exists():
        log.info("Repo {0} already upto date for all vdu".format(repo))
        return

    with transaction.atomic():
        repo.latest_changeset = latest_changeset
        repo.save()

        lab_templates = [
            os.path.abspath('{0}/{1}'.format(lab_template_git_workspace_path, i)) for i in os.listdir(lab_template_git_workspace_path)
        ]
        for lab_template in lab_templates:
            create_or_update_template_for_all_vud(repo, lab_template)


def create_or_update_template_for_all_vud(repo, lab_template):
    """Create or update a template from repo to all vdus

    Arguments:
        repo
        lab_template
    """
    lt_from_repo = get_lab_template_from_repo(repo, lab_template)
    qs_vdu = VirtualDataCenterUnit.objects.filter(lab_template_repo=repo)
    for vdu in qs_vdu.iterator():
        if lab_template_name_match(
                VirtualDataCenterUnitLinkLabTemplateRepo.objects.get(vdu=vdu, repo=repo).import_rules,
                lt_from_repo["name"]):
            log.info("Add/updating {0} to vdu {1}".format(lab_template, vdu.name))
            lt, created = LabTemplate.objects.get_or_create(
                template_path=lt_from_repo["template_path"],
                repo=repo,
                version=lt_from_repo["version"],
                virtualdatacenterunit=vdu,
                defaults=lt_from_repo,
            )
            if created:
                lt.virtualdatacenterunit = vdu
                lt.status = EntityType.objects.get(
                    name="Public", family="LabTemplateAvailabilityStatus"
                )
            else:
                lt.name = lt_from_repo["name"]
                lt.description = lt_from_repo["description"]
                lt.version = lt_from_repo["version"]
                lt.lab_spec = lt_from_repo["lab_spec"]
                lt.lab_params = lt_from_repo["lab_params"]
                lt.logo = lt_from_repo["logo"]
                lt.meta_data_json = lt_from_repo["meta_data_json"]
                lt.vdu = vdu

            lt.save()


def lab_template_name_match(state_rules, lab_template_name):
    if state_rules:
        for sr in state_rules:
            res = bool(re.match(sr, lab_template_name))
            if res:
                return True
    return False


def get_lab_template_from_repo(repo, lab_template):
    """Get lab template object saved in git repo.

    Arguments:
        repo {LabTemplateRepo} -- Repo name
        lab_template {string} -- lab template git path

    Returns:
        dict -- Lab template object from repo.
    """

    response = {"meta_data_json": None, "lab_spec": {}}
    with plumbum.local.cwd(lab_template):
        with open("meta.yaml") as f:
            response["meta_data_json"] = yaml.safe_load(f)

        if response["meta_data_json"]["description"]["long"] == "readme.md":
            with open("readme.md") as f:
                response["meta_data_json"]["description"]["long"] = f.read()

        response["description"] = response["meta_data_json"]["description"]
        with open("release.yaml") as f:
            response["lab_spec"]["release"] = yaml.safe_load(f)

        with open("create.yaml") as f:
            response["lab_spec"]["create"] = yaml.safe_load(f)

        resource_path = "request_params.jobs_sequence[*].inputs.parameters[?(@.name==LabResourceRequired)].value"
        cpus = sum(
            jsonpath_rw_ext.match(
                resource_path + "[*].CpuCores.size", response["lab_spec"]["create"],
            )
        )
        memory = sum(
            jsonpath_rw_ext.match(
                resource_path + "[*].Memory.size", response["lab_spec"]["create"],
            )
        )
        disk = sum(
            jsonpath_rw_ext.match(
                resource_path + "[*].Disk.size", response["lab_spec"]["create"],
            )
        )
        vms = len(
            jsonpath_rw_ext.match(resource_path, response["lab_spec"]["create"])[0]
        )
        response["meta_data_json"]["stats"]["cpu"] = cpus
        response["meta_data_json"]["stats"]["vm"] = vms
        response["meta_data_json"]["stats"]["disk"] = "{0} GB".format(disk)
        response["meta_data_json"]["stats"]["memory"] = "{0} GB".format(memory)

        response["lab_spec"]["stats"] = response["meta_data_json"]["stats"]
        with open("param.yaml") as f:
            response["lab_params"] = yaml.safe_load(f)

        response["repo"] = repo
        response["change_set"] = get_change_set(directory=lab_template)
        response["template_path"] = "labs/{0}".format(lab_template.split("/")[-1])
        response["name"] = response["meta_data_json"]["name"]
        response["version"] = response["meta_data_json"]["version"]

        file_path_svg = "{0}/logo.svg".format(lab_template)
        file_path_png = "{0}/logo.png".format(lab_template)
        if os.path.exists(file_path_svg):
            with open(file_path_svg, "rb") as f:
                img = base64.b64encode(f.read())
            response["logo"] = "data:image/svg+xml;base64,{0}".format(
                img.decode("utf-8")
            )
        elif os.path.exists(file_path_png):
            with open(file_path_png, "rb") as f:
                img = base64.b64encode(f.read())
            response["logo"] = "data:image/png;base64,{0}".format(img.decode("utf-8"))
        else:
            response["logo"] = RUBRIK_LOGO
    return response


def clone_or_update_repo(repo, git_workspace, lab_template_git_workspace_path):
    """Clone or Update given repo at given path.

    Arguments:
        repo
        git_workspace
        lab_template_git_workspace_path
    """
    log.info("Clonning/Updating {0}".format(repo.name))
    lab_template_git_token_path = "{0}/{1}_id_rsa".format(git_workspace, repo.name)
    if not os.path.isfile(git_workspace):
        plumbum.local["mkdir"]["-p", git_workspace]()

    with open(lab_template_git_token_path, "w") as f:
        f.write(repo.get_token)

    plumbum.local["chmod"]["600", lab_template_git_token_path]()
    git = plumbum.local["git"]
    git = git.setenv(
        GIT_SSH_COMMAND="ssh -i {0} "
                        "-o StrictHostKeyChecking=no "
                        "-o UserKnownHostsFile=/dev/null "
                        "-o Compression=no".format(lab_template_git_token_path)
    )
    if not os.path.exists(lab_template_git_workspace_path):
        with plumbum.local.cwd(git_workspace):
            git["clone", repo.url, repo.name]()

    with plumbum.local.cwd(lab_template_git_workspace_path):
        git["pull"]()

    with plumbum.local.cwd(lab_template_git_workspace_path):
        git["checkout", "master"]()
        git["submodule", "init"]()
        git["submodule", "update"]()

    log.info("Cloning/Updating {0} complete".format(repo.name))
    return get_change_set(lab_template_git_workspace_path)
