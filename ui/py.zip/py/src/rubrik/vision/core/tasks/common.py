"""Common util functions for tasks in future it can be a module."""
import logging
from functools import lru_cache

from django.db import transaction
from drf_client.client import DrfClient

from rubrik.vision.core.models import EntityType
from rubrik.vision.core.models import GlobalConfig
from rubrik.vision.lib.collections_utils import CollectionUtils

log = logging.getLogger(__name__)


@lru_cache(maxsize=4)
def get_vcube_client(vdu_name):
    vcube_config = GlobalConfig.objects.get(name="vcube").data[vdu_name]
    wscl = DrfClient(**vcube_config['connection'])
    return wscl


def create_vcube_task(wscl, lab_template_intance, action, overrides=None):
    vcube_job_request = lab_template_intance.lab_template.lab_spec[str(action)]

    # Replace Secrets
    secrets = GlobalConfig.objects.get(name="vcube").data[
        lab_template_intance.lab_template.virtualdatacenterunit.name]['secrets']
    job_params = lab_template_intance.params
    placeholder_params = [
                             ("<" + k + ">", v) for k, v in job_params.items()] + [
                             ("<" + k + ">", v) for k, v in secrets.items()
                         ]
    placeholder_params.append(("<instance_id>", str(lab_template_intance.id)))

    if overrides is not None:
        override_params = [("<" + k + ">", v) for k, v in overrides.items()]
        placeholder_params += override_params

    complete_params = CollectionUtils.replace_str_everywhere(
        placeholder_params, vcube_job_request
    )
    vcube_job_request_result = wscl.api.rubrik.vcube.core.jobexecutionrequest.create(
        **complete_params
    )
    return vcube_job_request_result


def get_vcube_task_status(wscl, vcube_task_id):
    vcube_res = wscl.api.rubrik.vcube.core.jobexecutionrequest.read(id=vcube_task_id)
    return vcube_res


def get_lab_details(res):
    keys = ["id", "outputs"]
    labs = res["jobs"]
    details = {}
    for lab in labs:
        lab_detail = {}
        for key in keys:
            lab_detail[key] = lab.get(key, "")
        details[lab["name"]] = lab_detail
    return details


def update_resource_reservation_request(resource_reservation_request, status_details, status):
    """Updates resource reservation request status and status details

    :param resource_reservation_request: obj
    :param status_details: json
    :param status: ReservationStatus entity name
    :return:
    """
    with transaction.atomic():
        _status_details = status_details
        resource_reservation_request.status = EntityType.objects.get(
            family="ReservationStatus",
            name=status
        )
        resource_reservation_request.status_details = _status_details
        resource_reservation_request.save()
