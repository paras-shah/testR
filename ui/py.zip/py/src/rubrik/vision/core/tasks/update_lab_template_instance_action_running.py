import logging

from celery import shared_task
from celery_once import QueueOnce
from django.db import transaction
from django.utils import timezone

from rubrik.vision.core.models import LabTemplateInstanceAction, EntityType, LabTemplateInstance
from .common import get_vcube_client, get_lab_details, get_vcube_task_status

log = logging.getLogger(__name__)




@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def check_action_jobs():
    processing_status = EntityType.objects.get(
        name="Running", family="ActionStatus"
    )
    reqs = LabTemplateInstanceAction.objects.filter(status=processing_status)
    for req in reqs.iterator():
        get_lti = LabTemplateInstance.objects.get(id=req.lab_template_instance_id)
        wscl = get_vcube_client(get_lti.lab_template.virtualdatacenterunit.name)
        vcube_res = get_vcube_task_status(wscl, req.action_spec["id"])
        # Job is done
        if vcube_res["state"] == "Completed":
            # Job Succeeded
            if vcube_res["status"] == "Success":
                new_status = EntityType.objects.get(
                    name="Completed", family="ActionStatus"
                )
                action_spec = req.action_spec
                for i in vcube_res['jobs']:
                    action_spec['output'].append(i['outputs'])
                req.action_spec = action_spec
                end_time = timezone.now()
            # Job Failed
            else:
                new_status = EntityType.objects.get(
                    name="Failed", family="ActionStatus"
                )
                try:
                    with transaction.atomic():
                        req.status = new_status
                        lti = LabTemplateInstance.object.get(id=req.lab_template_instance_id)
                        lti.status = EntityType.objects.get(name="Ready", family="RequestStatus")
                        lti.save()
                        req.save()
                except Exception as e:
                    log.exception("Error while saving after create check: {}".format(e))
                break
            try:
                with transaction.atomic():

                    req.status = new_status
                    lti = LabTemplateInstance.object.get(id=req.lab_template_instance_id)
                    lti.status = EntityType.objects.get(
                        name="Ready", family="RequestStatus"
                    )
                    lti.save()
                    req.end_time = end_time
                    req.save()
            except Exception as e:
                log.exception("Error while saving after create check: {}".format(e))
