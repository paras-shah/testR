import logging

from celery import shared_task
from celery_once import QueueOnce
from django.db import transaction
from django.utils import timezone

from rubrik.vision.core.models import LabTemplateInstance, EntityType
from .common import get_vcube_client, get_lab_details, get_vcube_task_status

log = logging.getLogger(__name__)


def get_external_lab_details(lab_details, instance_id):
    try:
        url = lab_details["get-lab-summary-" + str(instance_id)]["outputs"][
            "GlobalLabExternalDetails"
        ]
    except KeyError:
        log.exception("Error extracting external lab details for {0}".format(instance_id))
        url = ""
    return url


@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def check_create_jobs():
    reqs = LabTemplateInstance.objects.filter(status__name="Processing",
                                              status__family="RequestStatus")
    for lti in reqs.iterator():
        try:
            wscl = get_vcube_client(lti.lab_template.virtualdatacenterunit.name)
            vcube_res = get_vcube_task_status(wscl, lti.lab_internal_create_details["id"])
            if vcube_res["state"] == "Completed":
                lab_details = get_lab_details(vcube_res)
                lti.lab_internal_create_details = {
                    "id": vcube_res["id"],
                    "state": vcube_res["state"],
                    "status": vcube_res["status"],
                    "status_message": str(vcube_res["status_message"]),
                    "lab_details_internal": lab_details
                }
                if vcube_res["status"] == "Success":
                    lti.start_date = timezone.now()
                    lti.end_date = lti.start_date + timezone.timedelta(
                        hours=lti.lab_template.virtualdatacenterunit.policies[
                            'default_lab_instance_life_hr']
                    )
                    lti.status_message = "Lab is ready to use."
                    lti.status = EntityType.objects.get(name="Ready", family="RequestStatus")
                    lti.lab_details = get_external_lab_details(lab_details, lti.id)
                else:
                    lab_details = {"error": "processing failed"}
                    lti.status = EntityType.objects.get(name="ProcessingFailed",
                                                        family="RequestStatus")
                    lti.status_message = "Processing of lab failed"
                    lti.lab_details = lab_details
                with transaction.atomic():
                    lti.save()
        except Exception:
            log.exception(
                "Error while processing lab instance request {0}".format(lti.id)
            )
