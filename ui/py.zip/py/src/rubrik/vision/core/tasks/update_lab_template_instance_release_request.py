import logging

from celery import shared_task
from celery_once import QueueOnce
from django.db import transaction

from rubrik.vision.core.models import LabTemplateInstance, EntityType
from .common import get_vcube_client, get_vcube_task_status

log = logging.getLogger(__name__)


@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def check_release_request_jobs():
    reqs = LabTemplateInstance.objects.filter(status__name="ReleaseRequest",
                                              status__family="RequestStatus")
    for lti in reqs:
        try:
            wscl = get_vcube_client(lti.lab_template.virtualdatacenterunit.name)
            vcube_res = get_vcube_task_status(wscl, lti.lab_internal_create_details["id"])
            if vcube_res["state"] == "Completed":
                lti.lab_internal_destroy_details = {
                    "id": vcube_res["id"], "state": vcube_res["state"],
                    "status": vcube_res["status"],
                    "status_message": vcube_res["status_message"]
                }
                if vcube_res["status"] == "Success":
                    lti.status = EntityType.objects.get(name="PendingRelease",
                                                        family="RequestStatus")
                    lti.status_message = "Lab has been released."
                    lti.save()
                else:
                    lti.status_message = "Error while releasing lab"
                    lti.status = EntityType.objects.get(name="ReleaseFailed",
                                                        family="RequestStatus")
                with transaction.atomic():
                    lti.save()
        except Exception as e:
            log.exception(
                "Error while updating release lab instance request {0}".format(lti.id)
            )
