import logging

from celery import shared_task
from celery_once import QueueOnce
from django.db import transaction

from rubrik.vision.core.models import EntityType
from rubrik.vision.core.models import LabTemplateInstance
from .common import create_vcube_task
from .common import get_vcube_client

log = logging.getLogger(__name__)


@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def send_create_jobs():
    reqs = LabTemplateInstance.objects.filter(status__name="Initial",
                                              status__family="RequestStatus")
    for lti in reqs.iterator():
        try:
            with transaction.atomic():
                lti.status = EntityType.objects.get(
                    name="Processing", family="RequestStatus"
                )
                wscl = get_vcube_client(lti.lab_template.virtualdatacenterunit.name)
                vcube_res = create_vcube_task(wscl, lti, "create")
                create_details = {"id": vcube_res["id"], "state": vcube_res["state"],
                                  "status": vcube_res["status"],
                                  "status_message": vcube_res["status_message"]}
                lti.lab_internal_create_details = create_details
                lti.save()
        except Exception:
            log.exception(
                "Error while processing lab instance request {0}".format(lti.id)
            )
