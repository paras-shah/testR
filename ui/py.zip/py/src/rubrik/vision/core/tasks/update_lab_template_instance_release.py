import logging

from celery import shared_task
from celery_once import QueueOnce
from django.db import transaction
from django.utils import timezone

from rubrik.vision.core.models import LabTemplateInstance, EntityType

log = logging.getLogger(__name__)


@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def release_jobs():
    reqs = LabTemplateInstance.objects.filter(status__name="Ready",
                                              status__family="RequestStatus")
    for lti in reqs.iterator():
        if lti.end_date < timezone.now():
            try:
                with transaction.atomic():
                    lti.status = EntityType.objects.get(
                        name="PendingRelease", family="RequestStatus"
                    )
                    lti.save()
            except Exception:
                log.exception(
                    "Error while releasing lab instance request {0}".format(lti.id)
                )
