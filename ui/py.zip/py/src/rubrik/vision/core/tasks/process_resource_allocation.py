import logging

from celery_once import QueueOnce
from celery import shared_task

from rubrik.vision.core.models import ResourceReservationRequest
from rubrik.vision.lib.resource_manager.resource_request_processor import ResourceRequestProcessor

from rubrik.vision.core.tasks.common import update_resource_reservation_request

log = logging.getLogger(__name__)


@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def process_resource_allocation():
    """Task executes resource allocations

    :return: None
    """

    resource_reservation_requests = ResourceReservationRequest.objects.filter(
        status__name="Initial"
    ).order_by("-created_date")

    log.info("found {0} resource reservation requests".format(
        len(resource_reservation_requests)
    ))
    priority_order = {"Normal": 2, "High": 1, "Urgent": 0}

    if resource_reservation_requests:
        logging.info(resource_reservation_requests)

        # sort by priority_order
        for resource_reservation_request in sorted(
            resource_reservation_requests,
            key=lambda x: priority_order[str(x.priority)],
            reverse=False,
        ):
            try:
                update_resource_reservation_request(
                    resource_reservation_request=resource_reservation_request,
                    status_details={"Details": {"Request": "PendingReservation"}},
                    status="PendingReservation",
                )

                ResourceRequestProcessor.reserve_resource(
                    request_reservation_id=resource_reservation_request.id
                )

            except Exception as e:
                log.exception({"ERROR": "{0}".format(str(e))})
                update_resource_reservation_request(
                    resource_reservation_request=resource_reservation_request,
                    status_details={
                        "Details": {
                            "Exception": str(e),
                            "More info": str(traceback.extract_stack()),
                        }
                    },
                    status="ReservationFailed",
                )

    else:
        logging.info("No Instances in Initial state")
