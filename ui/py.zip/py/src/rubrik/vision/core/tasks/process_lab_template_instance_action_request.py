import logging

from celery import shared_task
from celery_once import QueueOnce
from django.db import transaction
from django.utils import timezone
from rubrik.vision.core.models import LabTemplateInstanceAction, EntityType,LabTemplateInstance
from .common import get_vcube_client
from .common import create_vcube_task

log = logging.getLogger(__name__)

@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def send_action_jobs():
    initial_status = EntityType.objects.get(name="Initial", family="ActionStatus")
    reqs = LabTemplateInstanceAction.objects.filter(status=initial_status)
    for req in reqs.iterator():
        # TODO Check if capacity exists before sending request (Quin Outland <qoutland@gmail.com>)
        log.info("action status".format(req.__dict__))
        get_lti = LabTemplateInstance.objects.get(id=req.lab_template_instance_id)
        wscl = get_vcube_client(get_lti.lab_template.virtualdatacenterunit.name)
        vcube_res = create_vcube_task(wscl, req.lab_template_instance_id, "restart_vm",req.params)

        # If task cannot be created or problem with vcube
        if vcube_res is None:
            log.exception("vcube cannot be reached")
        action_spec = {}
        action_spec["id"] = vcube_res["id"]
        action_spec["state"] = vcube_res["state"]
        action_spec["status"] = vcube_res["status"]
        action_spec["status_message"] = vcube_res["status_message"]
        action_spec['output'] = []
        start_time = timezone.now()
        try:
            with transaction.atomic():
                req.action_spec = action_spec
                req.status = EntityType.objects.get(
                    name="Running", family="ActionStatus"
                )
                lti = LabTemplateInstance.object.get(id=req.lab_template_instance_id)
                lti.status = EntityType.objects.get(
                    name="Processing", family="RequestStatus"
                )
                lti.save()
                req.start_time = start_time
                req.save()
        except Exception as e:
            log.exception("Error while saving create request details: {}".format(e))
