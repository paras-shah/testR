import logging
from celery_once import QueueOnce
from celery import shared_task

from rubrik.vision.core.models import ResourceReservationRequest
from rubrik.vision.lib.resource_manager.resource_request_processor import ResourceRequestProcessor
from rubrik.vision.core.tasks.common import update_resource_reservation_request

log = logging.getLogger(__name__)

@shared_task(base=QueueOnce, once={"graceful": True}, ignore_result=True)
def process_resource_release():
    """Task executes resource allocations release

    :return: None
    """

    resource_reservation_requests = ResourceReservationRequest.objects.filter(
        status__name="PendingRelease"
    )

    for _request in resource_reservation_requests.iterator():
        try:

            ResourceRequestProcessor.release_resource(
                request_reservation_id=_request.id
            )

        except Exception as e:
            log.exception("Error while processing release request {0}".format(_request.id))
            update_resource_reservation_request(
                resource_reservation_request=_request,
                status_details={"Details": "Internal Error {0}".format(str(e))},
                status="ReleaseFailed"
            )
