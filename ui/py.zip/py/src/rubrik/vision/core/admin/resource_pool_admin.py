from .base_admin import BaseAdmin


class ResourcePoolAdmin(BaseAdmin):
    list_display = ["name", "datacenter", "state", "status"]
    fields = ["name", "datacenter", "state", "status"]
    search_fields = ["name", "datacenter__name"]
    list_filter = ["datacenter__name"]
