from .base_admin import BaseAdmin


class ResourcePoolCapacityAdmin(BaseAdmin):
    list_display = [
        "resource_pool",
        "resource_type",
        "resource_property_type",
        "total_capacity",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    ]
    fields = [
        "resource_pool",
        "resource_type",
        "resource_property_type",
        "total_capacity",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    ]
    search_fields = [
        "resource_pool__name",
        "resource_type__name",
        "resource_property_type__name",
    ]
    list_filter = [
        "resource_pool__name",
        "resource_type__name",
        "resource_property_type__name",
    ]
