from django.contrib import admin

from rubrik.vision.core.models import VirtualDataCenterUnit
from .base_admin import BaseAdmin


class LabTemplateRepoInline(admin.TabularInline):
    model = VirtualDataCenterUnit.lab_template_repo.through
    extra = 1


class VirtualDataCenterUnitAdmin(BaseAdmin):
    list_display = ["name", "datacenter"]
    search_fields = ["name", "datacenter", "lab_template_repo"]
    fields = ["name", "datacenter", "policies"]
    list_filter = ["name", "datacenter", "lab_template_repo"]
    inlines = (LabTemplateRepoInline,)
