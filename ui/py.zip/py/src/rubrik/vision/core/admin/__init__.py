import sys
from django.contrib.admin.sites import AlreadyRegistered

from django.apps import apps
from django.contrib import admin

# list admin pages
from .data_center import DataCenterAdmin
from .entity_type import EntityTypeAdmin
from .global_config import GlobalConfigAdmin
from .lab_template_instance import LabTemplateInstanceAdmin
from .lab_template_repo import LabTemplateRepoAdmin
from .lab_template import LabTemplateAdmin
from .resource_admin import ResourceAdmin
from .resource_pool_admin import ResourcePoolAdmin
from .resource_pool_capacity_admin import ResourcePoolCapacityAdmin
from .resource_pool_share_admin import ResourcePoolShareAdmin
from .resource_property_admin import ResourcePropertyAdmin
from .resource_property_type_admin import ResourcePropertyTypeAdmin
from .resource_reservation_admin import ResourceReservationAdmin
from .resource_reservation_request_admin import ResourceReservationRequestAdmin
from .virtual_data_center_unit import VirtualDataCenterUnitAdmin
from .virtual_data_center_unit_capacity_admin import VirtualDataCenterUnitCapacityAdmin
from .lab_template_instance_action import LabTemplateInstanceActionAdmin


# bulk model to admin page registration
current_module = sys.modules[__name__]
current_app = apps.get_app_config("core")
for model_name, model in current_app.models.items():
    try:
        admin.site.register(
            model, getattr(current_module, "{}Admin".format(model.__name__))
        )
    except (AttributeError, AlreadyRegistered) as e:
        pass
