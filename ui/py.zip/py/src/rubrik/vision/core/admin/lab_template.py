from .base_admin import BaseAdmin


class LabTemplateAdmin(BaseAdmin):
    list_display = ["name", "virtualdatacenterunit", "version", "repo", "status"]
    fields = [
        "name",
        "template_path",
        "virtualdatacenterunit",
        "version",
        "description",
        "lab_spec",
        "lab_params",
        "repo",
        "status",
        "logo"
    ]
    search_fields = ["name", "virtualdatacenterunit__name", "version"]
    list_filter = ["virtualdatacenterunit",  "status"]
