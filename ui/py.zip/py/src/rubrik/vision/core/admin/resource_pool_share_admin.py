from .base_admin import BaseAdmin


class ResourcePoolShareAdmin(BaseAdmin):
    list_display = [
        "virtual_datacenter_unit",
        "resource_pool",
        "resource_type",
        "resource_property_type",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    ]
    fields = (
        "virtual_datacenter_unit",
        "resource_pool",
        "resource_type",
        "resource_property_type",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    )
    search_fields = ["virtual_datacenter_unit__name"]
    list_filter = ["virtual_datacenter_unit__name"]
