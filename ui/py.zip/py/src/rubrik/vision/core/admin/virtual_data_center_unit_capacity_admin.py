from .base_admin import BaseAdmin


class VirtualDataCenterUnitCapacityAdmin(BaseAdmin):
    list_display = [
        "virtual_datacenter_unit",
        "resource_type",
        "resource_property_type",
        "total_capacity",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    ]
    search_fields = [
        "virtual_datacenter_unit",
        "resource_type",
        "resource_property_type",
    ]
    fields = [
        "virtual_datacenter_unit",
        "resource_type",
        "resource_property_type",
        "total_capacity",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    ]
    list_filter = [
        "virtual_datacenter_unit__name",
        "resource_type",
        "resource_property_type__name",
    ]
