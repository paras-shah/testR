from .base_admin import BaseAdmin


class GlobalConfigAdmin(BaseAdmin):
    list_display = ["name", "description"]
    search_fields = ["name"]
