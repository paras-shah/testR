from .base_admin import BaseAdmin


class DataCenterAdmin(BaseAdmin):
    list_display = ["name", "location", "data", "status"]
    fields = ["name", "location", "status"]
    search_fields = ["name", "location"]
    list_filter = ["name", "location"]
