from .base_admin import BaseAdmin


class EntityTypeAdmin(BaseAdmin):
    list_display = ["name", "description", "family"]
    search_fields = ["name", "description"]
    list_filter = ["family"]
