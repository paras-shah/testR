from .base_admin import BaseAdmin


class LabTemplateInstanceActionAdmin(BaseAdmin):
    list_display = [
        "action_instance_id",
        "params",
        "action_spec",
        "requested_by",
        "lab_template_instance",
        "duration",
        "status"
    ]
    fields = [
        "name",
        "params",
        "action_spec",
        "lab_template_instance",
        "status",
        "requested_by",
        "start_time",
        "end_time",
    ]
    search_fields = ["name", "lab_template_instance", "action_instance_id"]
    list_filter = ["name", "lab_template_instance", "action_instance_id"]
