from .base_admin import BaseAdmin


class LabTemplateRepoAdmin(BaseAdmin):
    list_display = ["name", "url", "branch", "status__name", "latest_changeset"]
    search_fields = ["name", "url", "latest_changeset"]
    list_filter = ["branch", "status"]

    def save_model(self, request, obj, form, change):
        """Checks if token value has changed
        If changed save token using set_token

        :param request:
        :param obj:
        :param form:
        :param change:
        :return: None
        """

        try:
            if form.initial["token"] != form.cleaned_data["token"]:
                obj.set_token(token=form.cleaned_data["token"])
        # new repo does not have initial values
        except KeyError:
            obj.set_token(token=form.cleaned_data["token"])
        super().save_model(request, obj, form, change)
