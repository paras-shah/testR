from .base_admin import BaseAdmin


class ResourcePropertyTypeAdmin(BaseAdmin):
    list_display = ["name", "aggregate_type"]
    fields = ["name", "aggregate_type"]
    search_fields = ["name", "aggregate_type"]
    list_filter = ["name", "aggregate_type"]
