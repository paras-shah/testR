from .base_admin import BaseAdmin
from django.contrib import admin
from rubrik.vision.core.models import Resource


class ResourcePropertyTabularInline(admin.TabularInline):
    model = Resource.resource_properties.through
    extra = 1
    fields = (
            "resource",
            "resource_property_type",
            "value",
            "useable_capacity",
            "used_capacity",
            "free_capacity",
        )



class ResourceAdmin(BaseAdmin):
    list_display = [
        "name",
        "resource_type",
        "resource_pool",
        "shareable",
        "state",
        "status",
        "data",
    ]
    fields = [
        "name",
        "resource_type",
        "resource_pool",
        "shareable",
        "state",
        "status",
        "data",
    ]
    search_fields = ["name", "resource_pool__name"]
    list_filter = ["name", "resource_pool__name"]
    inlines = (ResourcePropertyTabularInline,)
