from .base_admin import BaseAdmin


class LabTemplateInstanceAdmin(BaseAdmin):
    list_display = [
        "instance_for",
        "status",
        "status_message",
        "start_date",
        "end_date",
        "params",
        "lab_details",
        "time_remaining"
    ]
    search_fields = ["id"]
    list_filter = ["instance_for", "status", "end_date"]
    readonly_fields = ["modified_date", "created_date"]
    date_hierarchy = "created_date"
    ordering = ["-created_date", "-modified_date"]
