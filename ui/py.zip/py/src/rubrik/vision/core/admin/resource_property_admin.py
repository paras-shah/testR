from .base_admin import BaseAdmin


class ResourcePropertyAdmin(BaseAdmin):
    list_display = [
        "resource__name",
        "resource_property_type__name__name",
        "value",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    ]
    fields = [
        "resource",
        "resource_property_type",
        "value",
        "useable_capacity",
        "used_capacity",
        "free_capacity",
    ]
    search_fields = ["resource__name", "resource_property_type__name", "value"]
    list_filter = ["resource__name", "resource_property_type__name"]
