from .base_admin import BaseAdmin


class ResourceReservationRequestAdmin(BaseAdmin):
    list_display = [
        "requested_by",
        "priority",
        "status",
        "expiry_date",
        "lab_template_instance",
        "request_params",
        "status_details",
        "data",
    ]
    fields = [
        "requested_by",
        "priority",
        "status",
        "expiry_date",
        "lab_template_instance",
        "request_params",
        "status_details",
        "data",
    ]
    search_fields = ["requested_by"]
    list_filter = ["requested_by"]
