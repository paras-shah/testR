from functools import reduce

from django.contrib import admin
from guardian.admin import GuardedModelAdmin
from django.contrib.postgres.fields import JSONField
from jsoneditor.forms import JSONEditor


class BaseAdmin(GuardedModelAdmin):
    formfield_overrides = {JSONField: {"widget": JSONEditor}}
    readonly_fields = ["created_date", "modified_date"]

    def __getattr__(self, attr):
        try:
            # not dynamic lookup, default behaviour
            return self.__getattribute__(attr)
        except Exception:
            lookup_more = (
                "__" in attr
                and not attr.startswith("_")
                and not attr.endswith("_boolean")
                and not attr.endswith("_short_description")
            )
            if lookup_more:

                def dyn_lookup(instance):
                    try:
                        # traverse all __ lookups
                        return reduce(
                            lambda parent, child: getattr(parent, child),
                            attr.split("__"),
                            instance,
                        )
                    except Exception:
                        return self.__getattribute__(attr)

                # get admin_order_field, boolean and short_description
                dyn_lookup.admin_order_field = attr
                dyn_lookup.boolean = getattr(self, "{}_boolean".format(attr), False)
                dyn_lookup.short_description = getattr(
                    self,
                    "{}_short_description".format(attr),
                    attr.replace("_", " ").capitalize(),
                )

                return dyn_lookup

            raise

    list_per_page = 30
