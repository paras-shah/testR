from .base_admin import BaseAdmin


class ResourceReservationAdmin(BaseAdmin):
    list_display = ["resource_reservation_request", "resource_reservation_name", "resource"]
    fields = ["resource_reservation_request", "resource_reservation_name", "resource"]
    search_fields = ["resource__name"]
    list_filter = ["resource__name"]
