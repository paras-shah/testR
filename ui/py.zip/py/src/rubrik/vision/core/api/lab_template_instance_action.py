from rest_framework import filters
from rest_framework import mixins
from rest_framework import serializers
from rest_framework import viewsets

from guardian.shortcuts import get_objects_for_user
from guardian.shortcuts import assign_perm
from django.db import transaction

from django_filters import rest_framework as backend_filters

from rubrik.vision.core.models import EntityType
from rubrik.vision.core.models import LabTemplateInstanceAction
from rubrik.vision.core.models import LabTemplateInstance

from rubrik.vision.core.permissions.permission_enums import (
    LabTemplateInstancePermissions,
)
from rubrik.vision.core.permissions.lab_template_instance_permission import (
    LabTemplateInstancePermission,
)

class LabTemplateInstanceActionSerializer(serializers.Serializer):
    """ Serializer for Request Lab Template Instance Action
    name, params and lab template instance id need to be passed for POST
    """

    id = serializers.CharField(required=False, read_only=True)
    name = serializers.CharField(required=True, read_only=False)
    start_time = serializers.CharField(required=False, read_only=True)
    end_time = serializers.CharField(required=False, read_only=True)
    created_date = serializers.CharField(required=False, read_only=True)
    params = serializers.JSONField(required=True, read_only=False)
    requested_by = serializers.CharField(required=False, read_only=True)
    status = serializers.CharField(required=False, read_only=True)
    lab_template_instance = serializers.CharField(read_only=False, required=True)
    action_instance_id = serializers.CharField(read_only=True,required=False)

class LabTemplateInstanceActionViewSet(mixins.CreateModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
    mixins.ListModelMixin,
    viewsets.GenericViewSet,):
    queryset = LabTemplateInstanceAction.objects.filter( status__name__in=['Initial', 'Running','Completed','Failed'])
    serializer_class = LabTemplateInstanceActionSerializer

    def perform_create(self, serializer):
        serializer.validated_data["lab_template_instance"] = LabTemplateInstance.objects.get(
            id=serializer.validated_data["lab_template_instance"]
        )
        obj = LabTemplateInstanceAction(**serializer.validated_data)
        obj.requested_by = self.request._user
        obj.status = EntityType.objects.get(family="ActionStatus", name="Initial")
        obj.save()
        return obj

