from rest_framework import filters
from rest_framework import mixins
from rest_framework import serializers
from rest_framework import viewsets

from guardian.shortcuts import get_objects_for_user
from guardian.shortcuts import assign_perm
from django.db import transaction

from django_filters import rest_framework as backend_filters

from rubrik.vision.core.models import EntityType
from rubrik.vision.core.models import LabTemplate
from rubrik.vision.core.models import LabTemplateInstance

from rubrik.vision.core.permissions.permission_enums import (
    LabTemplateInstancePermissions,
)
from rubrik.vision.core.permissions.lab_template_instance_permission import (
    LabTemplateInstancePermission,
)


class LabTemplateInstanceSerializer(serializers.Serializer):
    """ Serializer for Launch Lab Template Instance
    params and template id need to be passed for POST
    """

    id = serializers.CharField(required=False, read_only=True)
    start_date = serializers.CharField(required=False, read_only=True)
    end_date = serializers.CharField(required=False, read_only=True)
    created_date = serializers.CharField(required=False, read_only=True)
    params = serializers.JSONField(required=True, read_only=False)
    priority = serializers.CharField(required=False, read_only=True)
    instance_for = serializers.CharField(required=False, read_only=True)
    status = serializers.CharField(required=False, read_only=True)
    status_message = serializers.CharField(required=False, read_only=True)
    lab_template = serializers.CharField(read_only=False, required=True)
    lab_details = serializers.JSONField(required=False, read_only=True)
    lab_template_name = serializers.CharField(
        read_only=False, required=False, source="lab_template.name"
    )
    lab_template_version = serializers.CharField(
        read_only=False, required=False, source="lab_template.version"
    )
    lab_template_logo = serializers.CharField(
        read_only=False, required=False, source="lab_template.logo"
    )
    description = serializers.JSONField(
        read_only=True, required=False, source="lab_template.description"
    )
    vdu_id = serializers.CharField(
        read_only=True, source="lab_template.virtualdatacenterunit.id"
    )
    vdu_name = serializers.CharField(
        read_only=True, source="lab_template.virtualdatacenterunit.name"
    )
    datacenter = serializers.CharField(
        read_only=True, source="lab_template.virtualdatacenterunit.datacenter"
    )
    time_remaining = serializers.CharField(read_only=True,required=False)


class DestroyLabTemplateInstanceSerializer(serializers.Serializer):
    """
    Serializer is for updating the lab template instance to pending on calling destroy from velocity
    """

    id = serializers.CharField(required=False, read_only=True)
    start_date = serializers.CharField(required=False, read_only=True)
    end_date = serializers.CharField(required=False, read_only=True)
    priority = serializers.CharField(required=False, read_only=True)
    instance_for = serializers.CharField(required=False, read_only=True)
    status = serializers.CharField(required=False, read_only=True)


class LabTemplateFilter(backend_filters.FilterSet):
    """
    Custom filtering to get lab template instance by vdu
    """

    vdu_id = backend_filters.CharFilter(
        field_name="lab_template__virtualdatacenterunit__id", lookup_expr="exact"
    )
    vdu_name = backend_filters.CharFilter(
        field_name="lab_template__virtualdatacenterunit__name", lookup_expr="exact"
    )
    datacenter = backend_filters.CharFilter(
        field_name="lab_template__virtualdatacenterunit__datacenter__name",
        lookup_expr="exact",
    )

    class Meta:
        model = LabTemplateInstance
        fields = ["vdu_id", "vdu_name", "datacenter"]


class LabTemplateInstanceViewSet(
    mixins.CreateModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
    mixins.ListModelMixin,
    viewsets.GenericViewSet,
):
    queryset = LabTemplateInstance.objects.filter(
        status__name__in=["Initial", "Ready", "Processing", "Failed", "ProcessingFailed"]).order_by("created_date")
    serializer_class = LabTemplateInstanceSerializer
    api_name = "lab_template_instance"
    permission_classes = [LabTemplateInstancePermission]

    filter_backends = (backend_filters.DjangoFilterBackend, filters.SearchFilter)
    filterset_class = LabTemplateFilter
    # Choices are:
    # created_date,
    # end_date,
    # id,
    # instance_for,
    # instance_for_id,
    # lab_details,
    # lab_internal_create_details,
    # lab_internal_destroy_details,
    # lab_template,
    # lab_template_id,
    # labtemplateinstancegroupobjectpermission,
    # labtemplateinstanceuserobjectpermission,
    # modified_date,
    # params,
    # priority,
    # priority_id,
    # start_date,
    # status,
    # status_id,
    # status_message"
    search_fields = [
        "lab_template__name",
        "lab_template__version",
        "lab_template__virtualdatacenterunit__name",
        "lab_template__id",
        "priority__name",
        "status__name",
        "params",
    ]

    def get_queryset(self):
        qs = super().get_queryset()
        qs = get_objects_for_user(
            self.request.user,
            LabTemplateInstancePermissions.can_read_labtemplateinstance.name,
            klass=qs,
            with_superuser=False,
        )
        return qs

    def perform_create(self, serializer):
        serializer.validated_data["lab_template"] = LabTemplate.objects.get(
            id=serializer.validated_data["lab_template"]
        )
        obj = LabTemplateInstance(**serializer.validated_data)
        obj.instance_for = self.request._user
        obj.priority = EntityType.objects.get(family="Priority", name="Normal")
        obj.status = EntityType.objects.get(family="RequestStatus", name="Initial")
        with transaction.atomic():
            obj.save()
            self.perform_assign_perm(
                [
                    LabTemplateInstancePermissions.can_read_labtemplateinstance.name,
                    LabTemplateInstancePermissions.can_update_labtemplateinstance.name,
                ],
                self.request._user,
                obj,
            )
        return obj

    def perform_assign_perm(self, perm, user, obj):
        for i in perm:
            assign_perm(i, user, obj)


class DestroyLabTemplateInstanceViewSet(
    mixins.UpdateModelMixin, viewsets.GenericViewSet
):
    queryset = LabTemplateInstance.objects.all()
    serializer_class = DestroyLabTemplateInstanceSerializer
    permission_classes = [LabTemplateInstancePermission]
    api_name = "destroy_lab_template_instance"

    def perform_update(self, serializer):

        lab_template_instance = serializer.instance

        if lab_template_instance.status.name in {
            "Initial",
            "Ready",
            "ProcessingFailed",
        }:
            lab_template_instance.status = EntityType.objects.get(
                family="RequestStatus", name="PendingRelease"
            )
            lab_template_instance.status_message = ""
        elif lab_template_instance.status.name in {"Processing"}:
            lab_template_instance.status = EntityType.objects.get(
                family="RequestStatus", name="ReleaseRequest"
            )
            lab_template_instance.status_message = ""
        with transaction.atomic():
            lab_template_instance.save()
        return lab_template_instance
