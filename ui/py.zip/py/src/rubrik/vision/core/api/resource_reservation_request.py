from rest_framework import serializers
from rest_framework import viewsets
from rest_framework import mixins
from jsonschema import ValidationError
from jsonschema import validate
from rubrik.vision.core.models import EntityType
from rubrik.vision.core.models import ResourceReservationRequest
from rubrik.vision.core.models import LabTemplateInstance
from django.db import transaction
import logging

log = logging.getLogger(__name__)


class Validators:
    @staticmethod
    def request_params(request_params):

        request_params_schema = {
            "$schema": "http://json-schema.org/draft-06/schema#",
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "virtual_datacenter_unit": {
                        "type": "integer",
                        "description": "Name of the vdu.",
                    },
                    "ResourceType": {
                        "type": "string",
                        "description": "Type of the resource.",
                    },
                    "name": {"type": "string", "description": "Name of the resource."},
                    "CpuCores": {
                        "type": "object",
                        "description": "Number of CPU",
                        "anyOf": [{"$ref": "#/definitions/rest_resources"}],
                    },
                    "Memory": {
                        "description": "Memory Size",
                        "type": "object",
                        "anyOf": [{"$ref": "#/definitions/rest_resources"}],
                    },
                    "Disk": {
                        "type": "object",
                        "description": "Disk Size",
                        "anyOf": [{"$ref": "#/definitions/rest_resources"}],
                    },
                    "NetworkLabLan": {
                        "type": "object",
                        "description": "NetworkLabLan",
                        "anyOf": [{"$ref": "#/definitions/rest_resources"}],
                    },
                    "NetworkLabWan": {
                        "type": "object",
                        "description": "NetworkLabWan",
                        "anyOf": [{"$ref": "#/definitions/rest_resources"}],
                    },
                },
                "required": [
                    "virtual_datacenter_unit",
                    "ResourceType",
                    "name",
                    "CpuCores",
                    "Memory",
                    "Disk",
                ],
            },
            "definitions": {
                "rest_resources": {
                    "type": "object",
                    "required": ["size", "unit"],
                    "properties": {
                        "size": {"type": "integer", "description": "size"},
                        "unit": {"type": "string", "description": "unit"},
                    },
                }
            },
        }
        try:
            validate(request_params, request_params_schema)
        except ValidationError as e:
            raise serializers.ValidationError(
                "Error processing request_params due to {}".format(e)
            )


class ResourceReservationRequestSerializer(serializers.Serializer):
    id = serializers.CharField(required=False, read_only=True)
    lab_template_instance = serializers.CharField(required=True, read_only=False)
    lab_template_instance_id = serializers.CharField(
        read_only=False, required=False, source="lab_template_instance.id"
    )
    lab_template_instance_name = serializers.CharField(
        read_only=False, required=False, source="lab_template_instance.params"
    )
    requested_by = serializers.CharField(required=False, read_only=True)
    status = serializers.CharField(required=False, read_only=True)
    priority = serializers.CharField(required=False, read_only=True)
    request_params = serializers.JSONField(validators=[Validators.request_params])
    expiry_date = serializers.CharField(required=False, read_only=True)


class ResourceReservationReleaseSerializer(serializers.Serializer):
    id = serializers.CharField(required=False, read_only=True)
    requested_by = serializers.CharField(required=False, read_only=True)
    status = serializers.CharField(required=False, read_only=True)
    priority = serializers.CharField(required=False, read_only=True)
    request_params = serializers.CharField(required=False, read_only=True)
    expiry_date = serializers.CharField(required=False, read_only=True)


class ResourceReservationRequestViewSet(
    mixins.CreateModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet
):
    serializer_class = ResourceReservationRequestSerializer
    queryset = ResourceReservationRequest.objects.all()

    def perform_create(self, serializer):
        serializer.validated_data[
            "lab_template_instance"
        ] = LabTemplateInstance.objects.get(
            id=serializer.validated_data["lab_template_instance"]
        )
        obj = ResourceReservationRequest(**serializer.validated_data)
        obj.requested_by = self.request.user
        obj.priority = EntityType.objects.get(family="RequestPriority", name="Normal")
        obj.status = EntityType.objects.get(family="RequestStatus", name="Initial")
        try:
            with transaction.atomic():
                obj.save()
            return obj
        except Exception as e:
            log.exception("Error while saving release request details: {}".format(e))


class ResourceReservationReleaseViewSet(
    mixins.UpdateModelMixin, viewsets.GenericViewSet
):
    serializer_class = ResourceReservationReleaseSerializer
    queryset = ResourceReservationRequest.objects.all()
    api_name = "resource_reservation_release"

    def perform_update(self, serializer):
        resource_reservation_instance = serializer.instance
        resource_reservation_instance.status = EntityType.objects.get(
            family="RequestStatus", name="Released"
        )
        try:
            with transaction.atomic():
                resource_reservation_instance.save()
            return resource_reservation_instance
        except Exception as e:
            log.exception("Error while saving release request details: {}".format(e))
