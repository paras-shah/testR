from guardian.shortcuts import get_objects_for_user
from rest_framework import serializers
from rest_framework import viewsets
from rubrik.vision.core.permissions.permission_enums import (
    VirtualDataCenterUnitPermissions,
)
from rubrik.vision.core.models import VirtualDataCenterUnit
from rubrik.vision.core.permissions.virtual_datacenter_unit_permission import (
    VirtualDataCenterUnitPermission,
)


class VirtualDataCenterUnitSerializer(serializers.Serializer):
    id = serializers.CharField(required=False, read_only=True)
    name = serializers.CharField(required=False, read_only=True)
    import_rules = serializers.JSONField(required=False, read_only=True)


class VirtualDataCenterUnitViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = VirtualDataCenterUnitSerializer
    queryset = VirtualDataCenterUnit.objects.all()
    permission_classes = [VirtualDataCenterUnitPermission]

    def get_queryset(self):
        qs = super().get_queryset()
        qs = get_objects_for_user(
            self.request.user,
            VirtualDataCenterUnitPermissions.can_read_virtualdatacenterunit.name,
            klass=qs,
            with_superuser=False,
        )
        return qs
