from pathlib import Path
from os.path import basename

from django.contrib.auth.models import User
from django.contrib.auth import get_user_model

from rest_framework import viewsets
from rest_framework import serializers
from rest_framework import permissions, status

from rest_framework.response import Response
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework_jwt.settings import api_settings

from .users import UserSerializer
from rubrik.vision.lib.send_mail_utils import send_mail
from rubrik.vision.lib.send_mail_utils import validate_email
from rubrik.vision.site.settings import SMTP_CONFIGURATIONS

smtp_velocity_url = SMTP_CONFIGURATIONS["site_url"]
smtp_sender = SMTP_CONFIGURATIONS["sender"]
smtp_help_desk = SMTP_CONFIGURATIONS["helpdesk"]


class GenerateMagicLinkViewSet(APIView):
    """
    Send a magic link if user exist
    """

    serializer_class = UserSerializer
    permission_classes = (permissions.AllowAny,)
    api_name = "generate_magic_link"
    queryset = get_user_model().objects.all()
    http_method_names = ["post"]

    def post(self, request, format=None):
        """
        Handling call to magic link
        """
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        email_id = request.data["username"]

        # check valid format
        if validate_email(email_id) == False:
            return Response({"message": "Email is not correct."}, status=400)

        # check email exists
        user = User.objects.filter(username__iexact=email_id)
        if not user:
            return Response({"message": "No user exist."}, status=400)
        payload = jwt_payload_handler(user[0])
        token = jwt_encode_handler(payload)

        # send mail with magic link
        try:
            auth_url = smtp_velocity_url + "/#login/?token_url=" + token
            # encryption="STARTTLS"
            sender = smtp_sender
            receiver = email_id
            mail_subject = "Cloud Fabrik Authentication"
            mail_body = self.create_mail_body().format("RCF", auth_url, email_id)
            send_mail(sender, receiver, mail_subject, mail_body, "")
        except Exception as error:
            return Response(
                {
                    "message": "Error in sending mail with magic link. Please contact site administrator. "
                    + str(error)
                },
                status=400,
            )

        return Response(
            {
                "message": "Magic link to login to your account has been emailed to "
                + email_id
            },
            status=status.HTTP_200_OK,
        )

    def create_mail_body(self):
        """
        Email content 
        """
        htmlContent = """\
<html>
  <head></head>
  <body>
    <div>
        <p>
            <strong>{0}</strong> has received a request to send a magic link for the account <a href="mailto:{2}" target="_blank">{2}</a>
        </p>
        <p>If you did not request this change, please disregard this email.</p>
        <p>If you do wish to authenticate yourself, please click on this link : </p>
        <p><a href="{1}" target="_blank">here</a></p>
        <p>Please do not share this with others. </p>
        <p>If you need assistance, please view our help pages:</p>
        <p>Thank you for using <span>{0}</span></p>
    </div>
  </body>
</html>
"""
        return htmlContent


class GetHelpSerializer(serializers.Serializer):
    """ Serializer for Get Help
    params and template id need to be passed for POST
    """

    subject = serializers.CharField(required=True, write_only=True)
    message = serializers.CharField(required=True, write_only=True)
    attachment = serializers.FileField(required=False)


class GetHelpViewSet(APIView):
    """
    Send a mail to get help 
    """

    serializer_class = GetHelpSerializer
    permission_classes = (permissions.IsAuthenticated,)
    api_name = "get_help"
    http_method_names = ["post"]

    def post(self, request, format=None):
        """
        API to send an  email to get help 
        """
        mail_sender = None
        mail_form_data = request.data

        # return Response({"data": str(request.data),
        #                  "post": str(request.POST),
        #                  "files": str(request.FILES)})

        if request.user.is_authenticated:
            mail_sender = request.user.username

        mail_subject = "Rubrik Cloud Fabrik Help - " + mail_form_data["subject"]
        mail_body = self.get_help_mail_body().format(mail_form_data["message"])
        mail_attachment = mail_form_data["attachment"]

        # send mail with issue details
        response = "We have sent your request to helpdesk. A customer care representative will be contacting you soon on your mail id."

        try:
            mail_receiver = smtp_help_desk
            import logging

            send_mail(
                mail_sender, mail_receiver, mail_subject, mail_body, mail_attachment
            )

        except Exception as error:
            return Response(
                {
                    "message": str(error),
                    "TYPE": "{}:{}".format(type(mail_attachment), str(mail_attachment)),
                },
                status=400,
            )
        return Response({"message": response}, status=status.HTTP_200_OK)

    def get_help_mail_body(self):
        """
        get help mail content
        """
        htmlContent = """\
<html>
  <head></head>
  <body>
    <div>
        <p>{0}</p>
    </div>
  </body>
</html>
"""
        return htmlContent
