from drf_autoview.api import get_api_views_with_all_fields_readonly

from rubrik.vision.core import models
from .lab_template import LabTemplateViewSet
from .lab_template_instance import LabTemplateInstanceViewSet
from .lab_template_instance import DestroyLabTemplateInstanceViewSet
from .lab_template_by_vdu import LabTemplatesByVduViewSet
from .lab_template_instance_action import LabTemplateInstanceActionViewSet
from .virtual_datacenter_unit import VirtualDataCenterUnitViewSet
from .users import UserViewSet
from .resource_reservation_request import ResourceReservationRequestViewSet
from .resource_reservation_request import ResourceReservationReleaseViewSet

api_views = get_api_views_with_all_fields_readonly([])
api_views.extend(
    [
        LabTemplateViewSet,
        LabTemplateInstanceViewSet,
        LabTemplatesByVduViewSet,
        LabTemplateInstanceActionViewSet,
        VirtualDataCenterUnitViewSet,
        DestroyLabTemplateInstanceViewSet,
        ResourceReservationRequestViewSet,
        ResourceReservationReleaseViewSet,
    ]
)
