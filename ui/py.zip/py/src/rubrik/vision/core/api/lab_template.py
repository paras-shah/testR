from django_filters.rest_framework import DjangoFilterBackend
from guardian.shortcuts import get_objects_for_user
from django_filters import rest_framework as backend_filters
from rest_framework import serializers
from rest_framework import viewsets

from rubrik.vision.core.models import LabTemplate
from rubrik.vision.core.permissions.permission_enums import LabTemplatePermissions
from rubrik.vision.core.permissions.lab_template_permission import LabTemplatePermission


class LabTemplateSerializer(serializers.Serializer):
    id = serializers.CharField(required=False, read_only=True)
    name = serializers.CharField(required=False, read_only=True)
    description = serializers.JSONField(required=False, read_only=True)
    vdu_name = serializers.CharField(
        required=False, read_only=True, source="virtualdatacenterunit.name"
    )
    vdu_id = serializers.CharField(
        required=False, read_only=True, source="virtualdatacenterunit.id"
    )
    datacenter = serializers.CharField(
        required=False, read_only=True, source="virtualdatacenterunit.datacenter"
    )
    version = serializers.CharField(required=False, read_only=True)
    lab_stats = serializers.SerializerMethodField(read_only=True)
    lab_params = serializers.JSONField(required=False, read_only=True)
    status = serializers.CharField(required=False, read_only=True)
    meta_data_json = serializers.JSONField(required=False, read_only=True)
    logo = serializers.CharField(required=False, read_only=True)

    def get_lab_stats(self, obj):
        return obj.lab_spec.get("stats") if obj.lab_spec else None


class LabTemplateFilter(backend_filters.FilterSet):
    """
    Custom filtering to get lab templates by vdu
    """

    vdu_id = backend_filters.CharFilter(
        field_name="virtualdatacenterunit__id", lookup_expr="exact"
    )
    datacenter = backend_filters.CharFilter(
        field_name="virtualdatacenterunit__datacenter__name", lookup_expr="exact"
    )
    vdu_name = backend_filters.CharFilter(
        field_name="virtualdatacenterunit__name", lookup_expr="exact"
    )
    name = backend_filters.CharFilter(field_name="name", lookup_expr="exact")

    class Meta:
        model = LabTemplate
        fields = ["vdu_id", "name", "vdu_name", "datacenter"]


class LabTemplateViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = LabTemplateSerializer
    queryset = LabTemplate.objects.all().order_by(
        "virtualdatacenterunit", "name", "-created_date"
    )
    permission_classes = [LabTemplatePermission]
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ["virtualdatacenterunit__id", "name"]

    def get_queryset(self):
        qs = super().get_queryset()
        qs = get_objects_for_user(
            self.request.user,
            LabTemplatePermissions.can_read_labtemplate.name,
            klass=qs,
            with_superuser=False,
        )
        return qs

    filter_backends = (backend_filters.DjangoFilterBackend,)
    filterset_class = LabTemplateFilter
