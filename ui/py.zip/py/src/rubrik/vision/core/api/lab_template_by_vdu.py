from rest_framework import filters
from rest_framework import serializers
from rest_framework import viewsets

from django_filters import rest_framework as backend_filters
from guardian.shortcuts import get_objects_for_user
from rubrik.vision.core.permissions.permission_enums import LabTemplatePermissions
from rubrik.vision.core.permissions.lab_template_permission import LabTemplatePermission

from rubrik.vision.core.models import LabTemplate


class LabTemplateSerializer(serializers.Serializer):
    id = serializers.CharField(required=False, read_only=True)
    description = serializers.JSONField(required=False, read_only=True)
    version = serializers.CharField(required=False, read_only=True)
    lab_stats = serializers.SerializerMethodField(read_only=True)
    lab_params = serializers.JSONField(required=False, read_only=True)
    logo = serializers.CharField(required=False, read_only=True)

    def get_lab_stats(self, obj):
        return obj.lab_spec.get("stats") if obj.lab_spec else None


class LabTemplateSerializerByVdu(serializers.Serializer):
    name = serializers.CharField(required=False, read_only=True)
    vdu_name = serializers.CharField(
        required=False, read_only=True, source="virtualdatacenterunit.name"
    )
    vdu_id = serializers.CharField(
        required=False, read_only=True, source="virtualdatacenterunit.id"
    )
    datacenter = serializers.CharField(
        required=False, read_only=True, source="virtualdatacenterunit.datacenter"
    )
    versions = serializers.SerializerMethodField(read_only=True)

    def get_versions(self, obj):
        # we only return latest five versions
        qs = LabTemplate.objects.all()
        qs = get_objects_for_user(
            self.context["request"].user,
            LabTemplatePermissions.can_read_labtemplate.name,
            klass=qs,
            with_superuser=False,
        )
        qs = qs.filter(
            virtualdatacenterunit=obj.virtualdatacenterunit,
            name=obj.name,
            repo=obj.repo,
        ).order_by("virtualdatacenterunit", "name", "-created_date")[:5]
        serializer = LabTemplateSerializer(qs, many=True)
        return serializer.data


class LabTemplateFilter(backend_filters.FilterSet):
    """
    Custom filtering to get lab templates by vdu
    """

    vdu_id = backend_filters.CharFilter(
        field_name="virtualdatacenterunit__id", lookup_expr="exact"
    )
    vdu_name = backend_filters.CharFilter(
        field_name="virtualdatacenterunit__name", lookup_expr="exact"
    )
    datacenter = backend_filters.CharFilter(
        field_name="virtualdatacenterunit__datacenter__name", lookup_expr="exact"
    )
    name = backend_filters.CharFilter(field_name="name", lookup_expr="exact")

    class Meta:
        model = LabTemplate
        fields = ["vdu_id", "vdu_name", "datacenter", "name"]


class LabTemplatesByVduViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = LabTemplateSerializerByVdu
    queryset = LabTemplate.objects.all().distinct("virtualdatacenterunit", "name")
    api_name = "lab_template_by_vdu"
    permission_classes = [LabTemplatePermission]
    filter_backends = (backend_filters.DjangoFilterBackend, filters.SearchFilter)
    filterset_class = LabTemplateFilter
    # Choices are:
    # accessible_by,
    # change_set,
    # created_date,
    # description,
    # id,
    # lab_params,
    # lab_spec,
    # labtemplategroupobjectpermission,
    # labtemplateinstance,
    # labtemplateuserobjectpermission,
    # modified_date,
    # name,
    # repo,
    # repo_id,
    # version,
    # virtualdatacenterunit,
    # virtualdatacenterunit_id"
    search_fields = ["virtualdatacenterunit__name", "version", "name", "repo__name"]

    def get_queryset(self):
        qs = super().get_queryset()
        qs = get_objects_for_user(
            self.request.user,
            LabTemplatePermissions.can_read_labtemplate.name,
            klass=qs,
            with_superuser=False,
        )
        return qs
