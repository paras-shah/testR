from rest_framework import serializers
from rest_framework import viewsets
from rest_framework_jwt.settings import api_settings

from django.contrib.auth.models import User
from django.contrib.auth import get_user_model


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["username"]
        depth = 2


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = get_user_model().objects.all()
    serializer_class = UserSerializer
    filter_fields = ["username"]
