from django.contrib.postgres.fields import JSONField
from django.db import models

from .base_model import BaseModel
from .entity_type import EntityType
from guardian.models import UserObjectPermissionBase
from guardian.models import GroupObjectPermissionBase


class DataCenter(BaseModel):
    """DataCenter Model.

    Indicates each physical location
    DataCenter(DC) contains field name, location and data
    name should be name of DataCenter
    location is the entity type to family location
    data will contain key value pair for each DC's informtaion
    """

    name = models.CharField(max_length=256, unique=True)
    location = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "Location"},
    )
    data = JSONField(null=True, blank=True)
    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "DataCenterStatus"},
    )

    string_summary_field = ["name"]

    class Meta:
        default_permissions = ()
        permissions = (
            ("can_create_datacenter", "Create DC"),
            ("can_read_datacenter", "Read DC"),
            ("can_update_datacenter", "Update DC"),
            ("can_delete_datacenter", "Delete DC"),
        )


class DataCenterUserObjectPermission(UserObjectPermissionBase):
    content_object = models.ForeignKey(DataCenter, on_delete=models.CASCADE)


class DataCenterGroupObjectPermission(GroupObjectPermissionBase):
    content_object = models.ForeignKey(DataCenter, on_delete=models.CASCADE)
