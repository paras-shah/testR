from django.db import models
from .base_model import BaseModel
from .entity_type import EntityType
from .data_center import DataCenter


class ResourcePool(BaseModel):
    """ResourcePool Model.

    Group of recources under a given datacenter.

    Attr:
       name: Name of the resource pool.
       datacenter: data center where the resource pool belongs to.
       state: State of the resource pool.
       status: Status of the resource pool.
    """

    name = models.CharField(max_length=256)
    datacenter = models.ForeignKey(
        DataCenter, on_delete=models.CASCADE, related_name="+"
    )

    state = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourcePoolState"},
    )
    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourcePoolStatus"},
    )

    string_summary_field = ["name", "datacenter"]

    class Meta:
        unique_together = (("name", "datacenter"),)
