from django.db import models
from .base_model import BaseModel
from .entity_type import EntityType
from .resource_pool import ResourcePool
from .resource_property_type import ResourcePropertyType


class ResourcePoolCapacity(BaseModel):
    """ResourcePoolCapacity Model.

    Capacity definition of a resource pool.

    Attr:
       resource_pool: Resource Pool.
       resource_type: Specifies which resource type is. e.g ESX
       resource_property_type: Specifies which property type is. e.g CPU
       total_capacity: Total capacity of aggregated capacity or resources under this resource pool.
       useable_capacity: Actual usable  capacity or resources under this resource pool.

          e.g if we have one resource pool with resource type ESX which have 1 CPU
          total_capacity = "1 ESX 1 CPU => 1.
          useable_capacity = "1 ESX 1 CPU => 1.
          free_capacity = useable_capacity - used_capacity


          Now if that ESX caught on fire the new representation will be
          total_capacity = "1 ESX 1 CPU => 1.
          useable_capacity = "1 ESX 1 CPU => 0.
          free_capacity = useable_capacity - used_capacity => 0

       state: State of the resource pool.
       status: Status of the resource pool.
    """

    resource_pool = models.ForeignKey(
        ResourcePool, on_delete=models.CASCADE, related_name="resource_pool_capacity"
    )
    resource_type = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourceType"},
    )

    resource_property_type = models.ForeignKey(
        ResourcePropertyType, on_delete=models.PROTECT, related_name="+"
    )
    total_capacity = models.FloatField()
    useable_capacity = models.FloatField()
    used_capacity = models.FloatField()
    free_capacity = models.FloatField()

    string_summary_field = [
        "resource_pool",
        "resource_pool",
        "resource_property_type",
        "total_capacity",
        "used_capacity",
        "free_capacity",
    ]

    class Meta:
        unique_together = (
            ("resource_pool", "resource_type", "resource_property_type"),
        )
