from django.contrib.postgres.fields import JSONField
from django.db import models
from django.contrib.auth import get_user_model
from .base_model import BaseModel
from .entity_type import EntityType
from rubrik.vision.core.models import LabTemplateInstance

AUTH_USER_MODEL = get_user_model()


class StatusMappingDoesNotMatchException(Exception):
    pass


class ResourceReservationRequest(BaseModel):
    """ResourceReservationRequest Model.

    Attr:
        lab_template_instance_id: lab instance's resource reservation request
       requested_by: User initiated reservation request.
       status: status of reservation request.
       request_params: Request reservation  data.
       data: Json Field to update resource reservation e.g aggregate_values.
       expiry_date: Datetime, when this reservation request will be expired.
    """

    lab_template_instance = models.OneToOneField(
        LabTemplateInstance, on_delete=models.PROTECT, default=None, null=True
    )
    requested_by = models.ForeignKey(AUTH_USER_MODEL, on_delete=models.PROTECT)
    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ReservationStatus"},
    )
    priority = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "RequestPriority"},
    )
    status_details = JSONField(null=True, blank=True)
    request_params = JSONField(null=True, blank=True)
    data = JSONField(null=True, blank=True)
    expiry_date = models.DateTimeField(blank=True, null=True)
    string_summary_field = ["requested_by", "status"]

    def save(self, *args, **kwargs):
        STATUS_MAP = {
            "Initial": ["PendingReservation", "PendingRelease"],
            "PendingReservation": ["ReservationFailed", "Reserved"],
            "ReservationFailed": ["PendingRelease"],
            "Reserved": ["PendingRelease"],
            "PendingRelease": ["Released", "ReleaseFailed"],
            "Released": ["Initial"],
            "ReleaseFailed": ["PendingRelease"],
        }
        if hasattr(self, "json_field_schema_map"):
            self.validate_json_fields()

        using = kwargs.get("using", None)
        db = using if using is not None else self._state.db
        db_instance = self.__class__._default_manager.using(db).filter(pk=self.pk).first()
        if db_instance:
            if db_instance.status.name in STATUS_MAP and self.status.name not in STATUS_MAP[db_instance.status.name]:
                raise StatusMappingDoesNotMatchException(
                    "Cannot change from {0} to {1}".format(self.status.name, db_instance.status.name)
                )

        super().save(*args, **kwargs)

