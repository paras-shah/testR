from django.contrib.postgres.fields import JSONField
from django.db import models
from .base_model import BaseModel
from .entity_type import EntityType
from .resource_pool import ResourcePool
from .resource_property_type import ResourcePropertyType
from .resource_property import ResourceProperty


class Resource(BaseModel):
    """Resource Model.

    Attr:
       name: Resource name.
       resource_type: Resource types e.g. ESX .
       resource_pool: resource pool the resource belongs to.
       data: Resource data.
       state: Resource state.
       status: Resource status.
       resource_properties: Resource properties.
    """

    name = models.CharField(max_length=256, unique=True)
    resource_type = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourceType"},
    )
    resource_pool = models.ForeignKey(
        ResourcePool, on_delete=models.PROTECT, related_name="+"
    )
    data = JSONField(null=True, blank=True)
    state = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourceState"},
    )
    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourceStatus"},
    )

    resource_properties = models.ManyToManyField(
        ResourcePropertyType, related_name="+", through="ResourceProperty",
    )
    shareable = models.BooleanField(blank=False, null=False, default=True)

    string_summary_field = ["name", "resource_type", "resource_pool", "state", "status"]
