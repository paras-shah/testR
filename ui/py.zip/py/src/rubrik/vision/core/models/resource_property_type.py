from django.db import models
from .base_model import BaseModel
from .entity_type import EntityType


class ResourcePropertyType(BaseModel):
    """ResourceProperty Model.

    Attr:
       name: Resource property name.
       aggregate_type: Aggregator stratedgy Entity type value e.g sum, max
    """

    name = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourcePropertyTypes"},
    )
    aggregate_type = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "AggregateType"},
    )

    def __str__(self):
        return self.name.name
