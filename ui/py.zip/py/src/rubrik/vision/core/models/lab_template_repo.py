from django.db import models
from django.contrib.postgres.fields import JSONField

from rubrik.vision.lib.encryption_utils import decryption, encryption
from rubrik.vision.site.settings import VISION_ENCRYPTION_KEY
from .base_model import BaseModel
from .entity_type import EntityType


class LabTemplateRepo(BaseModel):
    """LabTemplateRepo Model.

    Row for each LabSpecRepo by commit.
    LabTemplateRepo id should be unique and un-predictable.
    LabTemplateRepo should know the time it was created.
    LabTemplateRepo should know the time it was last updated.
    LabTemplateRepo name should be the name of workflow.
    LabTemplateRepo needs the url from git and must be unique for each.
    LabTemplateRepo token gives access to git repo.
    LabTemplateRepo import_workflow contains details for each workflow per iteration.
    LabTemplateRepo status controls the current state
    LabTemplateRepo get_token property returns a decrypted token
    LabTemplateRepo set_token method encrypts token
    """

    name = models.CharField(max_length=256, blank=True, null=True)
    url = models.CharField(max_length=1024, blank=True, null=True)
    token = models.TextField(blank=True, null=True)
    branch = models.CharField(max_length=256, blank=True, null=True)
    latest_changeset = models.CharField(max_length=256, blank=True, null=True)
    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "LabTemplateRepoStatus"},
    )

    string_summary_field = ["name", "branch"]

    def __str__(self):
        return self.name

    class Meta:
        unique_together = ("name", "branch", "url")

    @property
    def get_token(self):
        """Token decryption

        :return: decrypted token as unicode
        """
        return u"""{}\n""".format(
            decryption(data=self.token, encryption_key=VISION_ENCRYPTION_KEY).replace(
                "\r\n", "\n"
            )
        )

    def set_token(self, token):
        """Token encryption

        :param token:
        """
        self.token = encryption(data=token, encryption_key=VISION_ENCRYPTION_KEY)
