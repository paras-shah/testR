from django.contrib.auth.models import Group
from django.contrib.postgres.fields import JSONField
from django.db import models

from .base_model import BaseModel
from .entity_type import EntityType
from .lab_template_repo import LabTemplateRepo
from .virtual_data_center_unit import VirtualDataCenterUnit

from guardian.models import UserObjectPermissionBase
from guardian.models import GroupObjectPermissionBase
from rubrik.vision.core.permissions.permission_enums import LabTemplatePermissions


class LabTemplate(BaseModel):
    """LabTemplate Model.
        LabTemplate name,vdu, version should be unique
        LabTemplate referred by various LabTemplateInstance models who have need to keep track
         of lab template.
        LabTemplate description has a long an
        LabTemplate lab_spec contains create, release and meta data as json
        LabTemplate lab_params contains parameter details
        LabTemplate repo is the associated lab spec repository
        LabTemplate status LabTemplateAvailabilityStatus
        LabTemplate logo contains base64 binary of image (svg/png)
        LabTemplate meta_data_json contains meta.yaml
        LabTemplate template_path contains lab path name
    """

    name = models.CharField(max_length=256)
    description = JSONField(null=True, blank=True)
    version = models.CharField(max_length=256)
    lab_spec = JSONField(null=True, blank=True)
    lab_params = JSONField(null=True, blank=True)
    accessible_by = models.ManyToManyField(Group)
    change_set = models.CharField(max_length=256, blank=True, null=True)
    repo = models.ForeignKey(
        LabTemplateRepo,
        on_delete=models.CASCADE,
        related_name="+",
        blank=True,
        null=True,
    )
    virtualdatacenterunit = models.ForeignKey(
        VirtualDataCenterUnit,
        on_delete=models.CASCADE,
        related_name="+",
        blank=True,
        null=True,
    )
    meta_data_json = JSONField(null=True, blank=True)
    """
    On import use meta.json name as lab template name
        - Add a new column, which says template path
    Lab template have status
        - template name regex based status
    Process a new file from lab-spec
        - logo.svg (encoded base64 text field)
    
    """
    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "LabTemplateAvailabilityStatus"},
        blank=True,
        null=True
    )
    template_path = models.CharField(max_length=256)
    logo = models.TextField(max_length=None, blank=True, null=True)

    class Meta:
        unique_together = (("template_path", "virtualdatacenterunit", "version", "repo"),)
        default_permissions = ()
        permissions = tuple([(i.name, i.value) for i in LabTemplatePermissions])

    string_summary_field = ["template_path", "virtualdatacenterunit", "version"]


class LabTemplateUserObjectPermission(UserObjectPermissionBase):
    content_object = models.ForeignKey(LabTemplate, on_delete=models.CASCADE)


class LabTemplateGroupObjectPermission(GroupObjectPermissionBase):
    content_object = models.ForeignKey(LabTemplate, on_delete=models.CASCADE)

