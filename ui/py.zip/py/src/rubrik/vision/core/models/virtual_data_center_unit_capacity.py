from django.db import models
from .base_model import BaseModel
from .entity_type import EntityType
from .virtual_data_center_unit import VirtualDataCenterUnit
from .resource_property_type import ResourcePropertyType


class VirtualDataCenterUnitCapacity(BaseModel):
    """VirtualDataCenterUnitCapacity Model.

    Capacity definition of a virtual datacenter unit.

    Attr:
        virtual_datacenter_unit: Virtual datacenter.
        resource_type: Specifies which resource type is. e.g ESX
        resource_property_type: Specifies which property type is. e.g CPU
        total_capacity: Total capacity of aggregated capacity or resources under this resource pool.
        useable_capacity: Actual usable  capacity or resources under this resource pool.

            e.g Assume we have one virtual datacenter unit which has shares in two resource pools.
            If the reresource pools have only one resource type ESX which have 1 CPU each,
            total_capacity = "2 * (1 ESX 1 CPU => 1).
            useable_capacity = "2 * (1 ESX 1 CPU => 1).
            free_capacity = 0 if all resource are being used 1, 2 otherwise.

            Now if one ESX on one of the resource pool caught on fire the new representation will be
            total_capacity = "2 * (1 ESX 1 CPU => 1).
            useable_capacity = "1 ESX 1 CPU => 1.
            free_capacity = useable_capacity - used_capacity

        state: State of the resource pool.
        status: Status of the resource pool.
    """

    virtual_datacenter_unit = models.ForeignKey(
        VirtualDataCenterUnit, on_delete=models.CASCADE, related_name="+"
    )
    resource_type = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourceType"},
    )

    resource_property_type = models.ForeignKey(
        ResourcePropertyType, on_delete=models.PROTECT, related_name="+"
    )
    total_capacity = models.FloatField()
    useable_capacity = models.FloatField()
    used_capacity = models.FloatField()
    free_capacity = models.FloatField()

    string_summary_field = [
        "virtual_datacenter_unit",
        "resource_type",
        "resource_property_type",
        "total_capacity",
        "used_capacity",
        "free_capacity",
    ]

    class Meta:
        unique_together = (
            ("virtual_datacenter_unit", "resource_type", "resource_property_type"),
        )
