from django.db import models
from .base_model import BaseModel
from .resource import Resource
from .resource_reservation_request import ResourceReservationRequest


class ResourceReservation(BaseModel):
    """ResourceReservation Model.

    Attr:
       resource_reservation_request: Resource Reservation Request
       resource: Resource created from @resource_reservation_request.data
       resource_reservation_name: Resource Reservation name.
    """

    resource_reservation_request = models.ForeignKey(
        ResourceReservationRequest, on_delete=models.CASCADE, related_name="+"
    )
    resource = models.ForeignKey(Resource, on_delete=models.CASCADE, related_name="+")
    resource_reservation_name = models.CharField(max_length=256)

    string_summary_field = ["resource_reservation_request", "resource"]

    class Meta:
        unique_together = (("resource_reservation_request", "resource", "resource_reservation_name"),)
