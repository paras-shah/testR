from django.contrib.postgres.fields import JSONField
from django.db import models

from .base_model import BaseModel


class GlobalConfig(BaseModel):
    """GlobalConfig Model.

    GlobalConfig name should be unique.
    GlobalConfig hold all configs for the webservice.
    GlobalConfig should be consumed by any current or future feature
     to enable configuration driven behavior.
    """

    data = JSONField(null=True, blank=True)
    description = models.CharField(max_length=256)
    name = models.CharField(max_length=256, unique=True)

    string_summary_field = ["name"]
