from django.contrib.auth import get_user_model
from django.contrib.postgres.fields import JSONField
from django.db import models
from django.utils import timezone
from .base_model import BaseModel
from .entity_type import EntityType
from .lab_template import LabTemplate
from guardian.models import UserObjectPermissionBase
from rubrik.vision.core.permissions.permission_enums import (
    LabTemplateInstancePermissions,
)
from guardian.models import GroupObjectPermissionBase

AUTH_USER_MODEL = get_user_model()


class LabTemplateInstance(BaseModel):
    start_date = models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    params = JSONField(blank=True)
    priority = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "Priority"},
    )
    instance_for = models.ForeignKey(AUTH_USER_MODEL, on_delete=models.PROTECT)

    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "RequestStatus"},
    )
    status_message = models.CharField(max_length=1024, blank=True, null=True)

    string_summary_field = ["instance_for", "priority", "status"]
    lab_template = models.ForeignKey(LabTemplate, on_delete=models.CASCADE, null=True)
    lab_details = JSONField(null=True, blank=True)

    # This which never be serialzized for regular user
    # It will store create/delete job_req_id from vcube
    # It will also store output of create and delete
    # The lab template instance processor task should on
    # moving lab from processing to Ready should populate lab_details
    # from lab_internal_details
    lab_internal_create_details = JSONField(null=True, blank=True)
    lab_internal_destroy_details = JSONField(null=True, blank=True)

    class Meta:
        default_permissions = ()
        permissions = tuple([(i.name, i.value) for i in LabTemplateInstancePermissions])

    def time_remaining(self):
        if self.start_date and self.end_date:
            return str(self.end_date - timezone.now()).split(".")[0]
        return None


class LabTemplateInstanceUserObjectPermission(UserObjectPermissionBase):
    content_object = models.ForeignKey(LabTemplateInstance, on_delete=models.CASCADE)


class LabTemplateInstanceGroupObjectPermission(GroupObjectPermissionBase):
    content_object = models.ForeignKey(LabTemplateInstance, on_delete=models.CASCADE)
