from django.contrib.postgres.fields import JSONField
from django.db import models
from .base_model import BaseModel


class ResourceProperty(BaseModel):
    """ResourceProperty Model.

    Attr:
       resource: Specifies The resrouce
       resource_property_type: Type of resource property.
       value: specifies value of the property
    """

    resource = models.ForeignKey("Resource", on_delete=models.CASCADE,)
    resource_property_type = models.ForeignKey(
        "ResourcePropertyType", on_delete=models.PROTECT
    )
    value = JSONField(null=True, blank=True)
    useable_capacity = models.FloatField(null=False, blank=False, default=0)
    used_capacity = models.FloatField(null=False, blank=False, default=0)
    free_capacity = models.FloatField(null=False, blank=False, default=0)
