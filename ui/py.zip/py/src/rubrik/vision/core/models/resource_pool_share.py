from django.db import models
from .base_model import BaseModel
from .virtual_data_center_unit import VirtualDataCenterUnit
from .resource_pool import ResourcePool
from .resource_property_type import ResourcePropertyType
from .entity_type import EntityType
from .resource_pool_capacity import ResourcePoolCapacity


class ResourcePoolShare(BaseModel):
    """ResourcePoolShare Model.

    Attr:
        virtual_datacenter_unit: VDU to share resource of.
        resource_pool: Resource Pool sharing part/whole of vdu.
        resource_type: Resource type to be shared e.g ESX.
        resource_property_type: Resource property type of the resource type to be shared with. e.g. ESX CPU.
        useable_capacity: Total usable shared capacity limit vdu can use on the resource pool.
            This is non computed value.
        used_capacity: Total used capacity, this will be dynamically computed as resources are affected.
            under the resource pool @attr resource_pool
        free_capacity: Free available capacity useable_capacity - used_capacity
    """

    virtual_datacenter_unit = models.ForeignKey(
        VirtualDataCenterUnit, on_delete=models.PROTECT, related_name="vdu_share"
    )
    resource_pool = models.ForeignKey(
        ResourcePool, on_delete=models.PROTECT, related_name="resource_pool_share"
    )
    resource_type = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ResourceType"},
    )

    resource_property_type = models.ForeignKey(
        ResourcePropertyType, on_delete=models.PROTECT, related_name="+"
    )
    useable_capacity = models.FloatField()
    used_capacity = models.FloatField()
    free_capacity = models.FloatField()

    string_summary_field = [
        "virtual_datacenter_unit",
        "resource_pool",
        "resource_type",
        "resource_property_type",
    ]

    class Meta:
        unique_together = (
            (
                "virtual_datacenter_unit",
                "resource_pool",
                "resource_type",
                "resource_property_type",
            ),
        )
