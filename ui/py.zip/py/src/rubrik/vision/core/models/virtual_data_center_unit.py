from django.contrib.auth.models import Group
from django.contrib.postgres.fields import JSONField
from django.db import models
from django.db import transaction
from guardian.models import GroupObjectPermissionBase
from guardian.models import UserObjectPermissionBase

from rubrik.vision.core.permissions.permission_enums import VirtualDataCenterUnitPermissions
from rubrik.vision.core.permissions.shortcuts import add_permission_to_vdu_members_group
from rubrik.vision.core.permissions.shortcuts import add_permission_to_vdu_owners_group
from rubrik.vision.core.permissions.shortcuts import add_vdu_members_group_on_vdu_obj
from rubrik.vision.core.permissions.shortcuts import add_vdu_owners_group_on_vdu_obj
from rubrik.vision.core.permissions.shortcuts import get_group_perms
from rubrik.vision.core.permissions.shortcuts import remove_perm
from .base_model import BaseModel
from .data_center import DataCenter
from .lab_template_repo import LabTemplateRepo


class VirtualDataCenterUnit(BaseModel):
    """ VirtualDataCenterUnit Model.

        Attributes:
           name: Name of the virtual data center unit.
           datacenter: Which datacenter it belongs to.
           lab_template_repo: lab templates associated with this vdu.
           policy: Virtual datacenter unit usage policy.
    """

    name = models.CharField(max_length=256)
    datacenter = models.ForeignKey(
        DataCenter, on_delete=models.CASCADE, related_name="+"
    )
    lab_template_repo = models.ManyToManyField(
        LabTemplateRepo,
        through="VirtualDataCenterUnitLinkLabTemplateRepo",
        through_fields=("vdu", "repo"),
    )
    policies = JSONField(null=True, blank=True)

    string_summary_field = ["name", "datacenter"]

    class Meta:
        unique_together = (("name", "datacenter"),)
        default_permissions = ()
        permissions = tuple(
            [(i.name, i.value) for i in VirtualDataCenterUnitPermissions]
        )

    def delete(self, using=None, keep_parents=False):
        with transaction.atomic():
            super().delete(using=None, keep_parents=False)
            group_name_owner = "vdu_owners__{0}".format(self.id)
            group_name_member = "vdu_member__{0}".format(self.id)

            group_owner = Group.objects.get(name=group_name_owner)
            group_member = Group.objects.get(name=group_name_member)
            group_owner.delete()
            group_member.delete()

    def save(self, *args, **kwargs):
        with transaction.atomic():
            super().save(*args, **kwargs)
            group_name_owner = "vdu_owners__{0}".format(self.id)
            group_owner, _ = Group.objects.get_or_create(name=group_name_owner)
            group_name_member = "vdu_member__{0}".format(self.id)
            group_member, _ = Group.objects.get_or_create(name=group_name_member)
            group_owner.permissions.clear()
            """
            Add Permissions for Group Owner
            """
            for perm in get_group_perms(group_member, self):
                remove_perm(perm, group_member, self)
            # Add perms owners
            add_permission_to_vdu_owners_group(group_owner)
            add_vdu_owners_group_on_vdu_obj(group_owner, self)

            """
            Add Permissions for Group Member
            """
            group_member.permissions.clear()
            for perm in get_group_perms(group_member, self):
                remove_perm(perm, group_member, self)

            # Add perms members
            add_permission_to_vdu_members_group(group_member)
            add_vdu_members_group_on_vdu_obj(group_member, self)


class VirtualDataCenterUnitLinkLabTemplateRepo(models.Model):
    vdu = models.ForeignKey(VirtualDataCenterUnit, on_delete=models.CASCADE)
    repo = models.ForeignKey(LabTemplateRepo, on_delete=models.CASCADE)
    import_rules = JSONField(null=True, blank=True)

    class Meta:
        unique_together = (("vdu", "repo"),)


class VirtualDataCenterUnitUserObjectPermission(UserObjectPermissionBase):
    content_object = models.ForeignKey(VirtualDataCenterUnit, on_delete=models.CASCADE)


class VirtualDataCenterUnitGroupObjectPermission(GroupObjectPermissionBase):
    content_object = models.ForeignKey(VirtualDataCenterUnit, on_delete=models.CASCADE)
