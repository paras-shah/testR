from django.contrib.auth import get_user_model
from django.contrib.postgres.fields import JSONField
from django.db import models

from .base_model import BaseModel
from .entity_type import EntityType
from .lab_template_instance import LabTemplateInstance

AUTH_USER_MODEL = get_user_model()


class LabTemplateInstanceAction(BaseModel):
    """LabTemplateInstanceAction Model.
        action_instance_id contains name, lab_template_instance, id
        action_spec contain key value pair of action specifications
        params contains key value pair of action to be performed on
        start time and end time represents action's job start and end time
    """

    name = models.CharField(max_length=1024)
    action_spec = JSONField(null=True, blank=True)
    params = JSONField(null=True, blank=True)  # ui will send list of objects
    requested_by = models.ForeignKey(AUTH_USER_MODEL, on_delete=models.PROTECT)

    status = models.ForeignKey(
        EntityType,
        on_delete=models.PROTECT,
        related_name="+",
        limit_choices_to={"family": "ActionStatus"},
    )
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    lab_template_instance = models.ForeignKey(
        LabTemplateInstance, on_delete=models.PROTECT
    )
    action_instance_id = models.CharField(max_length=256, null=True, blank=True)

    def duration(self):
        if self.start_time and self.end_time:
            return self.end_time - self.start_time

    def save(self, *args, **kwargs):

        # Shall execute if object does not exist
        if self.created_date is None:
            # Filter querset with lab template instance
            queryset = LabTemplateInstanceAction.objects.filter(lab_template_instance=self.lab_template_instance)
            # Shall return if object with status initial and same name exists
            if queryset.filter(status__name__in=["Initial"],name=self.name,).exists():
                return
            else:
                # set action_instance_id = name + lti + 1 when object with lab template instance does not exist
                if not queryset.exists():
                    action_id = 1
                    self.action_instance_id = "_".join(
                        [self.name, str(self.lab_template_instance.id), str(action_id)]
                    )
                # get latest action_instance_id and increment id by 1
                else:
                    previous_action_id_obj = queryset.latest("created_date")
                    previous_action_id_index = previous_action_id_obj.action_instance_id.rindex("_")
                    previous_action_id = previous_action_id_obj.action_instance_id[previous_action_id_index + 1:]
                    action_id = int(previous_action_id) + 1
                    self.action_instance_id = "_".join(
                        [self.name, str(self.lab_template_instance.id), str(action_id)]
                    )

        super().save(*args, **kwargs)

