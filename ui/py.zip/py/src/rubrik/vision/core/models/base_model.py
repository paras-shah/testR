import uuid

from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.urls import reverse
from django.utils import timezone
from jsonschema import validate


class MidAirCollision(Exception):
    pass


class BaseModel(models.Model):
    """Base Class for all model.

    Layout
        Fields
            local fields
            Related fields (Fk, M2M)
        Meta Class
        Methods
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_date = models.DateTimeField(
        auto_now_add=True, editable=False, db_index=True
    )
    modified_date = models.DateTimeField(auto_now=True, editable=False)

    string_summary_field = None

    class Meta:
        abstract = True
        ordering = ["-created_date"]

    def validate_json_fields(self):
        """ Validate json schema of fileds.

        Read
            https://python-jsonschema.readthedocs.io/en/latest/validate/#
            http://json-schema.org/example1.html

        Generate schema: https://www.jsonschema.net/#
        """
        for field, schema in self.json_field_schema_map.items():
            field = getattr(self, field)
            if not field:
                continue
            validate(field, schema)

    def save(self, *args, **kwargs):
        if hasattr(self, "json_field_schema_map"):
            self.validate_json_fields()

        self.modified_date = timezone.now()
        using = kwargs.get("using", None)
        db = using if using is not None else self._state.db
        db_instance = (
            self.__class__._default_manager.using(db).filter(pk=self.pk).first()
        )
        if db_instance:
            if db_instance.modified_date > self.modified_date:
                raise MidAirCollision(
                    "Database is already changed by someone, refresh and try again if needed."
                )

        super().save(*args, **kwargs)

    def get_change_url(self):
        content_type = ContentType.objects.get_for_model(self.__class__)
        return reverse(
            "admin:%s_%s_change" % (content_type.app_label, content_type.model),
            args=(self.id,),
        )

    def get_str_repr(self, attributes, separator=":"):
        if attributes:
            return "{}".format(separator).join(
                ["{}".format(getattr(self, i)) for i in attributes]
            )
        return str(self.id)

    def __str__(self):
        return self.get_str_repr(self.string_summary_field)
