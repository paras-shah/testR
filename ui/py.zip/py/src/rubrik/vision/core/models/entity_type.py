from django.db import models

from .base_model import BaseModel


class EntityType(BaseModel):
    """EntityType Model.

    EntityType name and family should be unique.
    EntityType family is category in which resource type falls.
    EntityType will be consumed by any model which have need to
    store/track things by types.
    """

    description = models.CharField(max_length=256)
    family = models.CharField(max_length=256)
    name = models.CharField(max_length=256)

    string_summary_field = ["name"]

    class Meta:
        unique_together = ("name", "family")
