"""vision URL Configuration"""
from django.conf.urls import url
from django.contrib import admin
from django.urls import include
from django.urls import path
from rest_framework.schemas import get_schema_view
from rest_framework_jwt.views import obtain_jwt_token
from rest_framework_jwt.views import verify_jwt_token
from rest_framework_jwt.views import refresh_jwt_token

from rubrik.vision.core.api.generate_magic_link import GenerateMagicLinkViewSet
from rubrik.vision.core.api.generate_magic_link import GetHelpViewSet


from .api import router

urlpatterns = [
    path("api/token-auth/", obtain_jwt_token),  # login
    path(
        "api/generate-magic-link/", GenerateMagicLinkViewSet.as_view()
    ),  # magic link login
    path("api/get_help/", GetHelpViewSet.as_view()),  # get help
    path("admin/", admin.site.urls),
    path("api/token-verify/", verify_jwt_token),  # to validate token
    path("api/token-refresh/", refresh_jwt_token),  # to refrsh a validated token
    url(r"^jet/", include("jet.urls", "jet")),
    url(r"^api-auth/", include("rest_framework.urls", namespace="rest_framework")),
    url(r"^api/", include(router.urls)),
    url(r"^api-schema/", get_schema_view("Supported API")),
]
