from importlib import import_module

from django.apps import apps
from django.utils.module_loading import module_has_submodule
from drf_autoview.api import register_with_router
from rest_framework import routers


def get_router():
    _router = routers.DefaultRouter()
    _apps = filter(lambda x: "rubrik.vision" in x[1].name, apps.app_configs.items())
    for _app_name, _app_obj in _apps:
        if module_has_submodule(_app_obj.module, "api"):
            api = import_module("{0}.api".format(_app_obj.module.__name__))
            register_with_router(_router, api.api_views)
    return _router


router = get_router()
