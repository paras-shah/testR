import datetime
import json
import logging
import os

import yaml


def get_json_from_env(env_key):
    return yaml.safe_load(os.environ.get(env_key))


# ############################################################################
# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)) + "/../../")

# ############################################################################
# Logging and Debugging
DEBUG = json.loads(os.environ.get("VISION_DEBUG", "false"))
DEPLOYMENT_TYPE = os.environ.get("DEPLOYMENT_TYPE")

LOGGING = {
    "version": 1,
    "disable_existing_loggers": True,
    "formatters": {
        "default_formatter": {
            "class": os.environ.get(
                "VCUBE_LOGGING_FORMATTER_CLASS", "pythonjsonlogger.jsonlogger.JsonFormatter"
            ),
            "format": "[%(asctime)s|%(name)s|%(process)d.%(threadName)s|%(module)s.%(funcName)s.%(lineno)s|%(levelname)s] %(message)s",
        }
    },
    "handlers": {
        "root_console": {
            "level": "INFO",
            "class": "logging.StreamHandler",
            "formatter": "default_formatter"
        },
        "elasticapm": {
            "level": "WARNING",
            "class": "elasticapm.contrib.django.handlers.LoggingHandler",
        },
    },
    "loggers": {
        "": {"handlers": ["root_console", "elasticapm"], "level": "INFO"},
        "django": {"handlers": ["root_console", "elasticapm"], "level": "INFO", "propagate": False},
        "celery": {"handlers": ["root_console", "elasticapm"], "level": "INFO", "propagate": False},
        "celery.worker": {"handlers": ["root_console", "elasticapm"], "level": "ERROR",
                          "propagate": False},
        "celery.app": {"handlers": ["root_console", "elasticapm"], "level": "ERROR",
                       "propagate": False},
        "kombu.pidbox": {"handlers": ["root_console"], "level": "ERROR", "propagate": False},
    },
}


# ############################################################################
# Core Django
WSGI_APPLICATION = "rubrik.vision.site.wsgi.application"
ALLOWED_HOSTS = [
    i.strip() for i in os.environ.get("VISION_ALLOWED_HOSTS", "*").split(",")
]
SECRET_KEY = os.environ.get("VISION_SECRET_KEY", "DEFAULT-NON-WORKING-KEY")
ROOT_URLCONF = "rubrik.vision.site.urls"

CORS_ORIGIN_ALLOW_ALL = True
# CORS_ORIGIN_REGEX_WHITELIST = [
#    r"^https?://[\w+\.]+:[\d]{4}$",
# ]

INSTALLED_APPS = [
    #######
    # Django core
    #
    "jet",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    #
    # Django core end
    #######
    #######
    # third party apps start
    #
    "jsoneditor",
    "django_celery_beat",
    "rest_framework",
    "django_filters",
    "elasticapm.contrib.django",
    # third party apps end
    #######
    #######
    # vision apps start
    #
    "rubrik.vision.core",
    # vision apps end
    #######
    #######
    # corsheaders start
    #
    "corsheaders",
    # corsheaders end
    #######
    #######
    # Django guardian start
    "guardian",
    # Django guardian end
    #######
]
MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "elasticapm.contrib.django.middleware.Catch404Middleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ]
        },
    }
]

# Internationalization
LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_L10N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = "/static/"
# Add these new lines
STATICFILES_DIRS = (
    # Enable when we need it
    # os.path.join(BASE_DIR, 'static'),
)
STATIC_ROOT = os.path.join(BASE_DIR, "../staticfiles")

# ############################################################################
# Database

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql_psycopg2",
        "NAME": "vision",
        "USER": os.environ.get("VISION_DB_DEFAULT_USER", None),
        "PASSWORD": os.environ.get("VISION_DB_DEFAULT_PASSWORD", None),
        "HOST": os.environ.get("VISION_DB_DEFAULT_HOST", None),
        "PORT": int(os.environ.get("VISION_DB_DEFAULT_PORT", "5432")),
        "CONN_MAX_AGE": int(os.environ.get("VISION_DB_DEFAULT_CONN_MAX_AGE", "600")),
    }
}

# ############################################################################
# Auth
# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"
    },
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

AUTHENTICATION_BACKENDS = (
    "django.contrib.auth.backends.ModelBackend",
    "guardian.backends.ObjectPermissionBackend",
)

# ############################################################################
# Django rest settings
DEFAULT_RENDERER_CLASSES = ("rest_framework.renderers.JSONRenderer",)

if DEPLOYMENT_TYPE == "development":
    DEFAULT_RENDERER_CLASSES = DEFAULT_RENDERER_CLASSES + (
        "rest_framework.renderers.BrowsableAPIRenderer",
    )

REST_FRAMEWORK = {
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.DjangoModelPermissions"],
    "DEFAULT_FILTER_BACKENDS": ("django_filters.rest_framework.DjangoFilterBackend",),
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.LimitOffsetPagination",
    "PAGE_SIZE": 40,
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework_jwt.authentication.JSONWebTokenAuthentication",
        "rest_framework.authentication.SessionAuthentication",
        "rest_framework.authentication.BasicAuthentication",
    ),
    "DEFAULT_RENDERER_CLASSES": (DEFAULT_RENDERER_CLASSES),
}

# JWT settings
JWT_AUTH = {
    "JWT_RESPONSE_PAYLOAD_HANDLER": "rubrik.vision.site.utils.custom_jwt_response_handler",
    "JWT_AUTH_HEADER_PREFIX": "BEARER",  # JWT
    "JWT_ALLOW_REFRESH": True,
    "JWT_REFRESH_EXPIRATION_DELTA": datetime.timedelta(days=7),
    "JWT_EXPIRATION_DELTA": datetime.timedelta(days=1),
}

# ############################################################################
# Elastic APM Plugin
if os.environ.get("VISION_ELASTIC_APM", None):
    ELASTIC_APM = get_json_from_env('VISION_ELASTIC_APM')
    ELASTIC_APM['ENVIRONMENT'] = os.environ.get("DEPLOYMENT_TYPE", 'development')
    ELASTIC_APM['SERVICE_VERSION'] = os.environ.get("WEB_IMAGE_SUFFIX", "unknown")
else:
    ELASTIC_APM = {
        'DISABLE_SEND': True,
    }


# ############################################################################
# Json editor
JSON_EDITOR_JS = (
    "https://cdnjs.cloudflare.com/ajax/libs/jsoneditor/5.26.2/jsoneditor.js"
)
JSON_EDITOR_CSS = (
    "https://cdnjs.cloudflare.com/ajax/libs/jsoneditor/5.26.2/jsoneditor.css"
)

# ############################################################################
# Celery Configs
# Before any change Read/UnderstandEffects/TestAllCases/GetReviewed/Publish
CELERY_BROKER_URL = os.environ.get("VISION_CELERY_BROKER_URL", None)
CELERY_TIMEZONE = TIME_ZONE
CELERY_ACCEPT_CONTENT = ["json"]
CELERY_ENABLE_REMOTE_CONTROL = True

CELERY_RESULT_SERIALIZER = "json"
CELERY_RESULT_CACHE_MAX = -1
CELERY_RESULT_BACKEND = os.environ.get("VISION_CELERY_RESULT_BACKEND", None)

CELERY_TASK_ANNOTATIONS = {
    "celery.chord_unlock": {"soft_time_limit": 300, "default_retry_delay": 5}
}
CELERY_TASK_RESULT_EXPIRES = 600
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_SERIALIZER = "json"
CELERY_TASK_ACKS_LATE = True
CELERY_TASK_SEND_SENT_EVENT = True
CELERY_TASK_REJECT_ON_WORKER_LOST = True
CELERY_TASK_ALWAYS_EAGER = False

CELERY_WORKER_PREFETCH_MULTIPLIER = 1
CELERY_WORKER_POOL_RESTARTS = True
CELERY_WORKER_HIJACK_ROOT_LOGGER = False

CELERYD_TASK_TIME_LIMIT = 24 * 3600  # A task can run for max of 24hrs
CELERYD_SEND_EVENTS = True
CELERYD_MAX_TASKS_PER_CHILD = 20
CELERYD_WORKER_LOST_WAIT = 59

CELERY_BEAT_SCHEDULE = {
    "send_create_jobs": {
        "task": "rubrik.vision.core.tasks.process_lab_template_instance_create_request.send_create_jobs",
        "schedule": 4,
        "args": (),
    },
    "send_release_jobs": {
        "task": "rubrik.vision.core.tasks.process_lab_template_instance_release_request.send_release_jobs",
        "schedule": 4,
        "args": (),
    },
    "check_create_jobs": {
        "task": "rubrik.vision.core.tasks.update_lab_template_instance_processing.check_create_jobs",
        "schedule": 1,
        "args": (),
    },
    "check_release_request_jobs": {
        "task": "rubrik.vision.core.tasks.update_lab_template_instance_release_request.check_release_request_jobs",
        "schedule": 4,
        "args": (),
    },
    "check_release_jobs": {
        "task": "rubrik.vision.core.tasks.update_lab_template_instance_releasing.check_release_jobs",
        "schedule": 4,
        "args": (),
    },
    "import_lab_template_process": {
        "task": "rubrik.vision.core.tasks.import_lab_template_process.import_lab_template_process",
        "schedule": 600,
        "args": (),
    },
    "release_jobs": {
        "task": "rubrik.vision.core.tasks.update_lab_template_instance_release.release_jobs",
        "schedule": 4,
        "args": (),
    },
    "process_resource_allocation": {
        "task": "rubrik.vision.core.tasks.process_resource_allocation.process_resource_allocation",
        "schedule": 4,
        "args": (),
    },
    "send_action_jobs": {
        "task": "rubrik.vision.core.tasks.process_lab_template_instance_action_request.send_action_jobs",
        "schedule": 4,
        "args": (),
    },
    "check_action_jobs": {
        "task": "rubrik.vision.core.tasks.update_lab_template_instance_action_running.check_action_jobs",
        "schedule": 4,
        "args": (),
    },

}

CELERY_ONCE = {
    "backend": "celery_once.backends.Redis",
    "settings": {
        "url": "{0}/0".format(CELERY_RESULT_BACKEND),
        "default_timeout": 30 * 60,  # 30 minutes
    },
}

# TODO encryption key needs to be set for production
# from cryptography.fernet import Fernet
# key = Fernet.generate_key()
VISION_ENCRYPTION_KEY = os.environ.get("VISION_ENCRYPTION_KEY", "").encode()

# ############################################################################
# Django organizations settings
ORGS_SLUGFIELD = "django_extensions.db.fields.AutoSlugField"

SMTP_CONFIGURATIONS = {
    "server": os.environ.get("SMTP_SERVER"),
    "user_name": os.environ.get("SMTP_USER_NAME"),
    "password": os.environ.get("SMTP_PASSWORD"),
    "sender": os.environ.get("SMTP_SENDER"),
    "helpdesk": os.environ.get("HELP_DESK_EMAIL"),
    "port": os.environ.get("SMTP_PORT"),
    "site_url": os.environ.get("VELOCITY_URL"),
}

# Local Timzone
USE_TZ = True
TIME_ZONE = 'US/Pacific'
