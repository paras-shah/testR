from rubrik.vision.core import models
from rubrik.vision.tests.base_test import BaseTestCase
from rubrik.vision.tests import mock_models
from rubrik.vision.lib.resource_manager import resource_request_reservation


class TestResourceRequestReservation(BaseTestCase):
    def test_reserve_resource(self):
        resource_types = ["ESX1", "ESX2"]
        resource_prop_types = [
            {"name": "CpuCores", "aggregate_type": "Sum"},
            {"name": "Memory", "aggregate_type": "Sum"},
            {"name": "Disk", "aggregate_type": "Sum"},
            {"name": "NetworkLabLan", "aggregate_type": "Sum"},
            {"name": "NetworkLabWan", "aggregate_type": "Sum"},
        ]

        request_reservation_data = {
            "requirements": [
                {
                    "virtual_datacenter_unit": "vdu1",
                    "ResourceType": "ESX1",
                    "name": "gateway",
                    "CpuCores": {"size": 1, "unit": "Hz"},
                    "Memory": {"size": 1024, "unit": "Mb"},
                    "Disk": {"size": 8, "unit": "Mb"},
                    "NetworkLabLan": {"size": 1, "unit": "port"},
                    "NetworkLabWan": {"size": 1, "unit": "port"},
                },
                {
                    "virtual_datacenter_unit": "vdu1",
                    "ResourceType": "ESX2",
                    "name": "linux-host-2",
                    "CpuCores": {"size": 1, "unit": "Hz"},
                    "Memory": {"size": 1024, "unit": "Mb"},
                    "Disk": {"size": 8, "unit": "Mb"},
                    "NetworkLabLan": {"size": 1, "unit": "port"},
                },
            ]
        }
        reserved = mock_models.generate_entity_type(name="Reserved", family="ReservationStatus")
        available = mock_models.generate_entity_type(name="Available", family="ResourceStatus")
        allocated = mock_models.generate_entity_type(name="Allocated", family="ResourceState")
        released = mock_models.generate_entity_type(name="Released", family="ReservationStatus")
        pending_release = mock_models.generate_entity_type(name="PendingRelease", family="ReservationStatus")


        mock_models.generate_resource_types(resource_types)
        mock_models.generate_resource_property_types(resource_prop_types)
        self.assertEqual(models.ResourceReservationRequest.objects.all().count(), 0)
        mock_models.generate_resource_reservation_request(request_reservation_data)
        self.assertEqual(models.ResourceReservationRequest.objects.all().count(), 1)
        rrr_obj = models.ResourceReservationRequest.objects.all()[0]
        rrr = resource_request_reservation.ResourceReservationRequest(
            rrr_obj.id)
        rp1 = mock_models.generate_resource_pool('RP1')
        status = mock_models.generate_entity_type(
            'Available', 'ResourceStatus')
        mock_models.generate_entity_type('Allocated', 'ResourceState')
        rrr.save(rp1, status)

        self.assertEqual(models.Resource.objects.count(), 2)
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 1)
        self.assertEqual(rrr.resource_request_reservation.status, available)
        self.assertEqual(models.ResourceReservation.objects.count(), 2)
        self.assertEqual(models.ResourceProperty.objects.count(), 9)

        # Test release
        resource_request_reservation.ResourceReservationRequest.release_resource(
            rrr_obj.id)
        self.assertEqual(models.Resource.objects.count(), 2)
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 1)
        rrr = models.ResourceReservationRequest.objects.get(id=rrr.resource_request_reservation.id)
        self.assertEqual(rrr.status, released)
        self.assertEqual(models.ResourceReservation.objects.count(), 2)
        self.assertEqual(models.ResourceProperty.objects.count(), 9)
