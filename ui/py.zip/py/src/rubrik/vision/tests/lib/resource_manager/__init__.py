from django.test import TestCase
from rubrik.vision.core import models

from rubrik.vision.tests import base_test
from rubrik.vision.tests import mock_models


class BaseResourceManagerTestCase(base_test.BaseTestCase):

    def _create_resource_pool_share(self, vdu, rPool, rType, rPropType, usable, used, free):
        return mock_models.generate_resource_pool_share(vdu=vdu, resource_pool=rPool, resource_type=rType,
                                                        resource_property_type=rPropType, useable_capacity=usable, used_capacity=used, free_capacity=free)

    def _create_resource_pool_capacity(self, rPool, rType, rPropType, usable, used, free):
        return mock_models.generate_resource_pool_capacity(resource_pool=rPool, resource_type=rType, resource_property_type=rPropType,
                                                           total_capacity=usable, useable_capacity=usable, used_capacity=used, free_capacity=free)

    def _create_resource_types(self, resource_types):
        return mock_models.generate_resource_types(resource_types)

    def _create_resource_property_type(self, property_type_name, aggregate_type):
        return mock_models.generate_resource_property_type(
            {"name": property_type_name, "aggregate_type": aggregate_type}
        )

    def validate_resource_pool_capacity(self, rp, rType, rPropType, used, free):
        rpCapacity = models.ResourcePoolCapacity.objects.get(
            resource_pool=rp,
            resource_type=mock_models.generate_resource_type(rType),
            resource_property_type=rPropType,
        )
        self.assertEqual(rpCapacity.free_capacity, free)
        self.assertEqual(rpCapacity.used_capacity, used)

    def validate_resource_pool_share_capacity(self, rp, rType, rPropType, used, free):
        rpCapacity = models.ResourcePoolShare.objects.get(resource_pool=rp,
            resource_type=mock_models.generate_resource_type(rType),
            resource_property_type=rPropType)
        self.assertEqual(rpCapacity.free_capacity, free)
        self.assertEqual(rpCapacity.used_capacity, used)
