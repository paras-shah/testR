import doctest
import unittest

from rubrik.vision.tests.base_test import BaseTestCase
from rubrik.vision.lib import collections_utils


class TestCollectionsUtil(BaseTestCase):
    def test_collections_util(self):
        doctest.DocTestSuite(collections_utils)
