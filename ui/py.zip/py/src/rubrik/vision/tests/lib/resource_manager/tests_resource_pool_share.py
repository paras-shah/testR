from rubrik.vision.core import models
from rubrik.vision.tests.lib.resource_manager import BaseResourceManagerTestCase
from rubrik.vision.tests import mock_models
from rubrik.vision.lib.resource_manager import resource_request_processor
from rubrik.vision.lib.resource_manager import resource_pool_share
from rubrik.vision.lib.resource_manager import exceptions as resource_expceptions


class TestResourcePoolShare(BaseResourceManagerTestCase):
    def test_reserve_resource_only_rp1_availbable_with_available_capacity(self):
        self._create_resource_types(["ESX1"])

        CpuCores = self._create_resource_property_type("CpuCores", "Sum")
        rp1 = mock_models.generate_resource_pool("RP1")
        vdu = mock_models.generate_virtual_datacenter_unit("VDU1")

        aggregate_values = {"ESX1__CpuCores": 99}

        # RP1 share
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX1", CpuCores, usable=100, used=0, free=100
        )

        # RP1 capacity
        self._create_resource_pool_capacity(
            "RP1", "ESX1", CpuCores, usable=100, used=0, free=100
        )

        # Only RP1 has capacity of 99
        rpShare = resource_pool_share.ResourcePoolShare(
            virtual_datacenter_unit_id=vdu.id, aggregate_values=aggregate_values
        )
        rpShare.reserve_resource_pool()

        self.assertEqual(rpShare.resource_pool.id, rp1.id)
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", CpuCores, used=99, free=1
        )

    def test_reserve_resource_with_available_capacity(self):
        self._create_resource_types(["ESX1"])

        CpuCores = self._create_resource_property_type("CpuCores", "Sum")
        mock_models.generate_resource_pool("RP1")
        vdu = mock_models.generate_virtual_datacenter_unit("VDU1")

        aggregate_values = {"ESX1__CpuCores": 99}

        # RP1 share
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX1", CpuCores, usable=50, used=0, free=50
        )

        # RP1 capacity
        self._create_resource_pool_capacity(
            "RP1", "ESX1", CpuCores, usable=50, used=0, free=50
        )

        # No Resource is available this should throw exceptions.OutOfCapacity exception
        rpShare = resource_pool_share.ResourcePoolShare(
            virtual_datacenter_unit_id=vdu.id, aggregate_values=aggregate_values
        )

        self.assertRaises(
            resource_expceptions.OutOfCapacity, lambda: rpShare.reserve_resource_pool()
        )

    def test_reserve_resource_only_rp2_has_enough_capacity(self):
        self._create_resource_types(["ESX1", "ESX2"])

        CpuCores = self._create_resource_property_type("CpuCores", "Sum")
        Memory = self._create_resource_property_type("Memory", "Sum")
        rp1 = mock_models.generate_resource_pool("RP1")
        rp2 = mock_models.generate_resource_pool("RP2")
        vdu = mock_models.generate_virtual_datacenter_unit("VDU1")

        aggregate_values = {
            "ESX1__CpuCores": 99,
            "ESX2__CpuCores": 99,
            "ESX1__Memory": 99,
            "ESX2__Memory": 99,
        }

        # RP1 share
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX1", CpuCores, usable=50, used=0, free=50
        )
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX1", Memory, usable=50, used=0, free=50
        )
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX2", CpuCores, usable=50, used=0, free=50
        )
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX2", Memory, usable=50, used=0, free=50
        )

        # RP1 capacity
        self._create_resource_pool_capacity(
            "RP1", "ESX1", CpuCores, usable=50, used=0, free=50
        )
        self._create_resource_pool_capacity(
            "RP1", "ESX1", Memory, usable=50, used=0, free=50
        )
        self._create_resource_pool_capacity(
            "RP1", "ESX2", CpuCores, usable=50, used=0, free=50
        )
        self._create_resource_pool_capacity(
            "RP1", "ESX2", Memory, usable=50, used=0, free=50
        )

        # RP2 share
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX1", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX1", Memory, usable=100, used=0, free=100
        )
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX2", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX2", Memory, usable=100, used=0, free=100
        )

        # RP2 Capacity
        self._create_resource_pool_capacity(
            "RP2", "ESX1", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP2", "ESX1", Memory, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP2", "ESX2", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP2", "ESX2", Memory, usable=100, used=0, free=100
        )

        # Only RP2 has capacity of greater than 99
        rpShare = resource_pool_share.ResourcePoolShare(
            virtual_datacenter_unit_id=vdu.id, aggregate_values=aggregate_values
        )

        rpShare.reserve_resource_pool()
        self.assertEqual(rpShare.resource_pool.id, rp2.id)

        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", CpuCores, used=99, free=1
        )
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", Memory, used=99, free=1
        )

    def test_reserve_resource(self):
        self._create_resource_types(["ESX1", "ESX2"])
        CpuCores = self._create_resource_property_type("CpuCores", "Sum")
        Memory = self._create_resource_property_type("Memory", "Sum")
        rp1 = mock_models.generate_resource_pool("RP1")
        mock_models.generate_resource_pool("RP2")
        vdu = mock_models.generate_virtual_datacenter_unit("VDU1")

        aggregate_values = {
            "ESX1__CpuCores": 55,
            "ESX2__CpuCores": 55,
            "ESX1__Memory": 55,
            "ESX2__Memory": 55,
        }

        # RP1 share
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX1", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX1", Memory, usable=100, used=0, free=100
        )
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX2", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX2", Memory, usable=100, used=0, free=100
        )

        # RP1 capacity
        self._create_resource_pool_capacity(
            "RP1", "ESX1", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP1", "ESX1", Memory, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP1", "ESX2", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP1", "ESX2", Memory, usable=100, used=0, free=100
        )

        # RP2 share
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX1", CpuCores, usable=50, used=0, free=50
        )
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX2", Memory, usable=50, used=0, free=50
        )
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX2", CpuCores, usable=50, used=0, free=50
        )
        self._create_resource_pool_share(
            "VDU1", "RP2", "ESX2", Memory, usable=50, used=0, free=50
        )

        # RP2 Capacity
        self._create_resource_pool_capacity(
            "RP2", "ESX1", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP2", "ESX1", Memory, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP2", "ESX2", CpuCores, usable=100, used=0, free=100
        )
        self._create_resource_pool_capacity(
            "RP2", "ESX2", Memory, usable=100, used=0, free=100
        )

        # Even though RP1 and RP2 have capacity of 100 for all resource requirements which are over 55 in ...
        # both cases, RP2 share is only 50 for VDU1 and, therefore RP1 should be selected.
        rpShare = resource_pool_share.ResourcePoolShare(
            virtual_datacenter_unit_id=vdu.id, aggregate_values=aggregate_values
        )

        # Validate before reserving resource
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", CpuCores, used=0, free=100
        )
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", Memory, used=0, free=100
        )
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX2", CpuCores, used=0, free=100
        )
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX2", Memory, used=0, free=100
        )

        rpShare.reserve_resource_pool()

        # Validate after reserving resource
        self.assertEqual(rpShare.resource_pool.id, rp1.id)
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", CpuCores, used=55, free=45
        )
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", Memory, used=55, free=45
        )
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX2", CpuCores, used=55, free=45
        )
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX2", Memory, used=55, free=45
        )

    def test_release_resource_one_rp_availbable_with_available_capacity(self):
        self._create_resource_types(["ESX1"])

        CpuCores = self._create_resource_property_type("CpuCores", "Sum")
        rp1 = mock_models.generate_resource_pool("RP1")
        vdu = mock_models.generate_virtual_datacenter_unit("VDU1")

        aggregate_values = {"ESX1__CpuCores": 99}

        # RP1 share
        self._create_resource_pool_share(
            "VDU1", "RP1", "ESX1", CpuCores, usable=100, used=0, free=100
        )

        # RP1 capacity
        self._create_resource_pool_capacity(
            "RP1", "ESX1", CpuCores, usable=100, used=0, free=100
        )

        # Only RP1 has capacity of 99
        rpShare = resource_pool_share.ResourcePoolShare(
            virtual_datacenter_unit_id=vdu.id, aggregate_values=aggregate_values
        )
        rpShare.reserve_resource_pool()

        self.assertEqual(rpShare.resource_pool.id, rp1.id)
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", CpuCores, used=99, free=1
        )
        # Release resource back to the pool
        rpShare.reslease_resource_pool(rp1.id)
        self.validate_resource_pool_capacity(
            rpShare.resource_pool, "ESX1", CpuCores, used=0, free=100
        )
