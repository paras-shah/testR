from rubrik.vision.core import models
from rubrik.vision.tests.base_test import BaseTestCase
from rubrik.vision.tests import mock_models
from rubrik.vision.lib.resource_manager import resource_request_processor
from rubrik.vision.tests.lib.resource_manager import BaseResourceManagerTestCase


class TestResourceRequestProcessor(BaseResourceManagerTestCase):

    def test_reserve_resource_dynamic(self):
        reserved = mock_models.generate_entity_type(name="Reserved", family="ReservationStatus")
        released = mock_models.generate_entity_type(name="Released", family="ReservationStatus")
        pendingRelease = mock_models.generate_entity_type(name="PendingRelease", family="ReservationStatus")
        mock_models.generate_entity_type(name="Available", family="ResourceStatus")
        mock_models.generate_entity_type(name="Allocated", family="ResourceState")
        self._create_resource_types(['VmwareComputeCluster'])
        CpuCores = self._create_resource_property_type('CpuCores', 'Sum')
        rp1 = mock_models.generate_resource_pool('RP1')
        vdu1 = mock_models.generate_virtual_datacenter_unit('VDU1')
        self._create_resource_pool_share('VDU1', 'RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)
        self._create_resource_pool_capacity('RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)

        request_reservation_data = {
            'requirements': [
                {
                    'virtual_datacenter_unit': '{}'.format(vdu1.id),
                    'ResourceType': 'VmwareComputeCluster',
                    'name': 'gateway1',
                    'CpuCores': {'size': 50, 'unit': 'Hz'}
                },
                {
                    'virtual_datacenter_unit': '{}'.format(vdu1.id),
                    'ResourceType': 'VmwareComputeCluster',
                    'name': 'gateway',
                    'CpuCores': {'size': 50, 'unit': 'Hz'},
                }
            ]
        }
        self.assertEqual(models.Resource.objects.count(), 0)
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 0)
        self.assertEqual(models.ResourceReservation.objects.count(), 0)
        self.assertEqual(models.ResourceProperty.objects.count(), 0)

        self.validate_resource_pool_capacity(rp1, 'VmwareComputeCluster', CpuCores, used=0, free=100)
        self.validate_resource_pool_share_capacity(rp1, 'VmwareComputeCluster', CpuCores, used=0, free=100)

        rrr = mock_models.generate_resource_reservation_request(
            request_reservation_data)
        resource_request_processor.ResourceRequestProcessor.reserve_resource(
             rrr.id)
        self.validate_resource_pool_capacity(rp1, 'VmwareComputeCluster', CpuCores, used=100, free=0)
        self.validate_resource_pool_share_capacity(rp1, 'VmwareComputeCluster', CpuCores, used=100, free=0)

        self.assertEqual(models.Resource.objects.count(), 2)
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 1)
        rrr = models.ResourceReservationRequest.objects.get(id=rrr.id)
        self.assertEqual(rrr.status, reserved)
        self.assertEqual(models.ResourceReservation.objects.count(), 2)
        self.assertEqual(models.ResourceProperty.objects.count(), 2)


        # test release
        resource_request_processor.ResourceRequestProcessor.release_resource(rrr.id)
        rrr = models.ResourceReservationRequest.objects.get(id=rrr.id)
        self.assertEqual(rrr.status, released)

    def test_reserve_resource_static(self):
        reserved = mock_models.generate_entity_type(name="Reserved", family="ReservationStatus")
        released = mock_models.generate_entity_type(name="Released", family="ReservationStatus")
        pending_release = mock_models.generate_entity_type(name="PendingRelease", family="ReservationStatus")

        mock_models.generate_entity_type(name="Available", family="ResourceStatus")
        mock_models.generate_entity_type(name="Allocated", family="ResourceState")
        self._create_resource_types(['VmwareComputeCluster'])
        CpuCores = self._create_resource_property_type('CpuCores', 'Sum')
        rp1 = mock_models.generate_resource_pool('RP1')
        vdu = mock_models.generate_virtual_datacenter_unit('VDU1')
        self._create_resource_pool_share('VDU1', 'RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)
        self._create_resource_pool_capacity('RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)
        mock_models.generate_resource(name='Sharable Resource', resource_pool=rp1, resource_type='VmwareComputeCluster', state='Allocated', status='Available')


        request_reservation_data = {
            "requirements": [
                {
                    'virtual_datacenter_unit': '{}'.format(vdu.id),
                    'ResourceType': 'VmwareComputeCluster',
                    'name': 'gateway1',
                    'CpuCores': {'size': 50, 'unit': 'Hz'},
                    'is_provisioned': True
                },
                {
                    'virtual_datacenter_unit': '{}'.format(vdu.id),
                    'ResourceType': 'VmwareComputeCluster',
                    'name': 'gateway',
                    'CpuCores': {'size': 50, 'unit': 'Hz'},
                    'is_provisioned': True
                }
            ]
        }

        self.validate_resource_pool_capacity(rp1, 'VmwareComputeCluster', CpuCores, used=0, free=100)

        self.assertEqual(models.Resource.objects.count(), 1)
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 0)
        self.assertEqual(models.ResourceReservation.objects.count(), 0)
        self.assertEqual(models.ResourceProperty.objects.count(), 0)

        rrr = mock_models.generate_resource_reservation_request(
            request_reservation_data)
        resource_request_processor.ResourceRequestProcessor.reserve_resource(
             rrr.id)
        self.validate_resource_pool_capacity(rp1, 'VmwareComputeCluster', CpuCores, used=100, free=0)

        self.assertEqual(models.Resource.objects.count(), 1)
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 1)
        rrr = models.ResourceReservationRequest.objects.get(id=rrr.id)
        self.assertEqual(rrr.status, reserved)
        self.assertEqual(models.ResourceReservation.objects.count(), 2)
        self.assertEqual(models.ResourceProperty.objects.count(), 0)

        # test release
        resource_request_processor.ResourceRequestProcessor.release_resource(rrr.id)
        rrr = models.ResourceReservationRequest.objects.get(id=rrr.id)
        self.assertEqual(rrr.status, released)
