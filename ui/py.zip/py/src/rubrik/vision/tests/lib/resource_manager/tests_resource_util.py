from rubrik.vision.tests.base_test import BaseTestCase
from rubrik.vision.lib.resource_manager import resource_util
from rubrik.vision.lib.resource_manager.exceptions import ConflictingAggregationMethod


class TestUtil(BaseTestCase):
    def test_aggregate_dict(self):
        input_data = [
            {"property_name": "cpu", "property_value": 1, "aggregate_type": "Sum"},
            {"property_name": "cpu", "property_value": 1, "aggregate_type": "Sum"},
            {"property_name": "mem", "property_value": 1, "aggregate_type": "Sum"},
            {"property_name": "mem", "property_value": 1, "aggregate_type": "Sum"},
            {"property_name": "mem", "property_value": 1, "aggregate_type": "Sum"},
            {
                "property_name": "network",
                "property_value": ["vlan1", "wan"],
                "aggregate_type": "Unique",
            },
            {
                "property_name": "network",
                "property_value": ["vlan2", "wan"],
                "aggregate_type": "Unique",
            },
        ]
        expected = {"cpu": 2, "mem": 3, "network": ["wan", "vlan1", "vlan2"]}
        result = resource_util.aggregate_dict(input_data)
        self.assertEqual(sorted(expected.pop("network")), sorted(result.pop("network")))
        self.assertDictEqual(expected, result)

    def test_aggregate_dict_should_fail_since_different_aggregate_type_with_same_property(
        self
    ):
        input_data = [
            {"property_name": "cpu", "property_value": 1, "aggregate_type": "Sum"},
            {"property_name": "cpu", "property_value": 1, "aggregate_type": "Unique"},
        ]

        self.assertRaises(
            ConflictingAggregationMethod,
            lambda: resource_util.aggregate_dict(input_data),
        )
