from rubrik.vision.core import models
from rubrik.vision.tests.lib.resource_manager import BaseResourceManagerTestCase
from rubrik.vision.tests import mock_models
from rubrik.vision.lib.resource_manager import resource_request_processor
from rubrik.vision.lib.resource_manager import resource_pool_share
from rubrik.vision.lib.resource_manager import exceptions as resource_expceptions

from django.contrib.auth.models import User as django_user


class TestMockModels(BaseResourceManagerTestCase):
    def test_generate_user(self):
        mock_models.generate_user(
            username="user", password="password", email="user@email.com", is_staff=True
        )
        # Created user and Anon User
        self.assertEqual(django_user.objects.count(), 2)

    def test_generate_entity_type(self):
        mock_models.generate_entity_type(name="test_name", family="test_family")
        self.assertEqual(models.EntityType.objects.count(), 1)

    def test_generate_datacenter_custom_location(self):
        location = mock_models.generate_entity_type(
            name="TestLocation", family="Location"
        )
        mock_models.generate_datacenter(
            name="Datacenter", location=location, status="Active"
        )
        self.assertEqual(models.DataCenter.objects.count(), 1)

    def test_generate_datacenter_default_location(self):
        mock_models.generate_datacenter(name="Datacenter", status="Active")
        self.assertEqual(models.DataCenter.objects.count(), 1)

    def test_generate_resource_reservation_request(self):
        request_params = {"test": "test"}
        mock_models.generate_resource_reservation_request(
            request_params=request_params, status="Initial", requestPriority="Normal"
        )
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 1)

    def test_generate_resource_reservation_request(self):
        request_params = {"test": "test"}
        mock_models.generate_resource_reservation_request(
            request_params=request_params, status="Initial", requestPriority="Normal"
        )
        self.assertEqual(models.ResourceReservationRequest.objects.count(), 1)

    def test_generate_resource_property_type(self):
        mock_models.generate_resource_property_type(
            prop={"name": "x", "aggregate_type": "y"}
        )
        self.assertEqual(models.ResourcePropertyType.objects.count(), 1)

    def test_generate_resource_property_types(self):
        mock_models.generate_resource_property_types(
            props=[
                {"name": "x", "aggregate_type": "y"},
                {"name": "w", "aggregate_type": "z"},
            ]
        )
        self.assertEqual(models.ResourcePropertyType.objects.count(), 2)

    def test_generate_resource_type(self):
        mock_models.generate_resource_type(name="test")
        self.assertEqual(
            models.EntityType.objects.filter(family="ResourceType").count(), 1
        )

    def test_generate_resource_types(self):
        mock_models.generate_resource_types(names=["x", "y", "z"])
        self.assertEqual(
            models.EntityType.objects.filter(family="ResourceType").count(), 3
        )

    def test_generate_resource_pool_custom_datacenter(self):
        datacenter = mock_models.generate_datacenter()
        mock_models.generate_resource_pool(
            name="TestPool", datacenter=datacenter, state="Available", status="Running"
        )
        self.assertEqual(
            models.ResourcePool.objects.filter(datacenter=datacenter).count(), 1
        )

    def test_generate_resource_pool_default_datacenter(self):
        mock_models.generate_resource_pool(name="TestPool")
        self.assertEqual(models.ResourcePool.objects.count(), 1)

    def test_generate_resource_custom_pool(self):
        resource_pool = mock_models.generate_resource_pool(name="x")
        mock_models.generate_resource(name="Resource", resource_pool=resource_pool)
        self.assertEqual(
            models.Resource.objects.filter(resource_pool=resource_pool).count(), 1
        )

    def test_generate_resource_default_pool(self):
        mock_models.generate_resource(name="Resource")
        self.assertEqual(models.Resource.objects.count(), 1)

    def test_generate_resource_default_pool_with_properties(self):
        properties = [
            {
                "name": "Prop1",
                "aggregate_type": "agg",
                "value": {"x": "x"},
                "useable_capacity": 1,
                "used_capacity": 0,
                "free_capacity": 1,
            }
        ]
        mock_models.generate_resource(name="Resource", properties=properties)
        self.assertEqual(models.Resource.objects.count(), 1)

    def test_generate_virtual_datacenter_unit_custom_datacenter(self):
        datacenter = mock_models.generate_datacenter()
        mock_models.generate_virtual_datacenter_unit(name="vdu1", datacenter=datacenter)
        self.assertEqual(
            models.VirtualDataCenterUnit.objects.filter(datacenter=datacenter).count(),
            1,
        )

    def test_generate_resource_pool_share_custom(self):
        vdu = mock_models.generate_virtual_datacenter_unit(name="vdu1")
        resource_pool = mock_models.generate_resource_pool(name="pool1")
        resource_type = mock_models.generate_resource_type(name="Type1")
        resource_property_type = mock_models.generate_resource_property_type(
            prop={"name": "x", "aggregate_type": "y"}
        )
        mock_models.generate_resource_pool_share(
            vdu=vdu,
            resource_pool=resource_pool,
            resource_type=resource_type,
            resource_property_type=resource_property_type,
        )
        self.assertEqual(
            models.ResourcePoolShare.objects.count(),
            1,
        )

    def test_generate_resource_pool_share_default(self):
        vdu = mock_models.generate_virtual_datacenter_unit(name="vdu1")
        rp = mock_models.generate_resource_pool(name="pool1")
        rp_type = mock_models.generate_resource_property_type(
            prop={"name": "x", "aggregate_type": "y"}
        )
        mock_models.generate_resource_pool_share(
            vdu=vdu, resource_pool=rp, resource_type="x", resource_property_type=rp_type
        )
        self.assertEqual(models.ResourcePoolShare.objects.filter().count(), 1)

    def test_generate_resource_pool_capacity(self):
        resource_pool = mock_models.generate_resource_pool(name="pool1")
        resource_type = mock_models.generate_resource_type(name="Type1")
        resource_property_type = mock_models.generate_resource_property_type(
            prop={"name": "x", "aggregate_type": "y"}
        )
        mock_models.generate_resource_pool_capacity(
            resource_pool=resource_pool,
            resource_type=resource_type,
            resource_property_type=resource_property_type,
        )
        self.assertEqual(models.ResourcePoolCapacity.objects.count(), 1)
