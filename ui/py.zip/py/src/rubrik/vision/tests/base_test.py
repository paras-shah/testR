from django.test import TestCase


class BaseTestCase(TestCase):

    def setUp(self):
        # from bin.db_loader import load_data
        # load_data()
        pass

