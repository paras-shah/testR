from rubrik.vision.tests.lib.resource_manager import BaseResourceManagerTestCase
from rubrik.vision.tests import mock_models

from rubrik.vision.core.tasks import process_resource_allocation
from rubrik.vision.core.tasks import process_resource_release
from rubrik.vision.core.models import ResourceReservationRequest


class TestProcessResourceAllocation(BaseResourceManagerTestCase):
<<<<<<< HEAD
    def test_process_resource_allocation_OutOfCapacity(self):
        vdu_uuid = mock_models.generate_virtual_datacenter_unit(
            name="vdu1", datacenter="DC1"
        ).id
        resource_types = ["ESX1", "ESX2"]
        resource_prop_types = [
            {"name": "CpuCores", "aggregate_type": "Sum"},
            {"name": "Memory", "aggregate_type": "Sum"},
            {"name": "Disk", "aggregate_type": "Sum"},
            {"name": "NetworkLabLan", "aggregate_type": "Sum"},
            {"name": "NetworkLabWan", "aggregate_type": "Sum"},
        ]
=======

    def test_process_resource_allocation_exception(self):
        vdu_uuid = mock_models.generate_virtual_datacenter_unit(name="vdu1", datacenter='DC1').id
        resource_types = ['ESX1', 'ESX2']
        resource_prop_types = [{'name': 'CpuCores', 'aggregate_type': 'Sum'},
                               {'name': 'Memory', 'aggregate_type': 'Sum'},
                               {'name': 'Disk', 'aggregate_type': 'Sum'},
                               {'name': 'NetworkLabLan', 'aggregate_type': 'Sum'},
                               {'name': 'NetworkLabWan', 'aggregate_type': 'Sum'}]
>>>>>>> d1a5eb956b0f1f7836c99a226d6e1e17b5996fde
        request_params = {
            "requirements": [
                {
                    "virtual_datacenter_unit": str(vdu_uuid),
                    "ResourceType": "VmwareComputeCluster",
                    "name": "gateway",
                    "CpuCores": {"size": 1, "unit": "Hz"},
                    "Memory": {"size": 1024, "unit": "Mb"},
                    "Disk": {"size": 8, "unit": "Mb"},
                    "NetworkLabLan": {"size": 1, "unit": "port"},
                    "NetworkLabWan": {"size": 1, "unit": "port"},
                },
                {
                    "virtual_datacenter_unit": str(vdu_uuid),
                    "ResourceType": "VmwareComputeCluster",
                    "name": "linux-host-2",
                    "CpuCores": {"size": 1, "unit": "Hz"},
                    "Memory": {"size": 1024, "unit": "Mb"},
                    "Disk": {"size": 8, "unit": "Mb"},
                    "NetworkLabLan": {"size": 1, "unit": "port"},
                },
            ]
        }

        mock_models.generate_entity_type(name="Initial", family="ReservationStatus")
        mock_models.generate_entity_type(
            name="PendingReservation", family="ReservationStatus"
        )
        mock_models.generate_entity_type(
            name="ReservationFailed", family="ReservationStatus"
        )
        mock_models.generate_entity_type(name="Reserved", family="ReservationStatus")

        mock_models.generate_entity_type(name="Normal", family="Priority")
        mock_models.generate_entity_type(name="High", family="Priority")
        mock_models.generate_entity_type(name="Urgent", family="Priority")

        mock_models.generate_entity_type(
            name="VmwareComputeCluster", family="ResourceType"
        )

        mock_models.generate_resource_reservation_request(
            request_params=request_params, status="Initial", requestPriority="High"
        )
        mock_models.generate_resource_reservation_request(
            request_params=request_params, status="Initial", requestPriority="Normal"
        )
        mock_models.generate_resource_reservation_request(
            request_params=request_params, status="Initial", requestPriority="Urgent"
        )

        mock_models.generate_resource_types(resource_types)
        mock_models.generate_resource_property_types(resource_prop_types)

        process_resource_allocation()
        rrr = ResourceReservationRequest.objects.all()

        self.assertEqual(len(rrr), 3)
        self.assertEqual(rrr[0].status.name, "ReservationFailed")
        self.assertEqual(rrr[1].status.name, "ReservationFailed")
        self.assertEqual(rrr[2].status.name, "ReservationFailed")

    def test_process_resource_allocation(self):
<<<<<<< HEAD
        mock_models.generate_entity_type(name="Initial", family="ReservationStatus")
=======

>>>>>>> d1a5eb956b0f1f7836c99a226d6e1e17b5996fde
        mock_models.generate_entity_type(
            name="PendingReservation", family="ReservationStatus"
        )
        mock_models.generate_entity_type(
<<<<<<< HEAD
            name="ReservationFailed", family="ReservationStatus"
        )
        mock_models.generate_entity_type(name="Reserved", family="ReservationStatus")

        mock_models.generate_entity_type(name="Normal", family="Priority")
        mock_models.generate_entity_type(name="High", family="Priority")
        mock_models.generate_entity_type(name="Urgent", family="Priority")

        mock_models.generate_entity_type(
            name="VmwareComputeCluster", family="ResourceType"
        )
        mock_models.generate_entity_type(name="Available", family="ResourceStatus")
        mock_models.generate_entity_type(name="Allocated", family="ResourceState")

        self._create_resource_types(["VmwareComputeCluster"])
        CpuCores = self._create_resource_property_type("CpuCores", "Sum")
        rp1 = mock_models.generate_resource_pool("RP1")
        vdu = mock_models.generate_virtual_datacenter_unit("VDU1")
        self._create_resource_pool_share(
            "VDU1",
            "RP1",
            "VmwareComputeCluster",
            CpuCores,
            usable=100,
            used=0,
            free=100,
        )
        self._create_resource_pool_capacity(
            "RP1", "VmwareComputeCluster", CpuCores, usable=100, used=0, free=100
        )
=======
            name="Reserved",
            family="ReservationStatus")
        pending_release = mock_models.generate_entity_type(
            name="PendingRelease",
            family="ReservationStatus")
        mock_models.generate_entity_type(
            name="ReleaseFailed",
            family="ReservationStatus")
        mock_models.generate_entity_type(
            name="Released",
            family="ReservationStatus")

        mock_models.generate_entity_type(
            name="Normal",
            family="Priority")
        mock_models.generate_entity_type(
            name="High",
            family="Priority")
        mock_models.generate_entity_type(
            name="Urgent",
            family="Priority")

        mock_models.generate_entity_type(
            name="VmwareComputeCluster",
            family="ResourceType")

        mock_models.generate_entity_type(name="Available", family="ResourceStatus")
        mock_models.generate_entity_type(name="Allocated", family="ResourceState")

        self._create_resource_types(['VmwareComputeCluster'])
        CpuCores = self._create_resource_property_type('CpuCores', 'Sum')
        vdu = mock_models.generate_virtual_datacenter_unit('VDU1')
        self._create_resource_pool_share('VDU1', 'RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)
        self._create_resource_pool_capacity('RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)
>>>>>>> d1a5eb956b0f1f7836c99a226d6e1e17b5996fde

        request_params = {
            "requirements": [
                {
                    "virtual_datacenter_unit": "{}".format(vdu.id),
                    "ResourceType": "VmwareComputeCluster",
                    "name": "gateway1",
                    "CpuCores": {"size": 50, "unit": "Hz"},
                },
                {
                    "virtual_datacenter_unit": "{}".format(vdu.id),
                    "ResourceType": "VmwareComputeCluster",
                    "name": "gateway",
                    "CpuCores": {"size": 50, "unit": "Hz"},
                },
            ]
        }
        rrr_obj = mock_models.generate_resource_reservation_request(
            request_params=request_params, status="Initial", requestPriority="High"
        )

        self.assertEqual(process_resource_allocation(), None)
        rrr = ResourceReservationRequest.objects.get(id=rrr_obj.id)
        self.assertEqual(rrr.status.name, "Reserved")

        rrr.status = pending_release
        rrr.save()

        process_resource_release()
        rrr_released = ResourceReservationRequest.objects.get(id=rrr.id)

        self.assertEqual(rrr_released.status.name, "Released")

    def test_process_resource_released_fail(self):

        mock_models.generate_entity_type(
            name="PendingRelease",
            family="ReservationStatus")
        mock_models.generate_entity_type(
            name="ReleaseFailed",
            family="ReservationStatus")
        mock_models.generate_entity_type(
            name="Released",
            family="ReservationStatus")

        mock_models.generate_entity_type(
            name="Normal",
            family="Priority")
        mock_models.generate_entity_type(
            name="High",
            family="Priority")
        mock_models.generate_entity_type(
            name="Urgent",
            family="Priority")

        mock_models.generate_entity_type(
            name="VmwareComputeCluster",
            family="ResourceType")

        mock_models.generate_entity_type(name="Available", family="ResourceStatus")
        mock_models.generate_entity_type(name="Allocated", family="ResourceState")

        self._create_resource_types(['VmwareComputeCluster'])
        CpuCores = self._create_resource_property_type('CpuCores', 'Sum')
        rp1 = mock_models.generate_resource_pool('RP1')
        vdu = mock_models.generate_virtual_datacenter_unit('VDU1')
        self._create_resource_pool_share('VDU1', 'RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)
        self._create_resource_pool_capacity('RP1', 'VmwareComputeCluster', CpuCores, usable=100, used=0, free=100)

        request_params = {
            'requirements': [
                {
                    'virtual_datacenter_unit': '{}'.format(vdu.id),
                    'ResourceType': 'VmwareComputeCluster',
                    'name': 'gateway1',
                    'CpuCores': {'size': 50, 'unit': 'Hz'}
                },
                {
                    'virtual_datacenter_unit': '{}'.format(vdu.id),
                    'ResourceType': 'VmwareComputeCluster',
                    'name': 'gateway',
                    'CpuCores': {'size': 50, 'unit': 'Hz'},
                }
            ]
        }

        rrr_obj = mock_models.generate_resource_reservation_request(
            request_params=request_params,
            status="PendingRelease",
            requestPriority="High")

        process_resource_release()
        rrr = ResourceReservationRequest.objects.get(id=rrr_obj.id)
        self.assertEqual(rrr.status.name, "ReleaseFailed")
