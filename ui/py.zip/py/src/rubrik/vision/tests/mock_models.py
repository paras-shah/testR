from django.contrib.auth.models import User as django_user
from rubrik.vision.core import models


def generate_user(
    username="mockuser", password="mockuser", email="mockuser@rubrik.com", is_staff=True
):
    return django_user.objects.get_or_create(
        username=username, password=password, email=email, is_staff=True
    )[0]


def generate_entity_type(name, family):
    return models.EntityType.objects.get_or_create(name=name, family=family)[0]


def generate_datacenter(name=None, location=None, status="Active"):
    name = name or "DC1"
    location = location or generate_entity_type(name, "Location")
    status = generate_entity_type(status, "DataCenterStatus")
    return models.DataCenter.objects.get_or_create(
        name=name, location=location, status=status
    )[0]


def generate_resource_reservation_request(
    request_params, status="INITIAL", requestPriority="HIGH"
):
    return models.ResourceReservationRequest.objects.get_or_create(
        requested_by=generate_user(),
        request_params=request_params,
        status=generate_entity_type(status, "ResourceStatus"),
        priority=generate_entity_type(requestPriority, "RequestPriority"),
    )[0]


def generate_resource_property_type(prop):
    prop_type_name = generate_entity_type(prop["name"], "ResourcePropertyTypes")
    agg_type = generate_entity_type(prop["aggregate_type"], "AggregateType")
    return models.ResourcePropertyType.objects.get_or_create(
        name=prop_type_name, aggregate_type=agg_type
    )[0]


def generate_resource_property_types(props):
    for prop in props:
        generate_resource_property_type(prop)


def generate_resource_type(name):
    return generate_entity_type(name, "ResourceType")


def generate_resource_types(names):
    for name in names:
        generate_resource_type(name)


def generate_resource_pool(name, datacenter=None, state="AVAILABLE", status="RUNNING"):
    resource_pool = models.ResourcePool.objects.get_or_create(
        name=name,
        datacenter=generate_datacenter(datacenter),
        state=generate_entity_type(state, "ResourceState"),
        status=generate_entity_type(status, "ResourceStatus"),
    )[0]
    return resource_pool


def generate_resource(
    name="",
    resource_pool=None,
    resource_type="",
    properties=[],
    shareable=True,
    state="AVAILABLE",
    status="RUNNING",
):
    resource = models.Resource.objects.get_or_create(
        name=name,
        resource_pool=resource_pool or generate_resource_pool(name="pool-1"),
        resource_type=generate_entity_type(resource_type, "ResourceType"),
        state=generate_entity_type(state, "ResourceState"),
        status=generate_entity_type(status, "ResourceStatus"),
    )[0]
    for prop in properties:
        resource_property_type = generate_resource_property_type(prop)
        models.ResourceProperty.objects.get_or_create(
            resource=resource,
            resource_property_type=resource_property_type,
            value=prop["value"],
            useable_capacity=prop["useable_capacity"],
            used_capacity=prop["used_capacity"],
            free_capacity=prop["free_capacity"]
        )


def generate_virtual_datacenter_unit(name, datacenter="DC1"):
    dc = generate_datacenter(datacenter)
    return models.VirtualDataCenterUnit.objects.get_or_create(name=name, datacenter=dc)[
        0
    ]


def generate_resource_pool_share(
    vdu,
    resource_pool,
    resource_type=None,
    resource_property_type=None,
    useable_capacity=100,
    used_capacity=0,
    free_capacity=None,
):
    free_capacity = free_capacity or useable_capacity - useable_capacity
    resource_pool_share = models.ResourcePoolShare.objects.get_or_create(
        virtual_datacenter_unit=generate_virtual_datacenter_unit(vdu),
        resource_pool=generate_resource_pool(resource_pool),
        resource_type=generate_entity_type(resource_type, "ResourceType"),
        resource_property_type=resource_property_type,
        useable_capacity=useable_capacity,
        used_capacity=used_capacity,
        free_capacity=free_capacity,
    )[0]
    return resource_pool_share


def generate_resource_pool_capacity(
    resource_pool,
    resource_type,
    resource_property_type,
    total_capacity=100,
    useable_capacity=100,
    used_capacity=0,
    free_capacity=None,
):
    free_capacity = free_capacity or useable_capacity - useable_capacity
    resource_pool_capacity = models.ResourcePoolCapacity.objects.get_or_create(
        resource_pool=generate_resource_pool(resource_pool),
        resource_type=generate_entity_type(resource_type, "ResourceType"),
        resource_property_type=resource_property_type,
        total_capacity=total_capacity,
        useable_capacity=useable_capacity,
        used_capacity=used_capacity,
        free_capacity=free_capacity,
    )[0]

    return resource_pool_capacity


# def generate_virtual_datacenter_unit_capacity(virtual_datacenter_unit, resource_type, resource_property_type,
#                                               total_capacity=100, useable_capacity=100, used_capacity=0, free_capacity=None):

#     free_capacity = useable_capacity - useable_capacity
#     vdu_capacity = models.ResourcePoolCapacity.objects.get_or_create(
#         virtual_datacenter_unit=generate_virtual_datacenter_unit(virtual_datacenter_unit),
#         resource_type=generate_entity_type(resource_type, 'ResourceType'),
#         resource_property_type=resource_property_type,
#         total_capacity=total_capacity, useable_capacity=useable_capacity, used_capacity=used_capacity,
#         free_capacity=free_capacity)[0]

#     return vdu_capacity
