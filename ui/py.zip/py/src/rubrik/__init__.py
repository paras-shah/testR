# Rubrik is namespace package read more about it on
# https://packaging.python.org/guides/packaging-namespace-packages/
# do not add/remove any content to this file else it will have unwanted
# where some of packages from the namespace are missing and will cause
# random failures when they are accessed.
__path__ = __import__("pkgutil").extend_path(__path__, __name__)
