import logging
import os

import pytest
import yaml
from django.conf import settings

log = logging.getLogger()


def pytest_addoption(parser):
    parser.addoption(
        "--context", action="store", default="dev", help="Context to run with prod or dev"
    )


@pytest.fixture
def run_config(request):
    context = request.config.getoption("--context")
    config_file = "{}/config.yaml".format(os.path.dirname(__file__))
    with open(config_file) as f:
        config = yaml.safe_load(f)
    return config["context"][context]


@pytest.fixture()
def reservation_params(run_config):
    return run_config["lab_templates"]


@pytest.fixture
def web_client(run_config):
    from drf_client.client import DrfClient

    config = run_config["web_client"]
    wscl = DrfClient(config["url"], config["username"], config["password"])
    yield wscl


@pytest.fixture(scope="session")
def django_db_setup():
    from rubrik.vision.site.settings import DATABASES

    settings.DATABASES["default"] = DATABASES["default"]
