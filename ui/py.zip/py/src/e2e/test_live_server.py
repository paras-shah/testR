import logging
from random import randint
from time import sleep

from .common import destroy_lab_template
from .common import launch_lab_template

log = logging.getLogger()


def test_reservation_only(web_client, reservation_params):
    instance = launch_lab_template(web_client, reservation_params)
    sleep(randint(5, 80))
    destroy_lab_template(web_client, instance)
