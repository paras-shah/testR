import logging
from time import sleep
from rest_framework.response import Response

log = logging.getLogger()


def wait_lab_template_instance_state_in(web_client, states, launch_instance=None):
    log.info(
        "Waiting for lab template instance {0} to be in expected states {1}".format(
            launch_instance, states
        )
    )
    while True:
        log.info("waiting for lab template instance status change....")
        sleep(1)
        launch_instance = web_client.api.rubrik.vision.core.lab_template_instance.read(
            id=launch_instance["id"]
        )
        launch_instance["status"] = "Ready"
        if launch_instance["status"] in states:
            log.info("lab template instance in expected states {0}".format(launch_instance))
            return launch_instance


def destroy_lab_template(web_client, launch_instance=None):
    """
    Destroy lab_template_instance
    """
    if launch_instance:
        launch_instance_iter = [launch_instance]
    else:
        launch_instance_iter = web_client.api.rubrik.vision.core.lab_template_instance.list(
            status__name="Ready"
        ).all()
    log.info("destroy".format(launch_instance_iter))
    for _launch_instance in launch_instance_iter:
        log.info("Making request to release reservation {0}".format(_launch_instance))
        update_lab_template_instance = web_client.api.rubrik.vision.core.destroy_lab_template_instance.update(
            id=_launch_instance["id"]
        )
        assert update_lab_template_instance["status"] == "PendingRelease"


def launch_lab_template(web_client, input_params, wait_lab_template_instance_states=False):
    """
    Create lab_template_instance
    """
    log.info("Creating lab_template_instance with params {0}".format(input_params))
    for _input_params_iter in input_params:
        log.info("Creating lab_template_instance with params_i {0}".format(_input_params_iter))
        log.info(
            "Creating lab_template with params_i {0}".format(
                _input_params_iter["lab_template"]["name"]
                + _input_params_iter["lab_template"]["virtualdatacenterunit"]
                + _input_params_iter["lab_template"]["version"]
            )
        )
        lab_location_id = get_vdu_id(
            web_client, _input_params_iter["lab_template"]["virtualdatacenterunit"]
        )
        log.info(lab_location_id)

        lab_template_object = list(web_client.api.rubrik.vision.core.labtemplate.list().all())
        for _lab_template_object_iter in lab_template_object:
            if _lab_template_object_iter["name"] == _input_params_iter["lab_template"]["name"] and \
                    _lab_template_object_iter["version"] == _input_params_iter["lab_template"]["version"] and \
                    _lab_template_object_iter["vdu_id"] == lab_location_id:

                launch_instance = web_client.api.rubrik.vision.core.lab_template_instance.create(
                    params=_input_params_iter["params"], lab_template=_lab_template_object_iter["id"]
                )

                assert Response.status_code == 200

                launch_instance_obj = list(web_client.api.rubrik.vision.core.lab_template_instance.list().all())[-1]
                initial_launch_instance_state = launch_instance_obj["status"]
                assert initial_launch_instance_state == "Initial"
                if not wait_lab_template_instance_states:
                    launch_instance = wait_lab_template_instance_state_in(
                        web_client, ["Failed", "Ready"], launch_instance_obj
                    )
                assert launch_instance["status"] == "Ready"
                log.info(launch_instance["status"])
                return launch_instance


def get_vdu_id(web_client, input_name):
    vdus = web_client.api.rubrik.vision.core.virtualdatacenterunit.list().all()
    for each_vdu in vdus:
        if each_vdu["name"] == input_name:
            return each_vdu["id"]
