#!/bin/bash
sudo chown root:docker /var/run/docker.sock
source $(pipenv --venv)/bin/activate
exec "$@"